"""Inspect compositing/age effects at frame299 without changing coded results."""
import json
from pathlib import Path
import random
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
import numpy as np
import torch
from torchvision.utils import save_image
from libgs.metric import psnr
from pipeline.module import motion_photometric_loss
from scripts.benchmark_rigid_residual_tree import (_load_config,_make_module,
    _capture_raw,_install_raw,_cam00,check_gpu_exclusivity)

OUT=Path(__file__).resolve().parent
job=json.loads((ROOT/'output/fs_ste_rate_sweep_full300_20261017/status.json').read_text())['jobs'][1]
run=Path(job['run']);frame=299;device=torch.device('cuda')
check_gpu_exclusivity()
cfg=_load_config(run);module,data=_make_module(cfg,device)
raw,degree=_capture_raw(run/'rigid-ckpt-299-200.pth',frame,200)
module.gaussians.active_sh_degree=degree
data.current_frame=frame
dataset=data.get_train_dataset()
indices=sorted(range(len(dataset.items)),key=lambda i:dataset.items[i].path.name)
train=[dataset[i].to(device) for i in indices]
view,_=_cam00(data,frame,device)
image_dir=OUT/'images';image_dir.mkdir(exist_ok=True)
save_image(view.image,image_dir/'frame299_gt.png')

@torch.no_grad()
def evaluate(label):
    image=module.forward(view)['render'].clamp(0,1)
    save_image(image,image_dir/(label+'.png'))
    return dict(psnr=float(psnr(image,view.image)),count=len(module.gaussians._xyz))

_install_raw(module,raw,device)
result=dict(baseline=evaluate('frame299_baseline'),
    scope='All opacity updates below are unquantized and not coded. No existing result files changed.')
N0=206237
N269=json.loads((run/'frame_summary/frame_269.json').read_text())['total_count']
N298=json.loads((run/'frame_summary/frame_298.json').read_text())['total_count']
ids=torch.arange(len(raw['xyz']))
for label,keep in [('initial_plus_last30_births',(ids<N0)|(ids>=N269)),
                   ('initial_plus_current_births',(ids<N0)|(ids>=N298))]:
    _install_raw(module,{name:value[keep] for name,value in raw.items()},device)
    result[label]=evaluate('frame299_'+label)

_install_raw(module,raw,device)
parameter=module.gaussians._opacity
parameter.requires_grad_(True)
optimizer=torch.optim.Adam([parameter],lr=cfg.module.gaussian.opacity_lr,eps=1e-8)
initial=list(range(len(train)));repeated=initial.copy();random.Random(frame).shuffle(repeated)
sequence=initial+[repeated[i%len(repeated)] for i in range(200-len(initial))]
for step in range(100):
    optimizer.zero_grad(set_to_none=True)
    for index in sequence[2*step:2*step+2]:
        image=module.forward(train[index],training=True)['render']
        (motion_photometric_loss(image,train[index].image,cfg.module.lambda_dssim)/2).backward()
    optimizer.step()
result['opacity_only']=evaluate('frame299_opacity_only')
before=raw['opacity'].flatten()
after=parameter.detach().cpu().flatten()
delta=torch.sigmoid(after)-torch.sigmoid(before)
for label,mask in [('initial',ids<N0),('older_births',(ids>=N0)&(ids<N269)),
                   ('recent_births',(ids>=N269)&(ids<N298)),('current_births',ids>=N298),
                   ('all',torch.ones(len(ids),dtype=torch.bool))]:
    d=delta[mask];v=after[mask]
    result[label+'_opacity_changes']=dict(count=len(d),
        mean_alpha_change=float(d.mean()),mean_abs_alpha_change=float(d.abs().mean()),
        alpha_decreased_over_001=int((d<-.01).sum()),alpha_increased_over_001=int((d>.01).sum()),
        alpha_below_001_before=int((torch.sigmoid(before[mask])<.01).sum()),
        alpha_below_001_after=int((torch.sigmoid(v)<.01).sum()),
        logit_updates_ge_half_001_grid=int(((v-before[mask]).abs()>=.005).sum()))
(OUT/'opacity_detail.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
