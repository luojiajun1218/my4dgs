"""Fixed-count diagnostic fits, not a coded method or rate-distortion result."""
from dataclasses import asdict
import json
from pathlib import Path
import random
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import numpy as np
import torch
from libgs.metric import psnr, ssim
from pipeline.module import motion_photometric_loss
from pipeline.model.birth_quantization import RAW_FIELDS, RAW_ATTRIBUTES
from scripts.benchmark_rigid_residual_tree import (
    _load_config, _make_module, _capture_raw, _install_raw, _cam00, check_gpu_exclusivity)

OUT = Path(__file__).resolve().parent
jobs = json.loads((ROOT/'output/fs_ste_rate_sweep_full300_20261017/status.json').read_text())['jobs']
run = Path(jobs[1]['run'])
device = torch.device('cuda')
check_gpu_exclusivity()
cfg = _load_config(run)
module, data = _make_module(cfg, device)
result = dict(run=str(run), frames=[],
    scope='Extra fits on a completed decoded frame, fixed count, unquantized, no rate loss. '
          'These are diagnostic headroom checks, NOT deployable coded results.',
    fitting_steps=100, views_per_step=2, camera_selection='same deterministic training order for all modes; cam00 held out',
    no_original_run_mutations=True)


def save():
    path = OUT/'parameter_audit.json'
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(result, indent=2)+'\n')
    temporary.replace(path)


@torch.no_grad()
def evaluate(views):
    rows = []
    for view in views:
        image = module.forward(view)['render']
        loss = motion_photometric_loss(image, view.image, cfg.module.lambda_dssim)
        image = image.clamp(0,1)
        rows.append(dict(camera=view.path.name, psnr=float(psnr(image,view.image)),
            ssim=float(ssim(image,view.image)), mse=float((image-view.image).square().mean()),
            image_loss=float(loss)))
    return dict(rows=rows, psnr_mean=sum(r['psnr'] for r in rows)/len(rows),
        mse_mean=sum(r['mse'] for r in rows)/len(rows),
        image_loss_mean=sum(r['image_loss'] for r in rows)/len(rows))


def fit(raw, mode, training_views, test_view, frame, current_births):
    _install_raw(module, raw, device)
    rates = {'xyz': cfg.module.rigid_tree.gs_translation_lr,
        'rotation': cfg.module.rigid_tree.gs_rotation_lr,
        'logscale':cfg.module.gaussian.scaling_lr,
        'opacity':cfg.module.gaussian.opacity_lr,
        'sh_dc':cfg.module.gaussian.feature_lr,
        'sh_rest':cfg.module.gaussian.feature_lr/20}
    selected = dict(pose=['xyz','rotation'], appearance=['logscale','opacity','sh_dc','sh_rest'],
        sh_only=['sh_dc','sh_rest'], opacity_only=['opacity'], all_existing=list(RAW_FIELDS),
        newborn_only=list(RAW_FIELDS))[mode]
    if mode == 'newborn_only':
        stage2 = cfg.module.gaussian_stage2
        rates.update(xyz=stage2.position_lr_init*data.cameras_extent,
            rotation=stage2.rotation_lr, logscale=stage2.scaling_lr,
            opacity=stage2.opacity_lr, sh_dc=stage2.feature_lr, sh_rest=stage2.feature_lr/20)
    groups = []
    params = {}
    for name, attr in zip(RAW_FIELDS, RAW_ATTRIBUTES):
        p = getattr(module.gaussians,attr)
        p.requires_grad_(name in selected)
        if name in selected:
            groups.append(dict(params=[p],lr=rates[name]))
            params[name] = p
    optimizer = torch.optim.Adam(groups, eps=1e-8)
    initial = list(range(len(training_views)))
    repeated = initial.copy()
    random.Random(frame).shuffle(repeated)
    sequence = initial+[repeated[i%len(repeated)] for i in range(200-len(initial))]
    started=time.perf_counter()
    for step in range(100):
        optimizer.zero_grad(set_to_none=True)
        for index in sequence[2*step:2*step+2]:
            view = training_views[index]
            image = module.forward(view,training=True)['render']
            loss = motion_photometric_loss(image,view.image,cfg.module.lambda_dssim)
            (loss/2).backward()
        if mode == 'newborn_only':
            for p in params.values():
                if p.grad is not None:
                    p.grad[:-current_births] = 0
        optimizer.step()
    torch.cuda.synchronize()
    duration=time.perf_counter()-started
    evaluated=dict(training=evaluate(training_views), heldout=evaluate([test_view]))
    if mode == 'newborn_only':
        assert all(torch.equal(getattr(module.gaussians,attr)[:-current_births].detach().cpu(),
                               raw[name][:-current_births])
                   for name,attr in zip(RAW_FIELDS,RAW_ATTRIBUTES))
    evaluated.update(mode=mode, trainable_fields=selected,
        rates={name:rates[name] for name in selected}, seconds=duration,
        gaussian_count=len(raw['xyz']), new_points_added=0)
    print(json.dumps(dict(frame=frame,mode=mode,train_psnr=evaluated['training']['psnr_mean'],
        test_psnr=evaluated['heldout']['psnr_mean'],seconds=duration)),flush=True)
    return evaluated


reference = np.load(run/'frame_storage/rigid_tree/reference_frame0.npz')
reference_count=len(reference['xyz'])
for frame in [29,149,299]:
    raw,degree=_capture_raw(run/f'rigid-ckpt-{frame}-200.pth',frame,200)
    module.gaussians.active_sh_degree=degree
    _install_raw(module,raw,device)
    data.current_frame=frame
    dataset=data.get_train_dataset()
    indices=sorted(range(len(dataset.items)),key=lambda i:dataset.items[i].path.name)
    train_views=[dataset[i].to(device) for i in indices]
    test_view,_=_cam00(data,frame,device)
    summary=json.loads((run/f'frame_summary/frame_{frame:03d}.json').read_text())
    baseline=dict(training=evaluate(train_views),heldout=evaluate([test_view]))
    assert abs(baseline['heldout']['psnr_mean']-summary['evaluation']['test']['psnr'])<1e-5
    record=dict(frame=frame,baseline=baseline,gaussian_count=len(raw['xyz']),
        current_births=summary['birth_count'],
        reference_attribute_unchanged={name:bool(np.array_equal(raw[name][:reference_count].numpy(),reference[name]))
            for name in ['logscale','opacity','sh_dc','sh_rest']},modes=[])
    result['frames'].append(record)
    save()
    modes=['pose','appearance'] if frame!=299 else ['pose','appearance','sh_only','opacity_only','all_existing','newborn_only']
    for mode in modes:
        record['modes'].append(fit(raw,mode,train_views,test_view,frame,summary['birth_count']))
        save()
    if frame==299:
        record['cohort_removal']={}
        counts={i:json.loads((run/f'frame_summary/frame_{i:03d}.json').read_text())['total_count']
                for i in [269,298]}
        for label,mask in [
                ('remove_current_births',torch.arange(len(raw['xyz']))<counts[298]),
                ('remove_last30_births',torch.arange(len(raw['xyz']))<counts[269]),
                ('keep_reference_cohort_only',torch.arange(len(raw['xyz']))<reference_count)]:
            _install_raw(module,{name:value[mask] for name,value in raw.items()},device)
            record['cohort_removal'][label]=dict(count=int(mask.sum()),
                training=evaluate(train_views),heldout=evaluate([test_view]))
        save()
    del train_views,test_view,raw
    torch.cuda.empty_cache()
result['complete']=True
save()
