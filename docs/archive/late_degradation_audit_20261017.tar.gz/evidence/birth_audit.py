"""Replay a late frame from step70 and test a lower birth threshold."""
import copy
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT/'output/fs_ste_rate_sweep_full300_20261017/source'
sys.path.insert(0, str(SOURCE))
import torch
from pipeline.entry import Pipeline
from scripts.benchmark_rigid_residual_tree import _load_config, check_gpu_exclusivity

OUT = Path(__file__).resolve().parent
job=json.loads((ROOT/'output/fs_ste_rate_sweep_full300_20261017/status.json').read_text())['jobs'][1]
run=Path(job['run'])
result=dict(source=str(SOURCE),source_run=str(run),frame=299,start_step=70,
    cases=[], scope='Single-frame diagnostic replay. Historical outputs are read-only.')


def save():
    path=OUT/'birth_audit.json'
    temporary=path.with_suffix('.tmp')
    temporary.write_text(json.dumps(result,indent=2)+'\n')
    temporary.replace(path)


for tag,multiplier in [('baseline',1.),('threshold_quarter',.25)]:
    check_gpu_exclusivity()
    cfg=_load_config(run)
    cfg.output_dir=OUT
    cfg.experiment_name=f'birth_frame299_{tag}'
    cfg.ckpt_path=run/'rigid-ckpt-299-70.pth'
    pipeline=Pipeline(cfg)
    trainer,module=pipeline.trainer,pipeline.module
    trainer.setup(module,cfg.ckpt_path)
    # Restore under its original configuration before the explicit diagnostic change.
    module.config.birth.densify_grad_threshold*=multiplier
    pipeline.save_config()
    case=dict(case=tag,multiplier=multiplier,
        effective_threshold=module.config.birth.densify_grad_threshold,
        output=str(pipeline.output_dir),prune_events=[])
    result['cases'].append(case)

    motion=module.motion
    parameters=[motion.region_translation,motion.region_rotation,
                motion.gs_translation,motion.gs_rotation,motion.gate_logits]
    names=['region_translation','region_rotation','gs_translation','gs_rotation','gate_logits']
    frozen=motion._hard_gate_frozen
    motion._hard_gate_frozen=False
    terms=motion.loss_terms(35,diagnostics=False)
    gradients=torch.autograd.grad(terms['rate_loss'],parameters,allow_unused=True)
    case['rate_gradients_during_soft_path_diagnostic']={name:None if grad is None else
        dict(abs_sum=float(grad.abs().sum()),nonzero=int(grad.ne(0).sum()))
        for name,grad in zip(names,gradients)}
    motion._hard_gate_frozen=frozen

    original_begin=module._begin_births
    @torch.no_grad()
    def begin():
        model=module.gaussians
        scores=torch.nan_to_num(model.xyz_gradient_accum/model.denom,nan=0.).norm(dim=-1)
        high=scores>=module.config.birth.densify_grad_threshold
        small=model.get_scaling.max(dim=1).values<=model.percent_dense*module.datamodule.cameras_extent
        case['pre_birth_candidates']=dict(old_count=len(scores),
            above_threshold=int(high.sum()),small_eligible=int((high&small).sum()),
            large_excluded=int((high&~small).sum()),
            small_scale_cutoff_world=float(model.percent_dense*module.datamodule.cameras_extent),
            max_new_gaussians=module.config.birth.max_new_gaussians)
        return original_begin()
    module._begin_births=begin

    original_periodic=module.births.adaptive_densify_and_prune
    def periodic(*args,**kwargs):
        info=original_periodic(*args,**kwargs)
        case['prune_events'].append(dict(step=trainer.global_step,kind='periodic',**info))
        return info
    module.births.adaptive_densify_and_prune=periodic

    original_terminal=module._prune_terminal_births
    @torch.no_grad()
    def terminal():
        model=module.births; config=module.config.birth
        low=model.get_opacity.flatten()<config.opacity_threshold
        screen=model.max_radii2D>config.new_max_screen_size
        world=model.get_scaling.max(dim=1).values>.1*module.datamodule.cameras_extent
        case['prune_events'].append(dict(step=trainer.global_step,kind='terminal',
            before=len(low),low_opacity=int(low.sum()),big_screen=int(screen.sum()),
            big_world=int(world.sum()),removed=int((low|screen|world).sum())))
        return original_terminal()
    module._prune_terminal_births=terminal
    started=time.perf_counter()
    report=trainer.frame_training_loop()
    case['seconds']=time.perf_counter()-started
    case['report']={name:report[name] for name in ['evaluation','birth_count','total_count',
        'birth_control','encoded_bytes','stage_image_metrics','motion_rate_diagnostics']}
    case['motion_bytes']=report['motion']['bytes']
    case['birth_attribute_bytes']=report['birth']['archive_bytes'] if report['birth'] else 0
    case['saved_original_psnr']=json.loads((run/'frame_summary/frame_299.json').read_text())['evaluation']['test']['psnr']
    print(json.dumps(case),flush=True)
    save()
    if trainer.tb_writer is not None:
        trainer.tb_writer.close()
    del trainer,module,pipeline,gradients,terms,parameters
    import gc
    gc.collect()
    torch.cuda.empty_cache()
result['complete']=True
save()
