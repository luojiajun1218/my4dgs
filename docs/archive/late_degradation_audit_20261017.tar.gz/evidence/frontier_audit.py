"""Compare fixed spatial cuts at identical fitted motion; never train/set gates in production."""
import copy
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
import torch
from libgs.metric import psnr
from pipeline.model.spatial_gated_motion import SpatialGatedMotion
from pipeline.model.spatial_gate import spatial_owner
from scripts.benchmark_rigid_residual_tree import (_load_config,_make_module,
    _install_raw,_cam00,CAPTURE_INDEX,check_gpu_exclusivity)

OUT=Path(__file__).resolve().parent
job=json.loads((ROOT/'output/fs_ste_rate_sweep_full300_20261017/status.json').read_text())['jobs'][1]
run=Path(job['run']);device=torch.device('cuda')
check_gpu_exclusivity()
cfg=_load_config(run)
checkpoint=torch.load(run/'rigid-ckpt-299-100.pth',map_location=device,weights_only=False)
module,data=_make_module(cfg,device)
view,_=_cam00(data,299,device)
base_raw={name:checkpoint['gaussians'][index].detach().cpu() for name,index in CAPTURE_INDEX.items()}
result=dict(frame=299,source_run=str(run),cases=[],
    scope='Post-hoc recoding only, fixed integer full motions, no births and no image optimization. '
          'All-open/all-coarse are diagnostic endpoints, NOT replacement rules for the learnable gate.')
original_motion=None
original_pose=None
for cut in ['learned','coarse8_refit','finest_refit']:
    motion=SpatialGatedMotion(cfg.module.rigid_tree)
    motion.restore(copy.deepcopy(checkpoint['rigid_tree_motion']))
    with torch.no_grad():
        full=motion._full_motion_symbols()
        if original_motion is None:
            original_motion=tuple(v.clone() for v in full)
            original_pose=tuple(v.clone() for v in motion.materialized_pose())
        if cut!='learned':
            opened=(torch.zeros_like(motion.opened) if cut.startswith('coarse') else motion.split_eligible.clone())
            opened[0]=True
            owner=spatial_owner(motion.spatial_paths,opened)
            motion.opened=opened
            motion._recode_owner(owner,full_motion=full)
            motion._hard_gate_frozen=True
            motion._refresh_active_representatives()
        final=motion._full_motion_symbols()
        assert all(torch.equal(a,b) for a,b in zip(original_motion,final))
        pose=motion.materialized_pose()
        delta=[float((a-b).abs().max()) for a,b in zip(pose,original_pose)]
        motion.register_materialized_layout(*pose,birth_source_rows=torch.empty(0,dtype=torch.long,device=device))
        packet_info=motion.export_motion(OUT/f'frontier_{cut}_motion299.bin')
        decoded=motion.codec_previous_state
        raw={**base_raw,'xyz':decoded.xyz,'rotation':decoded.rotation}
        _install_raw(module,raw,device)
        image=module.forward(view)['render'].clamp(0,1)
        terms=motion.loss_terms(100,diagnostics=True)
        row=dict(cut=cut,bytes=packet_info['bytes'],
            raw_stream_bytes=packet_info['raw_stream_bytes'],
            active_regions=int(motion.owner.unique().numel()),
            gs_active_rows=int(terms['gs_active_rows']),
            identical_integer_full_motion=True,max_abs_pose_delta=delta,
            heldout_psnr=float(psnr(image,view.image)))
        result['cases'].append(row)
        print(json.dumps(row),flush=True)
(OUT/'frontier_audit.json').write_text(json.dumps(result,indent=2)+'\n')
