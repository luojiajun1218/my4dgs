"""Inspect packet sections without changing existing experiment files."""
import csv
import json
from pathlib import Path
import statistics
import struct
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from pipeline.model.rigid_tree_codec import uncompressed_motion_packet, _Reader, SPATIAL_MAGIC

OUT = Path(__file__).resolve().parent
jobs = json.loads((ROOT / 'output/fs_ste_rate_sweep_full300_20261017/status.json').read_text())['jobs']


def sparse(reader):
    start = reader.cursor
    n = reader.integer()
    count_bytes = reader.cursor-start
    gap_bytes = flags_bytes = translation_bytes = rotation_bytes = 0
    active_t = active_r = 0
    for _ in range(n):
        previous = reader.cursor
        reader.integer()
        gap_bytes += reader.cursor-previous
        flags = reader.take(1)[0]
        flags_bytes += 1
        assert flags in [1, 2, 3]
        if flags & 1:
            reader.take(6)
            translation_bytes += 6
            active_t += 1
        if flags & 2:
            reader.take(6)
            rotation_bytes += 6
            active_r += 1
    return dict(rows=n, count_bytes=count_bytes, gap_bytes=gap_bytes,
                flags_bytes=flags_bytes, translation_bytes=translation_bytes,
                rotation_bytes=rotation_bytes, active_translation=active_t,
                active_rotation=active_r, section_bytes=reader.cursor-start)


results = []
for job in jobs:
    run = Path(job['run'])
    rows = []
    for frame in range(1, 300):
        packet = (run / f'frame_storage/rigid_tree/motion_{frame:03d}.bin').read_bytes()
        raw = uncompressed_motion_packet(packet)
        reader = _Reader(raw[:-16])
        assert bytes(reader.take(4)) == SPATIAL_MAGIC
        reader.take(32)
        index, regions, count, births = [reader.integer() for _ in range(4)]
        assert index == frame
        quantization = struct.unpack('<5d', reader.take(40))
        assert reader.take(1)[0] == 0
        assert reader.integer() == 0
        header = reader.cursor
        reader.take((regions+7)//8)
        regional = sparse(reader)
        point = sparse(reader)
        start = reader.cursor
        for _ in range(births):
            reader.integer()
        source_bytes = reader.cursor-start
        reader.take(births*28)
        assert reader.cursor == len(raw)-16
        summary = json.loads((run / f'frame_summary/frame_{frame:03d}.json').read_text())
        assert point['rows'] == summary['motion_activity']['old_gs_with_local_residual']
        assert len(raw) == header+(regions+7)//8+regional['section_bytes']+point['section_bytes']+source_bytes+births*28+16
        stage = {r['step']: r['psnr'] for r in summary['stage_image_metrics']}
        row = dict(frame=frame, stored_motion_bytes=len(packet), raw_motion_bytes=len(raw),
            old_count=count, birth_count=births, header_bytes=header,
            gate_bits_bytes=(regions+7)//8, checksum_bytes=16,
            birth_source_bytes=source_bytes, birth_pose_bytes=births*28,
            psnr100=stage[100], psnr200=stage[200], birth_gain=stage[200]-stage[100],
            clone_added=summary['birth_control']['clone_added'],
            split_added=summary['birth_control']['split_added'],
            pruned=summary['birth_control']['pruned'],
            birth_attribute_bytes=summary['birth']['archive_bytes'] if summary['birth'] else 0,
            **{'region_'+k:v for k,v in regional.items()},
            **{'gs_'+k:v for k,v in point.items()})
        rows.append(row)
    suffix = str(job['rate_loss_weight']).replace('0.', '')
    with (OUT/f'storage{suffix}_per_frame.csv').open('x', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    def aggregate(part):
        return {key:statistics.mean(row[key] for row in part)
                for key in rows[0] if key != 'frame'}
    result = dict(weight=job['rate_loss_weight'], run=str(run),
        raw_accounting='Section bytes before whole-packet entropy compression; compressed contributions are not additive.',
        all_dynamic=aggregate(rows), first30=aggregate(rows[:30]),
        last29=aggregate(rows[270:]),
        note='The motion packet also stores newborn pose/source rows; birth attributes are a separate packet.')
    results.append(result)
    print(json.dumps(result), flush=True)
(OUT/'storage_audit.json').write_text(json.dumps(results, indent=2)+'\n')
