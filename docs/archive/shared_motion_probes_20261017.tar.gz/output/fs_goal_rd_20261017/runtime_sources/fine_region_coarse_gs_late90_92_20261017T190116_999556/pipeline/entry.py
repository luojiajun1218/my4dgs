from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Literal, Optional

import torch

from libgs.pipeline import Config as BaseConfig
from libgs.pipeline import Pipeline as BasePipeline
from libgs.utils.general import safe_state

from .data import DataConfig, DataModule
from .module import Module, ModuleConfig
from .trainer import Trainer, TrainerConfig


@dataclass
class Config(BaseConfig):
    output_dir: Path = Path("output")
    experiment_name: str = datetime.now().strftime("%Y-%m-%d")
    mode: Literal["train", "validate"] = "train"
    ckpt_path: Optional[Path] = None
    resume_prefix_dir: Optional[Path] = None
    resume_completed_prefix_frames: Optional[int] = None
    gui_ip: str = "127.0.0.1"
    gui_port: int = 6009
    gui_enabled: bool = True
    detect_anomaly: bool = False
    quiet: bool = False
    random_seed: int = 0
    trainer: TrainerConfig = field(default_factory=TrainerConfig)
    data: DataConfig = field(default_factory=DataConfig)
    module: ModuleConfig = field(default_factory=ModuleConfig)


class Pipeline(BasePipeline):
    datamodule: DataModule
    module: Module
    trainer: Trainer

    def setup(self):
        safe_state(self.config.quiet, seed=self.config.random_seed)
        if self.config.gui_enabled:
            from libgs.renderer import network_gui
            network_gui.init(self.config.gui_ip, self.config.gui_port)
        torch.autograd.set_detect_anomaly(self.config.detect_anomaly)
        return super().setup()

    def setup_trainer_and_modules(self):
        output_dir = Path(self.config.output_dir) / self.config.experiment_name
        self.datamodule = DataModule(self.config.data)
        self.module = Module(self.config.module, datamodule=self.datamodule)
        self.module.gui_enabled = self.config.gui_enabled
        self.trainer = Trainer(self.config.trainer, output_dir=output_dir)
        if self.config.resume_prefix_dir is not None and self.config.mode != 'train':
            raise ValueError('Completed-prefix extension is a training entry point')
        if (self.config.resume_completed_prefix_frames is not None and
                self.config.resume_prefix_dir is None):
            raise ValueError('An explicit completed prefix length needs resume_prefix_dir')
        self.trainer.resume_prefix_dir = self.config.resume_prefix_dir
        self.trainer.resume_completed_prefix_frames = self.config.resume_completed_prefix_frames
