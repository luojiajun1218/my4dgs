"""Fine shared motion and sparse coarse corrections must retain their units."""
import copy
import unittest
import torch

from pipeline.model.spatial_gated_motion import SpatialGatedMotion
import test_joint_spatial_motion as joint_tests


class SeparateMotionGridTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)

    def model(self, rotation=False):
        source = joint_tests.JointSpatialMotionTests().model()
        cfg = copy.deepcopy(source.config)
        cfg.spatial_gate.joint_image_gradients = True
        cfg.proximal_gs_regularization = True
        cfg.rotation_updates = rotation
        cfg.motion_xyz_step_extent = cfg.gs_xyz_step_extent/4
        cfg.motion_rotation_step_rad = cfg.gs_rotation_step_rad/2
        cfg.validate()
        model = SpatialGatedMotion(cfg)
        model.setup(source.base_xyz, source.base_rotation, source.extent, frame_index=1)
        with torch.no_grad():
            model.region_translation[1:, 0] = 3 * model.steps[0]
            model.gs_translation[:, 0] = 2.2 * model.gs_steps[0]
            if rotation:
                model.region_rotation[1:, 1] = 3 * model.steps[3]
                model.gs_rotation[:, 1] = model.gs_steps[3]
        return model

    def test_configuration_rejects_noncommensurate_or_representation_only_grids(self):
        cfg = copy.deepcopy(self.model().config)
        cfg.spatial_gate.joint_image_gradients = False
        with self.assertRaisesRegex(ValueError, 'same region'):
            cfg.validate()
        cfg.spatial_gate.joint_image_gradients = True
        for ratio in (.5, 2.5):
            cfg.motion_xyz_step_extent = cfg.gs_xyz_step_extent/ratio
            with self.assertRaisesRegex(ValueError, 'integer GS/region'):
                cfg.validate()
        cfg.motion_xyz_step_extent = cfg.gs_xyz_step_extent/4
        for bad in (0., float('nan'), float('inf')):
            cfg.gs_rotation_step_rad = bad
            with self.assertRaisesRegex(ValueError, 'gs_rotation_step_rad'):
                cfg.validate()

    def test_full_symbols_use_regional_units_and_independent_decoder(self):
        model = self.model(rotation=True)
        t,r = model._full_motion_symbols()
        self.assertTrue(bool(t[:, 0].eq(11).all()))
        self.assertTrue(bool(r[:, 1].eq(5).all()))
        joint_tests.JointSpatialMotionTests().commit(model)

    def test_warm_start_preserves_increment_and_subbin_remainder_with_birth_lineage(self):
        model = self.model()
        before = tuple(value.detach().clone() for value in model._full_motion_symbols())
        remainder = model.gs_translation.detach().clone()
        source = torch.tensor([0, 20])
        births = model.materialized_pose()[0][source]
        state = joint_tests.JointSpatialMotionTests().commit(model, births, source)
        model.setup(state.xyz, state.rotation, model.extent, frame_index=2)
        for actual, previous in zip(model._full_motion_symbols(), before):
            torch.testing.assert_close(actual, torch.cat((previous, previous[source])), rtol=0, atol=0)
        torch.testing.assert_close(model.gs_translation,
            torch.cat((remainder, remainder[source])), rtol=0, atol=0)

    def test_gate_change_keeps_coarse_residual_and_applies_fine_shared_change(self):
        model = self.model()
        parent = int(model.owner[0]);members = model.owner.eq(parent)
        children = torch.where(model.parents.eq(parent))[0]
        with torch.no_grad():
            model.region_translation[children, 0] = 5*model.steps[0]
        previous = model._full_motion_symbols()[0].detach().clone()
        residual = model.gs_translation.detach().clone()
        with torch.no_grad():
            model.gate_logits[parent] = 2.
        model._select_frontier(freeze=False)
        torch.testing.assert_close(model.gs_translation, residual, rtol=0, atol=0)
        change = model._full_motion_symbols()[0]-previous
        self.assertTrue(bool(change[members, 0].eq(2).all()))
        with self.assertRaisesRegex(ValueError, 'identical region/GS grids'):
            model._recode_owner(model.owner.clone())
        joint_tests.JointSpatialMotionTests().commit(model)

    def test_photo_proximal_update_and_checkpoint_restore_are_consistent(self):
        model = self.model()
        model.mark_observed(torch.ones(len(model.owner), dtype=torch.bool))
        restored = SpatialGatedMotion(copy.deepcopy(model.config))
        restored.restore(copy.deepcopy(model.capture()))
        for current in (model,restored):
            xyz,_ = current(1,training=True)
            image = (xyz-current.base_xyz-.01).square().mean()
            (image+current.regularization_loss(1)).backward()
            self.assertIsNotNone(current.region_translation.grad)
            self.assertIsNotNone(current.gs_translation.grad)
            current.optimizer_step()
        left,right = dict(model.named_parameters()),dict(restored.named_parameters())
        self.assertEqual(left.keys(),right.keys())
        for name in left:
            torch.testing.assert_close(left[name],right[name],rtol=0,atol=0)


if __name__ == '__main__':
    unittest.main()
