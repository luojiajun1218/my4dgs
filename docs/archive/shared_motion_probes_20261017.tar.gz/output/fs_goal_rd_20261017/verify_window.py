"""Independently replay a frozen-code window and measure actual update bytes."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument('run', type=Path)
args = parser.parse_args()
run = args.run.resolve()
status = json.loads((run / 'window_status.json').read_text())
assert status['complete']
snapshot = Path(status['runtime_source'])
assert all(hashlib.sha256((snapshot / path).read_bytes()).hexdigest() == digest
           for path, digest in status['source_hashes'].items())
sys.path.insert(0, str(snapshot))
import torch
from scripts.benchmark_rigid_residual_tree import (
    _load_config, _make_module, _load_reference, _decode_frame, _install_raw,
    _cam00, _sequence_quality, _time_sequence_render, _validate_stream_manifest,
    _actual_frame_storage, _capture_raw, check_gpu_exclusivity, CAPTURE_INDEX)

torch.set_num_threads(2)
gpu = check_gpu_exclusivity()
cfg = _load_config(run)
module, data = _make_module(cfg, torch.device('cuda'))
stream = run / 'frame_storage/rigid_tree'
first, last = status['start'], status['end']
references = [stream / f'reference_frame{first-1}.npz',
              stream / f'reference_frame{first-1:03d}.npz']
ref = next(path for path in references if path.exists())
state, raw = _load_reference(ref, None)
source = Path(status['source'])
if first == 1:
    packet = torch.load(source, map_location='cpu', weights_only=False)
    capture = packet['gaussians']
    original = {name: capture[index].detach().float().cpu().contiguous()
                for name, index in CAPTURE_INDEX.items()}
    # The initial pruning is performed on the GPU before writing the bootstrap.
    keep = original['opacity'].cuda().sigmoid().flatten().ge(
        cfg.module.initial_opacity_threshold).cpu()
    saved = {name: value[keep] for name, value in original.items()}
else:
    saved, _ = _capture_raw(source, first - 1, 200)
assert all(torch.equal(raw[key], saved[key]) for key in raw)
relative_reference = json.loads((stream / f'frame_{first:03d}.json').read_text())['reference']
rows = []
bootstrap_quality = None
if first == 1:
    _install_raw(module, raw, torch.device('cuda'))
    view, n = _cam00(data, 0, torch.device('cuda'))
    assert n == 1
    from scripts.benchmark_rigid_residual_tree import _render_checked
    from libgs.metric import psnr, ssim
    with torch.no_grad():
        image = _render_checked(module, view)
        bootstrap_quality = dict(psnr=float(psnr(image, view.image)),
                                 ssim=float(ssim(image, view.image)),
                                 pure_fps=50/_time_sequence_render(module, view, 10, 50))
    del view
for frame in range(first, last + 1):
    started = time.perf_counter()
    preceding_rotation = raw['rotation']
    state, raw = _decode_frame(stream, frame, state, raw)
    manifest = _validate_stream_manifest(stream, frame, state, raw, relative_reference)
    decode_seconds = time.perf_counter() - started
    _install_raw(module, raw, torch.device('cuda'))
    view, n = _cam00(data, frame, torch.device('cuda'))
    assert n == 1
    summary = json.loads((run / 'frame_summary' / f'frame_{frame:03d}.json').read_text())
    quality, difference, cache_difference = _sequence_quality(module, view,
        summary['evaluation']['test'], dict(psnr=1e-4, ssim=1e-6, l1=1e-6), True)
    storage = _actual_frame_storage(stream, frame, manifest, summary,
                                    ref.stat().st_size, relative_reference)
    render_seconds = _time_sequence_render(module, view, 10, 50)
    row = dict(frame=frame, quality=quality, quality_saved_difference=difference,
        cache_pixel_max_abs_difference=cache_difference, render_seconds=render_seconds,
        pure_fps=50/render_seconds, decode_seconds=decode_seconds, **storage)
    if not getattr(cfg.module.rigid_tree, 'rotation_updates', True):
        survivors = state.survivor_rows
        assert torch.equal(raw['rotation'][:len(survivors)], preceding_rotation[survivors])
        row['old_orientation_unchanged'] = True
    if not getattr(cfg.module.birth, 'rotation_updates', True):
        sources = state.birth_sources
        if sources is not None and len(sources):
            assert torch.equal(raw['rotation'][-len(sources):], raw['rotation'][sources])
        row['new_orientation_inherited'] = True
    checkpoint = run / f'rigid-ckpt-{frame}-200.pth'
    if checkpoint.exists():
        saved, _ = _capture_raw(checkpoint, frame, 200)
        assert all(torch.equal(raw[key], saved[key]) for key in raw)
        row['raw_checkpoint_exact'] = True
    rows.append(row)
    del view
assert hashlib.sha256(source.read_bytes()).hexdigest() == status['source_sha256']
result = dict(complete=True, run=str(run), reference_matches_source=True,
    source_unchanged=True, snapshot_hashes_verified=True, bootstrap=bootstrap_quality,
    frames=rows, gpu_check=gpu,
    timing_scope='50 materialized renders after10 warmups; excludes decode/upload')
(run / 'independent_verification.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(dict(complete=True, frames=len(rows), bootstrap=bootstrap_quality,
    mean_psnr=sum(r['quality']['psnr'] for r in rows)/len(rows),
    mean_bytes=sum(r['complete_update_bytes'] for r in rows)/len(rows),
    mean_fps=sum(r['pure_fps'] for r in rows)/len(rows),
    max_psnr_difference=max(abs(r['quality_saved_difference']['psnr']) for r in rows),
    cache_max_pixel_difference=max(r['cache_pixel_max_abs_difference'] for r in rows)), indent=2))
