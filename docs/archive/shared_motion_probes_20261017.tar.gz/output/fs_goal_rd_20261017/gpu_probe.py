"""Bounded train/replay probe; resume the existing full run even on failure."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument('--config',type=Path,required=True)
parser.add_argument('--checkpoint',type=Path)
parser.add_argument('--name',required=True)
parser.add_argument('--frames',type=int,default=3)
parser.add_argument('--verify',action='store_true')
args = parser.parse_args()
out = Path(__file__).resolve().parent
root = out.parents[1]
assert not (out/args.name).exists(), 'Use a new experiment name'
main_pid = 585411
command = Path(f'/proc/{main_pid}/cmdline').read_bytes()
assert b'extend_prefix.py' in command and b'all_rotation_off_quant6_full300' in command
state = Path(f'/proc/{main_pid}/stat').read_text().rsplit(')',1)[1].split()[0]
assert state not in ('T','t','Z')
record = dict(main_pid=main_pid,config=str(args.config),
    source=None if args.checkpoint is None else str(args.checkpoint),
    scope='short GPU probe; full-run recipe unchanged',complete=False,
    started_utc=datetime.now(timezone.utc).isoformat())
path = out/f'{args.name}_schedule.json'
def save():
    path.write_text(json.dumps(record,indent=2)+'\n')
save()
started = time.perf_counter()
os.kill(main_pid,signal.SIGSTOP)
try:
    command = [sys.executable,str(out/'run_window.py'),'--config',str(args.config.resolve()),
               '--frames',str(args.frames),'--name',args.name,'--opacity-prox']
    if args.checkpoint is not None:
        command += ['--checkpoint',str(args.checkpoint.resolve())]
    with (out/f'{args.name}.log').open('w') as log:
        child = subprocess.Popen(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
        record['probe_pid']=child.pid;save()
        record['probe_exit_code']=child.wait()
    if record['probe_exit_code']==0 and args.verify:
        statuses = list((out/args.name).glob('*/window_status.json'))
        assert len(statuses)==1
        run = statuses[0].parent
        with (out/f'{args.name}_verify.log').open('w') as log:
            child = subprocess.Popen([sys.executable,str(out/'verify_window.py'),str(run)],
                cwd=root,stdout=log,stderr=subprocess.STDOUT)
            record['verification_pid']=child.pid;save()
            record['verification_exit_code']=child.wait()
finally:
    os.kill(main_pid,signal.SIGCONT)
    record.update(main_resumed=True,paused_seconds=time.perf_counter()-started,
        resumed_utc=datetime.now(timezone.utc).isoformat(),complete=True)
    save()
print(json.dumps(record,indent=2))
