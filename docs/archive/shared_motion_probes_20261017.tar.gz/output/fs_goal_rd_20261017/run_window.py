"""Frozen-code bounded training with explicit checkpoint migration.

The snapshot imports its own Python and shares only the unchanged CUDA source
directory. Dataset paths stay absolute symlinks; no large data is copied.
"""
import argparse
import copy
from dataclasses import asdict,fields
from datetime import datetime
import hashlib
import json
from pathlib import Path
import shutil
import sys
import time

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--config',type=Path,default=ROOT/'config/fs_ste_sparse_tralpha_rate003_full300_20261017.yaml')
parser.add_argument('--checkpoint',type=Path)
parser.add_argument('--frames',type=int,default=3)
parser.add_argument('--name',required=True)
parser.add_argument('--opacity-prox',action='store_true')
parser.add_argument('--views',type=int)
args=parser.parse_args()
assert 1<=args.frames<=299
stamp=datetime.now().strftime('%Y%m%dT%H%M%S_%f')
snapshot=OUT/'runtime_sources'/f'{args.name}_{stamp}'
hashes={}
for folder in ('pipeline','scripts','tests'):
    for source in (ROOT/folder).rglob('*.py'):
        if source.is_symlink():continue
        rel=source.relative_to(ROOT)
        dest=snapshot/rel;dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,dest)
        hashes[str(rel)]=hashlib.sha256(source.read_bytes()).hexdigest()
(snapshot/'extensions').symlink_to(ROOT/'extensions',target_is_directory=True)
(snapshot/'source_manifest.json').write_text(json.dumps(hashes,indent=2)+'\n')
sys.path.insert(0,str(snapshot))
import torch
from omegaconf import OmegaConf
from libgs.utils.config import to_structured
from pipeline.entry import Config,Pipeline
from pipeline.model.sparse_updates import QuantizedOpacityUpdate
from scripts.benchmark_rigid_residual_tree import _load_config,check_gpu_exclusivity

check_gpu_exclusivity()
target,extra=to_structured(OmegaConf.load(args.config),Config);assert not extra,extra
target.module.opacity_update.proximal_regularization=args.opacity_prox
if args.views is not None:target.trainer.motion_views_per_step=args.views
source=Path(target.ckpt_path if args.checkpoint is None else args.checkpoint).resolve()
is_dynamic='rigid-ckpt-' in source.name
cfg=_load_config(source.parent) if is_dynamic else copy.deepcopy(target)
cfg.output_dir=OUT
cfg.experiment_name=args.name
cfg.ckpt_path=source
cfg.resume_prefix_dir=None
cfg.resume_completed_prefix_frames=None
pipeline=Pipeline(cfg)
trainer,module=pipeline.trainer,pipeline.module
trainer.setup(module,source)
old_config=asdict(module.config)
if is_dynamic:
    assert module.frame_finalized
    # Restore against the saved recipe first. Only then migrate the next
    # frame's optimizer/configuration; the preceding decoded GS stay exact.
    if target.module.rigid_tree.spatial_gate.region_motion!='absolute':
        raise ValueError('This bounded runner expects the validated absolute baseline')
    for field in fields(target.module.rigid_tree):
        setattr(cfg.module.rigid_tree,field.name,copy.deepcopy(getattr(target.module.rigid_tree,field.name)))
    cfg.module.birth=copy.deepcopy(target.module.birth)
    cfg.module.opacity_update=copy.deepcopy(target.module.opacity_update)
    module.opacity_update=QuantizedOpacityUpdate(cfg.module.opacity_update)
    if trainer._resume_rng is not None:trainer._restore_rng(trainer._resume_rng)
    trainer._resume_rng=None
    start=module.current_frame+1
    module.begin_next_frame()
else:
    assert trainer.is_first_frame
    start=1
end=min(start+args.frames,300)
trainer.global_step=0
cfg.trainer.motion_views_per_step=target.trainer.motion_views_per_step
cfg.trainer.saving_ckpt_frames=sorted(set([start,end-1]+[f for f in (9,29,59,89,119,149,179,209,239,269,299) if start<=f<end]))
cfg.trainer.saving_ckpt_steps=[70,100,200]
cfg.module.rigid_tree.validate();cfg.module.opacity_update.validate()
pipeline.save_config()
status=dict(complete=False,name=args.name,output=str(pipeline.output_dir),start=start,end=end-1,
    source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    runtime_source=str(snapshot),source_hashes=hashes,source_module_config=old_config,
    effective_module_config=asdict(module.config),results=[])
path=pipeline.output_dir/'window_status.json'
def save():
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(status,indent=2,default=str)+'\n');tmp.replace(path)
save()
started=time.perf_counter()
try:
    for frame in range(start,end):
        trainer.datamodule.current_frame=frame
        row=trainer.frame_training_loop()
        manifest=pipeline.output_dir/'frame_storage/rigid_tree'/f'frame_{frame:03d}.json'
        status['results'].append(dict(frame=frame,psnr=row['evaluation']['test']['psnr'],
            ssim=row['evaluation']['test']['ssim'],full_bytes=row['encoded_bytes']+manifest.stat().st_size,
            motion_bytes=row['motion']['bytes'],opacity_bytes=(row.get('opacity_update') or {}).get('archive_bytes',0),
            birth_bytes=(row.get('birth') or {}).get('archive_bytes',0),regions=row['region_count'],
            gs_rows=row['motion_rate_diagnostics']['gs_active_rows'],gs_t=row['motion_rate_diagnostics']['gs_translation_active_blocks'],
            gs_r=row['motion_rate_diagnostics']['gs_rotation_active_blocks'],count=row['total_count'],
            birth_count=row['birth_count'],old_count=row['old_count'],seconds=row['elapsed_seconds']))
        save()
        if frame+1<end:
            module.begin_next_frame();trainer.global_step=0
    status.update(complete=True,seconds=time.perf_counter()-started,
        source_unchanged=hashlib.sha256(source.read_bytes()).hexdigest()==status['source_sha256'])
except BaseException as exc:
    status['error']=repr(exc);raise
finally:
    save()
    if trainer.tb_writer is not None:trainer.tb_writer.close()
print(json.dumps({k:status[k] for k in ('complete','output','start','end','seconds','results')},indent=2))
