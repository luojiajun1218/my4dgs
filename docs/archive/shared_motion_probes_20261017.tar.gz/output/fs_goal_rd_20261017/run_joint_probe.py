"""Run one matched GPU probe, resuming the full experiment in finally."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

out = Path(__file__).resolve().parent
root = out.parents[1]
main_pid = 585411
command = Path(f'/proc/{main_pid}/cmdline').read_bytes()
assert b'extend_prefix.py' in command and b'all_rotation_off_quant6_full300' in command
state = Path(f'/proc/{main_pid}/stat').read_text().rsplit(')', 1)[1].split()[0]
assert state not in ('T','t','Z')
active = json.loads((out/'active_run.json').read_text())
source = root/active['run']/'rigid-ckpt-59-200.pth'
record = dict(main_pid=main_pid,source=str(source),scope='GPU scheduling only; full recipe unchanged',
              started_utc=datetime.now(timezone.utc).isoformat(),complete=False)
path = out/'joint_probe_schedule.json'
def save():
    path.write_text(json.dumps(record,indent=2)+'\n')
save()
started = time.perf_counter()
os.kill(main_pid, signal.SIGSTOP)
try:
    with (out/'joint_image_raw_alpha_norot_late60_62.log').open('w') as log:
        child = subprocess.Popen([sys.executable,str(out/'run_window.py'),
            '--config',str(out/'joint_image_raw_alpha_norot.yaml'),
            '--checkpoint',str(source),'--frames','3',
            '--name','joint_image_raw_alpha_norot_late60_62','--opacity-prox'],
            cwd=root,stdout=log,stderr=subprocess.STDOUT)
        record['probe_pid']=child.pid;save()
        record['probe_exit_code']=child.wait()
finally:
    os.kill(main_pid,signal.SIGCONT)
    record.update(main_resumed=True,paused_seconds=time.perf_counter()-started,
        resumed_utc=datetime.now(timezone.utc).isoformat(),complete=True)
    save()
print(json.dumps(record,indent=2))
