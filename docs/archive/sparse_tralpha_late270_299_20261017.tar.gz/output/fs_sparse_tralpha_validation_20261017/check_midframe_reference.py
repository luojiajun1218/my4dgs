"""Check actual step100 checkpoint reconstructs its pre-update reference."""
from pathlib import Path
import json
import sys
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import numpy as np
import torch
from pipeline.trainer import Trainer
from pipeline.model.birth_quantization import RAW_FIELDS, RAW_ATTRIBUTES, reference_digest
from pipeline.model.rigid_tree_codec import DecodedState
from scripts.benchmark_rigid_residual_tree import CAPTURE_INDEX
from scripts.replay_rigid_tree import replay

OUT = Path(__file__).resolve().parent
status = json.loads((OUT/'late_window_status.json').read_text())
run = Path(status['output'])
torch.set_num_threads(2)
checkpoint = torch.load(run/'rigid-ckpt-279-100.pth', map_location='cpu', weights_only=False)
raw = {name:checkpoint['gaussians'][index] for name,index in CAPTURE_INDEX.items()}
model = SimpleNamespace(**{attr:raw[name] for name,attr in zip(RAW_FIELDS, RAW_ATTRIBUTES)})
motion = checkpoint['rigid_tree_motion']
state = DecodedState.restore(motion['codec_previous_state'])
assert state.frame_index == 278
holder = SimpleNamespace(gaussians=model, frame_finalized=False,
    retired_reference=checkpoint['rigid_tree_retired_reference'],
    opacity_update=SimpleNamespace(reference=checkpoint['quantized_opacity_update']['reference']),
    motion=SimpleNamespace(previous_rows=motion['tensors']['previous_rows']),
    initial_reference=checkpoint['rigid_tree_initial_reference'])
worker = SimpleNamespace(output_dir=OUT/'midframe_reference', module=holder,
    datamodule=SimpleNamespace(cameras_extent=motion['extent']))
Trainer._write_reference(worker, 278, state)
stream = run/'frame_storage/rigid_tree'
expected_state, expected = replay(stream, stream/'reference_frame269.npz', 278)
with np.load(worker.decoder_reference_path) as packet:
    rebuilt = {name:torch.from_numpy(packet[name].copy()) for name in raw}
assert state.digest() == expected_state.digest()
assert all(torch.equal(rebuilt[name], expected[name]) for name in raw)
result = dict(checkpoint=str(run/'rigid-ckpt-279-100.pth'), reference=str(worker.decoder_reference_path),
    reference_frame=278, raw_matches_independent_prior_replay=True,
    prior_count=len(state.xyz), retained_count=len(raw['xyz']),
    retired_count=len(state.xyz)-len(raw['xyz']), raw_sha256=reference_digest(rebuilt))
(OUT/'midframe_reference_check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
