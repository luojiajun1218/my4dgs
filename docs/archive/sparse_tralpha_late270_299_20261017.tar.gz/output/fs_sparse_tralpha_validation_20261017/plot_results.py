from pathlib import Path
import csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
rows=list(csv.DictReader((OUT/'per_frame_comparison.csv').open()))
old=[row for row in rows if row['case']=='historical']
new=[row for row in rows if row['case']=='sparse_tralpha']
x=[int(row['frame']) for row in new]
fig,axes=plt.subplots(3,1,figsize=(10.4,8.4),sharex=True)
gray='#757575';teal='#087e8b';orange='#df9748'
for group,color,label in [(old,gray,'Previous method'),(new,teal,'Sparse T/R/opacity')]:
    axes[0].plot(x,[float(row['psnr']) for row in group],color=color,lw=1.8,label=label)
    axes[1].plot(x,[float(row['complete_update_bytes'])/1000 for row in group],color=color,lw=1.8,label=label)
    axes[2].plot(x,[int(row['total_count'])/1000 for row in group],color=color,lw=1.8,label=label)
total=[float(row['complete_update_bytes'])/1000 for row in new]
without_alpha=[(float(row['complete_update_bytes'])-float(row['opacity_bytes']))/1000 for row in new]
axes[1].fill_between(x,without_alpha,total,color=orange,alpha=.3,label='Opacity packet share')
axes[0].set_ylabel('Held-out PSNR (dB)')
axes[1].set_ylabel('Complete update (KB)')
axes[2].set_ylabel('GS count (thousands)')
axes[2].set_xlabel('Frame')
for ax in axes:
    ax.grid(alpha=.22)
    ax.spines[['top','right']].set_visible(False)
    ax.legend(loc='best',frameon=False,fontsize=9)
fig.suptitle('Quantized sparse T/R/opacity: continuation on frames 270–299',fontsize=13)
fig.tight_layout(rect=(0,0,1,.96))
path=ROOT/'docs/experiment/figures/20261017_sparse_tralpha_late270_299.png'
fig.savefig(path,dpi=180,bbox_inches='tight')
print(path)
