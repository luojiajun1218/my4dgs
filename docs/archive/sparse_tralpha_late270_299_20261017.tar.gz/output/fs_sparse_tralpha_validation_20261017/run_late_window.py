"""Explicitly migrate a finalized old frame269 into the new method for 270–299."""
from pathlib import Path
from dataclasses import asdict
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import torch
from omegaconf import OmegaConf
from pipeline.entry import Pipeline
from pipeline.model.sparse_updates import OpacityUpdateConfig, QuantizedOpacityUpdate
from scripts.benchmark_rigid_residual_tree import _load_config, check_gpu_exclusivity

OUT = Path(__file__).resolve().parent
OLD = ROOT/'output/fs_ste_depth4_rate003_full300_20261017/20261017T022827_f74b2a'
check_gpu_exclusivity()
cfg = _load_config(OLD)
cfg.output_dir = OUT
cfg.experiment_name = 'late270_299'
cfg.ckpt_path = OLD/'rigid-ckpt-269-200.pth'
pipeline = Pipeline(cfg)
trainer, module = pipeline.trainer, pipeline.module
# First restore against the original configuration. Migration is explicit and
# recorded below, rather than bypassing checkpoint compatibility checks.
trainer.setup(module, cfg.ckpt_path)
assert module.frame_finalized and module.current_frame == 269 and trainer.global_step == 200
source_config = asdict(module.config)
cfg.module.rigid_tree.differentiable_rate_support = True
cfg.module.rigid_tree.sparse_rate_width_bins = 1.
cfg.module.birth.replace_low_opacity = False
cfg.module.opacity_update = OpacityUpdateConfig(enabled=True, step=.05,
    learning_rate=.05, prune_threshold=.01)
module.opacity_update = QuantizedOpacityUpdate(cfg.module.opacity_update)
assert module.motion.config is cfg.module.rigid_tree
trainer.config.saving_ckpt_frames = [270, 279, 299]
pipeline.save_config()
status = dict(scope='Late-window migration only, shared old frame269; not a fresh full300 run.',
    source_run=str(OLD), source_checkpoint=str(cfg.ckpt_path), output=str(pipeline.output_dir),
    first_trained_frame=270, last_trained_frame=299, source_module_config=source_config,
    effective_module_config=asdict(module.config), opacity_retirement=[], complete=False)


def save_status():
    temporary = OUT/'late_window_status.tmp'
    temporary.write_text(json.dumps(status, indent=2,
        default=lambda value: OmegaConf.to_container(value, resolve=True)
            if OmegaConf.is_config(value) else str(value))+'\n')
    temporary.replace(OUT/'late_window_status.json')


original_commit = module._commit_opacity_and_retire
@torch.no_grad()
def commit():
    update = module.opacity_update
    before = update.reference.detach().cpu().sigmoid().flatten()
    after = update.canonical_logits(full=True).sigmoid().flatten()
    remove = after < module.config.opacity_update.prune_threshold
    record = dict(frame=module.current_frame, original_count=len(before),
        below_threshold_before=int((before < .01).sum()), retired=int(remove.sum()),
        retired_previously_alpha_ge_05=int((remove & before.ge(.5)).sum()),
        retired_previously_alpha_ge_09=int((remove & before.ge(.9)).sum()),
        full_opacity_nonzero_updates=int(update.symbols().ne(0).sum()))
    original_commit()
    record['surviving_opacity_nonzero_updates'] = int(update.symbols()[update.rows].ne(0).sum())
    module.birth_control['opacity_retirement_diagnostics'] = record
    status['opacity_retirement'].append(record)
    save_status()
module._commit_opacity_and_retire = commit

original_post = module.post_training_step
def post(package):
    if module.current_frame == 270 and trainer.global_step == 20:
        motion = module.motion
        terms = motion.loss_terms(20, diagnostics=False)
        opacity = module.opacity_update.rate_terms(module._rate_byte_price(20),
            width=module.config.rigid_tree.sparse_rate_width_bins)
        parameters = [motion.region_translation, motion.region_rotation,
                      motion.gs_translation, motion.gs_rotation, module.opacity_update.delta]
        names = ['region_translation', 'region_rotation', 'gs_translation', 'gs_rotation', 'opacity_delta']
        gradients = torch.autograd.grad(terms['rate_loss'] + opacity['loss'], parameters, allow_unused=True)
        status['live_rate_gradients_step20'] = {name: None if gradient is None else
            dict(nonzero=int(gradient.ne(0).sum()), abs_sum=float(gradient.abs().sum()))
            for name, gradient in zip(names, gradients)}
        save_status()
    return original_post(package)
module.post_training_step = post
save_status()
started = time.perf_counter()
try:
    reports = trainer.training_loop()
    assert [report['frame'] for report in reports] == list(range(270, 300))
    status.update(complete=True, seconds=time.perf_counter() - started,
                  trained_frames=len(reports), final_count=reports[-1]['total_count'])
except BaseException as error:
    status['error'] = repr(error)
    raise
finally:
    save_status()
    if trainer.tb_writer is not None:
        trainer.tb_writer.close()
print(json.dumps({key: value for key, value in status.items() if key not in [
    'source_module_config', 'effective_module_config', 'opacity_retirement']}, indent=2))
