"""Resume after materializing/pruning old opacity and replay the new packet."""
from pathlib import Path
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import torch
from pipeline.entry import Pipeline
from scripts.benchmark_rigid_residual_tree import _load_config, _capture_raw, check_gpu_exclusivity
from scripts.replay_rigid_tree import replay

OUT = Path(__file__).resolve().parent
status = json.loads((OUT/'late_window_status.json').read_text())
assert status['complete']
run = Path(status['output'])
check_gpu_exclusivity()
cfg = _load_config(run)
cfg.output_dir = OUT
cfg.experiment_name = 'resume279_step100'
cfg.ckpt_path = run/'rigid-ckpt-279-100.pth'
pipeline = Pipeline(cfg)
trainer, module = pipeline.trainer, pipeline.module
trainer.setup(module, cfg.ckpt_path)
pipeline.save_config()
retired = dict(module.birth_control['retirement'])
count = len(module.gaussians._xyz)
start = time.perf_counter()
report = trainer.frame_training_loop()
assert report['train_loss_steps'] == 100
assert len(module.motion.owner) == count == report['old_count']
assert report['birth_control']['retirement'] == retired
stream = pipeline.output_dir/'frame_storage/rigid_tree'
state, raw = replay(stream, trainer.decoder_reference_path, 279)
saved, _ = _capture_raw(pipeline.output_dir/'rigid-ckpt-279-200.pth', 279, 200)
assert all(torch.equal(raw[name], saved[name]) for name in raw)
original = json.loads((run/'frame_summary/frame_279.json').read_text())
result = dict(source_checkpoint=str(cfg.ckpt_path), output=str(pipeline.output_dir),
    seconds=time.perf_counter()-start, resumed_steps=100,
    retirement_not_repeated=True, independent_raw_exact=True,
    old_count=count, retired_count=report['retired_count'],
    reference_frame=278, final_frame=state.frame_index,
    test=report['evaluation']['test'], original_test=original['evaluation']['test'],
    psnr_difference=report['evaluation']['test']['psnr']-original['evaluation']['test']['psnr'],
    births=report['birth_count'], original_births=original['birth_count'],
    opacity_bytes=report['opacity_update']['archive_bytes'] if report['opacity_update'] else 0)
(OUT/'resume_audit.json').write_text(json.dumps(result,indent=2)+'\n')
if trainer.tb_writer is not None:
    trainer.tb_writer.close()
print(json.dumps(result,indent=2))
