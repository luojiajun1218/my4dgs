"""Same-window quality and actual encoded bytes, including old-opacity packets."""
from pathlib import Path
import csv
import hashlib
import json
import statistics
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from scripts.benchmark_rigid_residual_tree import summarize_render_frames

OUT = Path(__file__).resolve().parent
status = json.loads((OUT/'late_window_status.json').read_text())
assert status['complete']
NEW = Path(status['output'])
OLD = Path(status['source_run'])
rows = []
cases = {}
for tag, run in [('historical', OLD), ('sparse_tralpha', NEW)]:
    entries = []
    for frame in range(270, 300):
        report = json.loads((run/'frame_summary'/f'frame_{frame:03d}.json').read_text())
        stream = run/'frame_storage/rigid_tree'
        path = stream/f'frame_{frame:03d}.json'
        manifest = json.loads(path.read_text())
        motion_bytes = (stream/manifest['motion']).stat().st_size
        birth_bytes = (stream/manifest['birth']).stat().st_size if manifest['birth'] else 0
        alpha_bytes = (stream/manifest['opacity_update']).stat().st_size if manifest.get('opacity_update') else 0
        assert report['encoded_bytes'] == motion_bytes + birth_bytes + alpha_bytes
        if tag == 'sparse_tralpha':
            assert manifest['opacity_update_timing'] == 'before_births'
            assert report['old_count'] + report['birth_count'] == report['total_count']
            assert report['previous_count'] - report['retired_count'] == report['old_count']
        diag = report['motion_rate_diagnostics']
        row = dict(case=tag, frame=frame,
            psnr=report['evaluation']['test']['psnr'], ssim=report['evaluation']['test']['ssim'],
            lpips=report['evaluation']['test']['lpips'], motion_bytes=motion_bytes,
            birth_bytes=birth_bytes, opacity_bytes=alpha_bytes, manifest_bytes=path.stat().st_size,
            payload_bytes=report['encoded_bytes'],
            complete_update_bytes=report['encoded_bytes'] + path.stat().st_size,
            old_count=report['old_count'], birth_count=report['birth_count'],
            total_count=report['total_count'], retired_count=report.get('retired_count', 0),
            region_count=report['region_count'], gs_active_rows=diag['gs_active_rows'],
            translation_blocks=diag['gs_translation_active_blocks'],
            rotation_blocks=diag['gs_rotation_active_blocks'],
            opacity_updates=report['opacity_update']['rows'] if report.get('opacity_update') else 0,
            elapsed_seconds=report['elapsed_seconds'])
        entries.append(row)
    rows += entries
    mean_fields = ['psnr','ssim','lpips','motion_bytes','birth_bytes','opacity_bytes','manifest_bytes',
        'payload_bytes','complete_update_bytes','region_count','gs_active_rows','translation_blocks',
        'rotation_blocks','opacity_updates','elapsed_seconds']
    cases[tag] = dict(run=str(run), trained_frames=30,
        means={name:statistics.mean(row[name] for row in entries) for name in mean_fields},
        total_births=sum(row['birth_count'] for row in entries),
        total_retired=sum(row['retired_count'] for row in entries),
        first_frame=entries[0], last_frame=entries[-1])
old = cases['historical']['means']
new = cases['sparse_tralpha']['means']
retired = status['opacity_retirement']
result = dict(scope=status['scope'], cases=cases,
    delta_means={key:new[key]-old[key] for key in new},
    complete_update_reduction_percent=100*(1-new['complete_update_bytes']/old['complete_update_bytes']),
    current_alpha_retirement=dict(total=sum(row['retired'] for row in retired),
        previously_alpha_ge_05=sum(row['retired_previously_alpha_ge_05'] for row in retired),
        previously_alpha_ge_09=sum(row['retired_previously_alpha_ge_09'] for row in retired)),
    live_rate_gradients_step20=status['live_rate_gradients_step20'])
benchmark = OUT/'late_benchmark.json'
if benchmark.exists():
    measured = json.loads(benchmark.read_text())
    baseline = json.loads((ROOT/'output/fs_ste_rate_sweep_full300_20261017/rate003_benchmark.json').read_text())
    result['new_render_summary'] = measured['render_summary']
    result['old_same_window_render_summary'] = summarize_render_frames(baseline['frames'][270:300])
    result['verification'] = {name:measured[name] for name in ['measured_frames',
        'bootstrap_raw_matches_source_checkpoint','final_raw_matches_checkpoint',
        'max_cache_pixel_difference','max_quality_difference']}
    result['source269_cohort'] = measured['source269_cohort']
with (OUT/'per_frame_comparison.csv').open('w') as file:
    writer = csv.DictWriter(file, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
(OUT/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
