"""Plot same-window quality and real, equally lossless-coded update bytes."""
from pathlib import Path
import csv

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
rows=list(csv.DictReader((OUT/'per_frame_comparison.csv').open()))
fig,axes=plt.subplots(1,2,figsize=(11.5,3.6),layout='constrained')
for name,label,color in [('previous','Previous sparse T/R/alpha','#a15931'),
                         ('proximal','Photometric Adam + proximal GS','#216aa6')]:
    selected=[r for r in rows if r['case']==name]
    x=[int(r['frame']) for r in selected]
    axes[0].plot(x,[float(r['psnr']) for r in selected],label=label,color=color,lw=1.7)
    axes[1].plot(x,[float(r['complete_bytes'])/1000 for r in selected],label=label,color=color,lw=1.7)
axes[0].set_ylabel('PSNR (dB)')
axes[1].set_ylabel('Complete update (KB, 1000 B)')
axes[0].set_title('Same starting state: frame 269')
axes[1].set_title('Both methods use the lossless integer codec')
for ax in axes:
    ax.set_xlabel('Frame')
    ax.grid(alpha=.2)
    ax.spines[['top','right']].set_visible(False)
axes[1].legend(fontsize=8,loc='upper right')
path=ROOT/'docs/experiment/figures/20261017_proximal_gs_late270_299.png'
fig.savefig(path,dpi=160)
print(path)
