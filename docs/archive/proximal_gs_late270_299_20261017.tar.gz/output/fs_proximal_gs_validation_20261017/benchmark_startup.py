"""Independent first-frame bootstrap, two-frame decode and image validation."""
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
import torch
from scripts.benchmark_rigid_residual_tree import (_load_config,_make_module,_load_reference,
    _decode_frame,_validate_stream_manifest,_install_raw,_cam00,_sequence_quality,
    _capture_raw,check_gpu_exclusivity)

OUT=Path(__file__).resolve().parent
status=json.loads((OUT/'startup.json').read_text());assert status['complete']
run=Path(status['output']);stream=run/'frame_storage/rigid_tree'
reference=stream/'reference_frame0.npz'
device=torch.device('cuda');torch.set_num_threads(2);check_gpu_exclusivity()
config=_load_config(run);module,data=_make_module(config,device)
state,raw=_load_reference(reference,None)
baseline=ROOT/'output/fs_ste_depth4_rate003_full300_20261017/20261017T022827_f74b2a/frame_storage/rigid_tree/reference_frame0.npz'
base_state,base_raw=_load_reference(baseline,None)
assert state.digest()==base_state.digest()
assert all(raw[k].numpy().tobytes()==base_raw[k].numpy().tobytes() for k in raw)
relative_reference=json.loads((stream/'frame_001.json').read_text())['reference']
rows=[]
for frame in [1,2]:
    state,raw=_decode_frame(stream,frame,state,raw)
    _validate_stream_manifest(stream,frame,state,raw,relative_reference)
    _install_raw(module,raw,device)
    view,_=_cam00(data,frame,device)
    summary=json.loads((run/f'frame_summary/frame_{frame:03d}.json').read_text())
    quality,difference,cache_difference=_sequence_quality(module,view,summary['evaluation']['test'],
        dict(psnr=1e-4,ssim=1e-6,l1=1e-6),True)
    rows.append(dict(frame=frame,quality=quality,saved_difference=difference,cache_difference=cache_difference))
saved,_=_capture_raw(run/'rigid-ckpt-2-200.pth',2,200)
assert all(saved[k].numpy().tobytes()==raw[k].numpy().tobytes() for k in raw)
result=dict(complete=True,frames=rows,initial_reference_matches_historical=True,
    final_raw_matches_checkpoint=True,no_full300_run=True)
(OUT/'startup_benchmark.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
