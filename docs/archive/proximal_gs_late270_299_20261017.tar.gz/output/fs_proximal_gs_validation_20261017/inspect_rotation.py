"""Continuous-bin and Adam-moment diagnostics from completed checkpoints."""
from pathlib import Path
import json
import math
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
import torch

torch.set_num_threads(2)
OUT=Path(__file__).resolve().parent
status=json.loads((OUT/'late_window_status.json').read_text())
assert status['complete']
new=Path(status['output'])
base=Path(json.loads((ROOT/'output/fs_sparse_tralpha_validation_20261017/comparison.json').read_text())['cases']['sparse_tralpha']['run'])
rows=[]
for tag,run in [('previous',base),('proximal',new)]:
    for frame in [270,279,299]:
        checkpoint=torch.load(run/f'rigid-ckpt-{frame}-100.pth',map_location='cpu',weights_only=False)
        motion=checkpoint['rigid_tree_motion']
        values=motion['parameters']['gs_rotation']
        step=motion['config']['gs_rotation_step_rad']
        bins=values/step
        symbols=bins.round()
        norms=symbols.abs().sum(-1)
        active=norms.gt(0)
        single=norms.eq(1)
        selected=bins[single][symbols[single].ne(0)].abs()
        group=motion['optimizer']['param_groups'][3]
        adam=motion['optimizer']['state'][group['params'][0]]
        variance=adam['exp_avg_sq']/(1-motion['config']['adam_betas'][1]**int(adam['step']))
        metrics=variance.sqrt()
        row=dict(case=tag,frame=frame,old_count=len(values),active_rotation_blocks=int(active.sum()),
            exact_zero_parameter_blocks=int(values.eq(0).all(-1).sum()),single_bin_blocks=int(single.sum()),
            single_bin_near_half=int((selected-.5).le(.01).sum()),
            single_bin_abs_median=float(selected.median()) if len(selected) else None,
            data_or_mixed_gradient_rms_median=float(metrics[active].median()) if bool(active.any()) else None,
            adam_learning_rate=group['lr'],proximal_gs_regularization=motion['config'].get('proximal_gs_regularization',False))
        rows.append(row)
        print(json.dumps(row),flush=True)
(OUT/'rotation.json').write_text(json.dumps(dict(scope='Checkpoint diagnostics only; old moments include regularization, new GS moments are photometric-only.',frames=rows),indent=2)+'\n')
