"""Compare the new fitted window with the already-completed alpha method."""
from pathlib import Path
import csv
import json
import statistics
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
OUT=Path(__file__).resolve().parent
status=json.loads((OUT/'late_window_status.json').read_text())
assert status['complete']
run=Path(status['output'])
baseline=json.loads((ROOT/'output/fs_sparse_tralpha_validation_20261017/comparison.json').read_text())
original=Path(baseline['cases']['sparse_tralpha']['run'])
recoded=ROOT/'output/fs_lossless_gate_rotation_validation_20261017/reencoded270_299/frame_storage/rigid_tree'
cases={}
all_rows=[]
for tag,folder,stream in [('previous',original,recoded),('proximal',run,run/'frame_storage/rigid_tree')]:
    rows=[]
    for frame in range(270,300):
        report=json.loads((folder/f'frame_summary/frame_{frame:03d}.json').read_text())
        manifest_path=stream/f'frame_{frame:03d}.json'
        manifest=json.loads(manifest_path.read_text())
        motion=(stream/manifest['motion']).stat().st_size
        alpha=(stream/manifest['opacity_update']).stat().st_size if manifest.get('opacity_update') else 0
        birth=(stream/manifest['birth']).stat().st_size if manifest.get('birth') else 0
        d=report['motion_rate_diagnostics']
        row=dict(case=tag,frame=frame,psnr=report['evaluation']['test']['psnr'],
            ssim=report['evaluation']['test']['ssim'],lpips=report['evaluation']['test']['lpips'],
            motion_bytes=motion,opacity_bytes=alpha,birth_bytes=birth,
            complete_bytes=motion+alpha+birth+manifest_path.stat().st_size,
            region_count=report['region_count'],gs_active_rows=d['gs_active_rows'],
            translation_blocks=d['gs_translation_active_blocks'],rotation_blocks=d['gs_rotation_active_blocks'],
            opacity_rows=report['opacity_update']['rows'] if report.get('opacity_update') else 0,
            old_count=report['old_count'],total_count=report['total_count'],
            births=report['birth_count'],retired=report['retired_count'],elapsed_seconds=report['elapsed_seconds'])
        rows.append(row)
    all_rows+=rows
    cases[tag]=dict(run=str(folder),stream=str(stream),
        means={name:statistics.mean(r[name] for r in rows) for name in rows[0] if name not in ['case','frame']},
        first=rows[0],last=rows[-1],total_births=sum(r['births'] for r in rows),total_retired=sum(r['retired'] for r in rows))
a,b=cases['previous']['means'],cases['proximal']['means']
result=dict(scope=status['scope'],cases=cases,
    delta_means={name:b[name]-a[name] for name in a},
    storage_reduction_percent=100*(1-b['complete_bytes']/a['complete_bytes']),
    source_module_config=status['source_module_config'],effective_module_config=status['effective_module_config'])
benchmark=OUT/'late_benchmark.json'
if benchmark.exists():
    measured=json.loads(benchmark.read_text())
    result['verification']={name:measured[name] for name in ['measured_frames','bootstrap_raw_matches_source_checkpoint',
        'final_raw_matches_checkpoint','max_cache_pixel_difference','max_quality_difference']}
    result['render_summary']=measured['render_summary']
    result['previous_render_summary']=baseline['new_render_summary']
with (OUT/'per_frame_comparison.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(all_rows[0]));writer.writeheader();writer.writerows(all_rows)
(OUT/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key not in ['source_module_config','effective_module_config']},indent=2))
