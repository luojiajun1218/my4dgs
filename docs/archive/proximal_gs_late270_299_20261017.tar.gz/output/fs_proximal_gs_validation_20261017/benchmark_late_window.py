"""Verify and time each independently decoded frame270–299 from reference269."""
from pathlib import Path
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import torch
from pipeline.model import rigid_tree_codec as motion_codec
from scripts.benchmark_rigid_residual_tree import (
    _load_config, _make_module, _load_reference, _decode_frame, _install_raw,
    _cam00, _sequence_quality, _time_sequence_render, _validate_stream_manifest,
    _actual_frame_storage, _summarize_storage, summarize_render_frames,
    _capture_raw, check_gpu_exclusivity)

OUT = Path(__file__).resolve().parent
status = json.loads((OUT/'late_window_status.json').read_text())
assert status['complete'] and status['trained_frames'] == 30
run = Path(status['output'])
stream = run/'frame_storage/rigid_tree'
reference = stream/'reference_frame269.npz'
device = torch.device('cuda')
torch.set_num_threads(2)
checks = [check_gpu_exclusivity()]
cfg = _load_config(run)
module, data = _make_module(cfg, device)
state, raw = _load_reference(reference, None)
assert state.frame_index == 269
saved_raw, _ = _capture_raw(Path(status['source_checkpoint']), 269, 200)
assert all(torch.equal(raw[name], saved_raw[name]) for name in raw)
origin_ids = torch.arange(len(raw['xyz']))
origin_alpha = raw['opacity'].sigmoid().flatten()
origin_retirement = []
relative_reference = json.loads((stream/'frame_270.json').read_text())['reference']
tolerance = dict(psnr=1e-4, ssim=1e-6, l1=1e-6)
rows = []
for frame in range(270, 300):
    started = time.perf_counter()
    state, raw = _decode_frame(stream, frame, state, raw)
    kept = state.survivor_rows
    packet_raw = motion_codec.uncompressed_motion_packet((stream/f'motion_{frame:03d}.bin').read_bytes())
    reader = motion_codec._Reader(packet_raw)
    reader.take(36)
    index, regions, old_count, births = [reader.integer() for _ in range(4)]
    reader.take(40)
    if reader.take(1)[0]:
        deleted_count = reader.integer()
        for _ in range(deleted_count): reader.integer()
    assert reader.integer() == 0
    reader.take((regions+7)//8)
    rt, rr = motion_codec._sparse_read(reader, regions-1, delta_rows=True)
    rt = torch.cat((torch.zeros(1,3,dtype=torch.int16),rt))
    rr = torch.cat((torch.zeros(1,3,dtype=torch.int16),rr))
    gt, gr = motion_codec._sparse_read(reader, old_count, delta_rows=True)
    full_t = rt[state.owner[:old_count]].int()+gt.int()
    full_r = rr[state.owner[:old_count]].int()+gr.int()
    moving = full_t.ne(0).any(-1)|full_r.ne(0).any(-1)
    residual = gt.ne(0).any(-1)|gr.ne(0).any(-1)
    sharing = dict(old_count=old_count,moving_points=int(moving.sum()),residual_points=int(residual.sum()),
        moving_without_residual=int((moving&~residual).sum()))
    deleted = torch.ones(len(origin_ids), dtype=torch.bool)
    deleted[kept] = False
    source_ids = origin_ids[deleted]
    source_ids = source_ids[source_ids.ge(0)]
    origin_retirement.append(dict(frame=frame, source269_retired=len(source_ids),
        source269_original_alpha_ge_05=int(origin_alpha[source_ids].ge(.5).sum()),
        source269_original_alpha_ge_09=int(origin_alpha[source_ids].ge(.9).sum())))
    origin_ids = torch.cat((origin_ids[kept], torch.full((len(raw['xyz'])-len(kept),), -1, dtype=torch.long)))
    manifest = _validate_stream_manifest(stream, frame, state, raw, relative_reference)
    decode_seconds = time.perf_counter() - started
    started = time.perf_counter()
    _install_raw(module, raw, device)
    torch.cuda.synchronize()
    upload_seconds = time.perf_counter() - started
    view, count = _cam00(data, frame, device)
    assert count == 1
    summary = json.loads((run/'frame_summary'/f'frame_{frame:03d}.json').read_text())
    quality, difference, cache_difference = _sequence_quality(
        module, view, summary['evaluation']['test'], tolerance, True)
    storage = _actual_frame_storage(stream, frame, manifest, summary,
        reference.stat().st_size, relative_reference)
    render_seconds = _time_sequence_render(module, view, 10, 50)
    rows.append(dict(frame=frame, gaussian_count=len(raw['xyz']), quality=quality,sharing=sharing,
        quality_saved_difference=difference, cache_pixel_max_abs_difference=cache_difference,
        warmup_renders=10, timed_renders=50, render_seconds=render_seconds,
        file_decode_verify_seconds=decode_seconds, upload_seconds=upload_seconds,
        **storage))
    del view
    if frame in [279, 289, 299]:
        checks.append(check_gpu_exclusivity())
saved_raw, _ = _capture_raw(run/'rigid-ckpt-299-200.pth', 299, 200)
assert all(torch.equal(raw[name], saved_raw[name]) for name in raw)
retained_source = origin_ids.ge(0)
retained_initial_alpha = origin_alpha[origin_ids[retained_source]]
retained_final_alpha = raw['opacity'][retained_source].sigmoid().flatten()
result = dict(scope='Proximal GS trial, 30 late frames270-299 only; same old frame269 bootstrap.',
    run=str(run), reference=str(reference), reference_frame=269, measured_frames=len(rows),
    bootstrap_raw_matches_source_checkpoint=True, final_raw_matches_checkpoint=True,
    render_summary=summarize_render_frames(rows), storage=_summarize_storage(rows),
    frames=rows, gpu_checks=checks,
    max_cache_pixel_difference=max(row['cache_pixel_max_abs_difference'] for row in rows),
    max_quality_difference={name:max(abs(row['quality_saved_difference'][name]) for row in rows)
                            for name in ['psnr','ssim','l1']},
    source269_cohort=dict(initial_count=len(origin_alpha),
        remaining_count=int(retained_source.sum()),
        retired_original_alpha_ge_05=sum(row['source269_original_alpha_ge_05'] for row in origin_retirement),
        retired_original_alpha_ge_09=sum(row['source269_original_alpha_ge_09'] for row in origin_retirement),
        originally_alpha_ge_09_now_below_05=int((retained_initial_alpha.ge(.9) & retained_final_alpha.lt(.5)).sum()),
        per_frame=origin_retirement),
    timing_scope='Full materialized render+clamp,10 warmups and50 timed renders/frame; decode/upload excluded.')
result['shared_moving_point_percent']=100*sum(r['sharing']['moving_without_residual'] for r in rows)/sum(r['sharing']['moving_points'] for r in rows)
(OUT/'late_benchmark.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key not in ['frames','gpu_checks']},indent=2))
