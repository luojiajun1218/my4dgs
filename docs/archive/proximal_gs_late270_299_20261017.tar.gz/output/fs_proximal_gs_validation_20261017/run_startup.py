"""Two dynamic frames from the shared native frame0; dataset still has300 frames."""
from pathlib import Path
from dataclasses import asdict
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from omegaconf import OmegaConf
from pipeline.entry import Pipeline
from scripts.benchmark_rigid_residual_tree import _load_config,check_gpu_exclusivity

OUT=Path(__file__).resolve().parent
status=json.loads((OUT/'late_window_status.json').read_text())
assert status['complete']
check_gpu_exclusivity()
config=_load_config(Path(status['output']))
config.output_dir=OUT
config.experiment_name='startup0_2_prox_rate002'
config.module.rigid_tree.rate_loss_weight=.002
config.ckpt_path=Path(OmegaConf.load(ROOT/'config/fs_ste_sparse_tralpha_rate003_full300_20261017.yaml').ckpt_path)
config.trainer.saving_ckpt_frames=[1,2]
pipeline=Pipeline(config)
trainer,module=pipeline.trainer,pipeline.module
trainer.setup(module,config.ckpt_path)
assert trainer.is_first_frame and trainer.global_step==trainer.config.num_init_steps
pipeline.save_config()
trainer.global_step=0
reports=[]
for frame in range(1,3):
    trainer.datamodule.current_frame=frame
    reports.append(trainer.frame_training_loop())
    module.begin_next_frame()
    trainer.global_step=0
if trainer.tb_writer is not None:
    trainer.tb_writer.close()
result=dict(complete=True,scope='Default rate .002: shared native frame0 plus two dynamic frames, data.num_frames remains300.',
    output=str(pipeline.output_dir),frames=[r['frame'] for r in reports],
    module_config=asdict(module.config),reference_count=module.reference_count,
    results=[dict(frame=r['frame'],psnr=r['evaluation']['test']['psnr'],encoded_bytes=r['encoded_bytes'],
        rotation_blocks=r['motion_rate_diagnostics']['gs_rotation_active_blocks']) for r in reports])
(OUT/'startup.json').write_text(json.dumps(result,indent=2,
    default=lambda value:OmegaConf.to_container(value,resolve=True)
        if OmegaConf.is_config(value) else str(value))+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='module_config'},indent=2))
