"""Continue an independently verified native prefix with identical frozen code."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument('prefix', type=Path)
parser.add_argument('--name', required=True)
args = parser.parse_args()
prefix = args.prefix.resolve()
status = json.loads((prefix/'window_status.json').read_text())
verification = json.loads((prefix/'independent_verification.json').read_text())
assert status['complete'] and status['start'] == 1 and status['end'] < 299
assert verification['complete'] and len(verification['frames']) == status['end']
snapshot = Path(status['runtime_source'])
assert all(hashlib.sha256((snapshot/path).read_bytes()).hexdigest() == digest
           for path,digest in status['source_hashes'].items())
sys.path.insert(0, str(snapshot))
from scripts.benchmark_rigid_residual_tree import _load_config,check_gpu_exclusivity
from pipeline.entry import Pipeline

check_gpu_exclusivity()
cfg = _load_config(prefix)
cfg.output_dir = Path(__file__).resolve().parent
cfg.experiment_name = args.name
cfg.ckpt_path = prefix/f'rigid-ckpt-{status["end"]}-200.pth'
cfg.resume_prefix_dir = prefix
cfg.resume_completed_prefix_frames = status['end']+1
cfg.trainer.saving_ckpt_frames = sorted(set(cfg.trainer.saving_ckpt_frames) | {
    frame for frame in (status['end']+1,59,89,119,149,179,209,239,269,299)
    if frame > status['end']})
pipeline = Pipeline(cfg)
trainer,module = pipeline.trainer,pipeline.module
trainer.setup(module,cfg.ckpt_path)
assert module.frame_finalized
assert (pipeline.output_dir/'prefix_provenance.json').exists()
if trainer._resume_rng is not None:
    trainer._restore_rng(trainer._resume_rng)
trainer._resume_rng = None
module.begin_next_frame()
trainer.global_step = 0
pipeline.save_config()
status = {**status,'name':args.name,'complete':False,'end':299,
    'output':str(pipeline.output_dir),'prefix_source':str(prefix),
    'resume_checkpoint':str(cfg.ckpt_path),
    'resume_checkpoint_sha256':hashlib.sha256(cfg.ckpt_path.read_bytes()).hexdigest(),
    'resumed_at':len(status['results'])+1,'results':list(status['results'])}
path = pipeline.output_dir/'window_status.json'
def save():
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(status,indent=2,default=str)+'\n')
    temporary.replace(path)
save()
started = time.perf_counter()
try:
    for frame in range(status['resumed_at'],300):
        trainer.datamodule.current_frame = frame
        row = trainer.frame_training_loop()
        manifest = pipeline.output_dir/'frame_storage/rigid_tree'/f'frame_{frame:03d}.json'
        status['results'].append(dict(frame=frame,psnr=row['evaluation']['test']['psnr'],
            ssim=row['evaluation']['test']['ssim'],full_bytes=row['encoded_bytes']+manifest.stat().st_size,
            motion_bytes=row['motion']['bytes'],opacity_bytes=(row.get('opacity_update') or {}).get('archive_bytes',0),
            birth_bytes=(row.get('birth') or {}).get('archive_bytes',0),regions=row['region_count'],
            gs_rows=row['motion_rate_diagnostics']['gs_active_rows'],
            gs_t=row['motion_rate_diagnostics']['gs_translation_active_blocks'],
            gs_r=row['motion_rate_diagnostics']['gs_rotation_active_blocks'],count=row['total_count'],
            birth_count=row['birth_count'],old_count=row['old_count'],seconds=row['elapsed_seconds']))
        save()
        if frame < 299:
            module.begin_next_frame();trainer.global_step=0
    status.update(complete=True,continuation_seconds=time.perf_counter()-started,
        source_unchanged=hashlib.sha256(Path(status['source']).read_bytes()).hexdigest()==status['source_sha256'])
except BaseException as exc:
    status['error']=repr(exc)
    raise
finally:
    save()
    if trainer.tb_writer is not None:
        trainer.tb_writer.close()
print(json.dumps(dict(complete=status['complete'],output=str(pipeline.output_dir),
                      frames=len(status['results'])),indent=2))
