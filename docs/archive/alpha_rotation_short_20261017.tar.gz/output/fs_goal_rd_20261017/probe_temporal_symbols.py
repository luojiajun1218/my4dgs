"""Read-only lossless temporal coding capacity, with exact survivor alignment."""
import hashlib
import json
from pathlib import Path
import sys
import torch
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from pipeline.model.rigid_tree_codec import (
    uncompressed_motion_packet,compress_motion_packet,_Reader,_sparse_read,_sparse_write)
torch.set_num_threads(2)
stream=ROOT/'output/fs_proximal_gs_validation_20261017/late270_299_prox_v1/20261017T132700_043227/frame_storage/rigid_tree'
previous=None
results=[]
for frame in range(270,300):
    path=stream/f'motion_{frame:03d}.bin'
    packet=path.read_bytes();raw=uncompressed_motion_packet(packet)
    reader=_Reader(raw[:-16]);assert bytes(reader.take(4))==b'SPG1'
    reader.take(32)
    f,regions,count,births=[reader.integer() for _ in range(4)]
    reader.take(40);mode=reader.take(1)[0]
    if mode:
        deleted_count=reader.integer();deleted=[];last=-1
        for _ in range(deleted_count):
            last+=reader.integer()+1;deleted.append(last)
        keep=torch.ones(count+deleted_count,dtype=torch.bool);keep[deleted]=False
        rows=keep.nonzero(as_tuple=True)[0]
    else:rows=torch.arange(count)
    assert reader.integer()==0
    reader.take((regions+7)//8)
    rt,rr=_sparse_read(reader,regions-1,delta_rows=True)
    prefix=raw[:reader.cursor]
    gt,gr=_sparse_read(reader,count,delta_rows=True)
    tail=raw[reader.cursor:-16]
    if previous is not None:
        prediction_t,prediction_r=[v[rows] for v in previous]
        dt,dr=gt.int()-prediction_t.int(),gr.int()-prediction_r.int()
        overflow=bool(dt.abs().gt(32767).any() or dr.abs().gt(32767).any())
        if overflow:raise ValueError('Need wider prediction symbols')
        body=bytearray(prefix);_sparse_write(body,dt.short(),dr.short());body.extend(tail)
        body.extend(hashlib.sha256(body).digest()[:16])
        alternative=compress_motion_packet(body,'auto')
        nonzero=gt.ne(0).any(-1)|gr.ne(0).any(-1)
        corrected=dt.ne(0).any(-1)|dr.ne(0).any(-1)
        results.append(dict(frame=frame,bytes=len(packet),predictive_bytes=len(alternative),
            active=int(nonzero.sum()),corrected=int(corrected.sum()),
            identical_previous_fraction=float(torch.cat((gt,gr),1).eq(torch.cat((prediction_t,prediction_r),1)).all(-1).float().mean())))
    previous=[torch.cat((v,torch.zeros(births,3,dtype=v.dtype))) for v in (gt,gr)]
result=dict(scope='fixed trained poses; previous GS residual integer predictor, regions unchanged',
    frames=results,baseline_bytes=sum(r['bytes'] for r in results),
    predictive_bytes=sum(r['predictive_bytes'] for r in results),
    per_frame_best_bytes=sum(min(r['bytes'],r['predictive_bytes']) for r in results))
(ROOT/'output/fs_goal_rd_20261017/temporal_symbol_probe.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='frames'},indent=2))
