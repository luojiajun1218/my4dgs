from pathlib import Path
import csv, datetime, hashlib, io, json, os, signal, subprocess, sys, time

ROOT=Path('/home/gamer-02/Documents/DeepLearning/my4dgs')
CONTROL=Path(__file__).resolve().parent
PLAN=json.loads((CONTROL/'plan.json').read_text())
EXPERIMENT=ROOT/'output'/PLAN['experiment_name']
UUID='GPU-ba22542c-c87e-a4f9-8fbd-2dfd200d967a'
FIELDS=['temperature.gpu','power.draw','power.limit','utilization.gpu','memory.used','pcie.link.gen.current','pcie.link.width.current']
started=time.monotonic()
now=datetime.datetime.now().astimezone()
state=dict(status='starting',controller_pid=os.getpid(),started_at=now.isoformat(),since_local=now.strftime('%Y-%m-%d %H:%M:%S'),boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),plan=PLAN)
samples=[]
child=None

def save():
    tmp=CONTROL/'status.tmp'
    tmp.write_text(json.dumps(state,indent=2))
    tmp.replace(CONTROL/'status.json')

def probe():
    result=subprocess.run(['nvidia-smi','-i',UUID,'--query-gpu='+','.join(FIELDS),'--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=10)
    if result.returncode:
        raise RuntimeError('GPU query failed: '+(result.stderr or result.stdout).strip())
    values=next(csv.reader(io.StringIO(result.stdout)))
    sample={'at':datetime.datetime.now().astimezone().isoformat(),'elapsed_seconds':time.monotonic()-started}
    sample.update({key:float(value.strip()) for key,value in zip(FIELDS,values)})
    samples.append(sample)
    with (CONTROL/'gpu_samples.jsonl').open('a') as f:
        f.write(json.dumps(sample)+'\n')
    return sample

def stop_child():
    if child is not None and child.poll() is None:
        os.killpg(child.pid,signal.SIGINT)
        try:
            child.wait(timeout=25)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGTERM)
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid,signal.SIGKILL)
                child.wait(timeout=10)

def interrupted(signum,frame):
    raise RuntimeError(f'Controller interrupted by signal {signum}')

for sig in (signal.SIGINT,signal.SIGTERM):
    signal.signal(sig,interrupted)
try:
    sample=probe()
    if abs(sample['power.limit']-350)>0.1:
        raise RuntimeError('350 W cap is not active')
    if EXPERIMENT.exists():
        raise RuntimeError('The new experiment directory already exists')
    with (CONTROL/'train.log').open('xb') as log:
        child=subprocess.Popen([sys.executable,'-u','main.py','--config='+PLAN['config']],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env={**os.environ,'PYTHONUNBUFFERED':'1'})
        state.update(status='training',training_pid=child.pid)
        save()
        print(json.dumps(state),flush=True)
        last_frame=-1
        last_notice=0.
        while child.poll() is None:
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                pass
            sample=probe()
            if sample['temperature.gpu']>=PLAN['temperature_stop_c']:
                raise RuntimeError('GPU temperature reached the 90 C stop threshold')
            if time.monotonic()-started>PLAN['max_training_seconds']:
                raise RuntimeError('Bounded training check exceeded 45 minutes')
            runs=[p for p in EXPERIMENT.glob('*') if p.is_dir()] if EXPERIMENT.exists() else []
            summaries=sorted(runs[0].glob('frame_summary/frame_*.json')) if len(runs)==1 else []
            frame=int(summaries[-1].stem.split('_')[-1]) if summaries else -1
            state.update(elapsed_seconds=time.monotonic()-started,last_complete_frame=frame,completed_dynamic_frames=len(summaries),gpu=sample,run=str(runs[0]) if len(runs)==1 else None)
            save()
            if frame!=last_frame or time.monotonic()-last_notice>=55:
                print(json.dumps(dict(status='training',last_complete_frame=frame,completed_dynamic_frames=len(summaries),elapsed_seconds=round(state['elapsed_seconds'],1),temperature_c=sample['temperature.gpu'],power_w=sample['power.draw'],gpu_util_percent=sample['utilization.gpu'])),flush=True)
                last_frame=frame
                last_notice=time.monotonic()
        state['training_exit_code']=child.returncode
        if child.returncode:
            raise RuntimeError(f'Training exited with code {child.returncode}')
    if state.get('completed_dynamic_frames')!=29 or state.get('last_complete_frame')!=29:
        raise RuntimeError('Training finished without all 29 dynamic frames')
    snapshot=CONTROL/'source_snapshot'
    manifest=json.loads((snapshot/'source_manifest.json').read_text())
    state['source_changed_since_snapshot']=[name for name,digest in manifest['hashes'].items() if not (ROOT/name).is_file() or hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest]
    state['status']='training_complete'
except BaseException as error:
    state.update(status='failed_or_interrupted',error=repr(error))
    stop_child()
finally:
    state['elapsed_seconds']=time.monotonic()-started
    state['finished_at']=datetime.datetime.now().astimezone().isoformat()
    if samples:
        state['sample_count']=len(samples)
        state['max_temperature_c']=max(s['temperature.gpu'] for s in samples)
        state['max_sampled_power_w']=max(s['power.draw'] for s in samples)
        state['max_sampled_gpu_util_percent']=max(s['utilization.gpu'] for s in samples)
    kernel=subprocess.run(['journalctl','-k','-b','--since',state['since_local'],'--no-pager','--output=short-iso','--grep','NVRM: Xid|GPU has fallen|PCIe Bus Error|AER:.*(error|fatal)'],capture_output=True,text=True,timeout=30)
    (CONTROL/'kernel_errors.log').write_text(kernel.stdout+kernel.stderr)
    state['new_xid_count']=kernel.stdout.count('NVRM: Xid')
    if child is not None:
        state['training_exit_code']=child.poll()
    save()
    print(json.dumps(state),flush=True)
if state['status']!='training_complete':
    raise SystemExit(1)
