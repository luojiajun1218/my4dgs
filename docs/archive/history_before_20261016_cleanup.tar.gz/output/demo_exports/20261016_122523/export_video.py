"""Export saved model renders without requiring CUDA or altering source runs."""

from __future__ import annotations

from datetime import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
from zoneinfo import ZoneInfo

from PIL import Image
import yaml


ROOT = Path('/home/gamer-02/Documents/DeepLearning/my4dgs')
SOURCE = ROOT / 'output/fs_spatial_gate_worldroute_200_full300_20261015/20261015T180221_5e8236'
STAMP = datetime.now(ZoneInfo('Asia/Shanghai')).strftime('%Y%m%d_%H%M%S')
BUILD = ROOT / 'output/demo_exports' / STAMP
FINAL = ROOT / 'output' / f'4dgs_flame_steak_demo_1920x1080_{STAMP}.mp4'
PARTIAL = BUILD / 'encoding.mp4'
FPS = 30
REPEATS = 1


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    ffmpeg = shutil.which('ffmpeg')
    ffprobe = shutil.which('ffprobe')
    if not ffmpeg or not ffprobe:
        raise RuntimeError('Run in the ReConGS environment with ffmpeg and ffprobe')

    chain = []
    current = SOURCE
    while current:
        if current in chain:
            raise ValueError('Cyclic run prefix provenance')
        chain.append(current)
        cfg = yaml.safe_load((current / 'config.yaml').read_text())
        prefix = cfg.get('resume_prefix_dir')
        current = Path(prefix) if prefix else None
    chain.reverse()

    frames = {}
    for run in chain:
        for path in sorted((run / 'image/frames').glob('*/cam00_step200.png')):
            index = int(path.parent.name)
            if index in frames:
                raise ValueError(f'Overlapping saved final render for frame {index}')
            summary = json.loads((run / 'frame_summary' / f'frame_{index:03d}.json').read_text())
            copied_summary = json.loads((SOURCE / 'frame_summary' / f'frame_{index:03d}.json').read_text())
            if summary['frame'] != index or summary['materialized_sha256'] != copied_summary['materialized_sha256']:
                raise ValueError(f'Source render is outside the verified continuation at frame {index}')
            final_stage = [m for m in summary['stage_image_metrics'] if m['step'] == 200]
            if len(final_stage) != 1 or final_stage[0]['phase'] != 'final_decoded_with_birth' or Path(final_stage[0]['camera']).name != 'cam00.png':
                raise ValueError(f'Not the final decoded camera00 render for frame {index}')
            with Image.open(path) as image:
                if image.size != (1600, 1199):
                    raise ValueError(f'Unexpected source image size: {path}: {image.size}')
                image.verify()
            frames[index] = dict(frame=index, image=str(path), sha256=digest(path),
                                 model_sha256=summary['materialized_sha256'], run=str(run))
    indices = sorted(frames)
    if indices != list(range(1, 200)):
        raise ValueError(f'Need exactly contiguous saved frames 1..199, got {indices}')

    BUILD.mkdir(parents=True, exist_ok=False)
    links = BUILD / 'frames'
    links.mkdir()
    for output_index in range(len(indices) * REPEATS):
        source_index = indices[output_index % len(indices)]
        (links / f'{output_index + 1:04d}.png').symlink_to(frames[source_index]['image'])

    filters = ('scale=1920:1080:force_original_aspect_ratio=decrease:'
               'force_divisible_by=2:flags=lanczos,'
               'pad=1920:1080:(ow-iw)/2:(oh-ih)/2:color=black,'
               'setsar=1,format=yuv420p')
    command = [ffmpeg, '-hide_banner', '-nostdin', '-n', '-framerate', str(FPS),
               '-start_number', '1', '-i', str(links / '%04d.png'),
               '-frames:v', str(len(indices) * REPEATS), '-vf', filters,
               '-c:v', 'libx264', '-preset', 'slow', '-crf', '16', '-threads', '8',
               '-r', str(FPS), '-pix_fmt', 'yuv420p', '-profile:v', 'high',
               '-movflags', '+faststart', '-an', '-metadata',
               'title=4D Gaussian Splatting - Flame Steak', '-metadata',
               'comment=Saved model reconstruction, fixed camera00, frames 001-199, single playback; no ground-truth frames or synthetic interpolation.',
               str(PARTIAL)]
    manifest = dict(created_at=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),
                    final_path=str(FINAL), width=1920, height=1080, fps=FPS,
                    source_frame_range=[1, 199], source_frame_count=len(indices),
                    output_frame_count=len(indices) * REPEATS, repeats=REPEATS,
                    camera='cam00', method='spatial-gated worldroute',
                    content='Final decoded model renders with births, saved at training step200',
                    source_resolution=[1600, 1199],
                    framing='Preserve scene aspect ratio and entire field of view, black side bars',
                    gpu_rendering_performed=False, ground_truth_used=False,
                    interpolation_used=False, source_run_chain=[str(p) for p in chain],
                    source_frames=[frames[i] for i in indices], ffmpeg_command=command)
    (BUILD / 'manifest.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False))
    print(f'Validated {len(indices)} final model renders from {len(chain)} causally continued runs', flush=True)
    print(f'Encoding {len(indices) * REPEATS} frames at {FPS} fps to {FINAL}', flush=True)
    with (BUILD / 'ffmpeg.log').open('w') as log:
        subprocess.run(command, check=True, stdout=log, stderr=subprocess.STDOUT)

    probe = json.loads(subprocess.check_output([ffprobe, '-v', 'error', '-count_frames',
                       '-show_entries', 'stream=codec_name,width,height,pix_fmt,r_frame_rate,nb_read_frames:format=duration,size',
                       '-of', 'json', str(PARTIAL)], text=True))
    stream = probe['streams'][0]
    if (stream['width'], stream['height'], stream['r_frame_rate'], int(stream['nb_read_frames'])) != (1920, 1080, '30/1', len(indices) * REPEATS):
        raise ValueError(f'Unexpected encoded video properties: {probe}')
    subprocess.run([ffmpeg, '-v', 'error', '-xerror', '-i', str(PARTIAL), '-f', 'null', '-'], check=True)
    manifest['probe'] = probe
    manifest['sha256'] = digest(PARTIAL)
    manifest['full_video_decode_verified'] = True
    if FINAL.exists():
        raise FileExistsError(FINAL)
    PARTIAL.rename(FINAL)
    for name, seconds in [('preview_start.jpg', 0), ('preview_middle.jpg', 3.3), ('preview_late.jpg', 6.3)]:
        subprocess.run([ffmpeg, '-v', 'error', '-nostdin', '-n', '-ss', str(seconds),
                        '-i', str(FINAL), '-frames:v', '1', '-q:v', '2', str(BUILD / name)], check=True)
    (BUILD / 'manifest.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False))
    print(json.dumps(dict(video=str(FINAL), manifest=str(BUILD / 'manifest.json'),
                          previews=str(BUILD), probe=probe), ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
