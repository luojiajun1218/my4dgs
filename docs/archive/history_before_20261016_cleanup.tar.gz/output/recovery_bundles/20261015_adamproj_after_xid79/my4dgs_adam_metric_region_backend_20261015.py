"""Isolated training marker for Adam-metric regional initialization.

Motion codec and region/GS/gate semantics remain the original SPG1 method.
"""
from my4dgs_adam_metric_region_init_20261015 import initialize

MARKER = 'quantized_existing_adam_metric_projection_v1'


def install(spatial):
    cls = spatial.SpatialGatedMotion
    if getattr(cls, '_adam_metric_projection_installed', False):
        raise RuntimeError('Projection initialization already installed')
    capture, restore, diagnostics = cls.capture, cls.restore, cls.record_final_diagnostics

    def new_capture(self):
        packet = capture(self)
        if packet is not None:
            packet['candidate_initialization'] = MARKER
        return packet

    def new_restore(self, packet):
        if packet is not None and packet.get('candidate_initialization') != MARKER:
            raise ValueError('Cannot resume different regional initialization rules')
        delegated = None if packet is None else dict(packet, candidate_initialization='quantized_median_v1')
        return restore(self, delegated)

    def new_diagnostics(self):
        result = diagnostics(self)
        self.flat_region_diagnostics['candidate_initialization'] = MARKER
        self.flat_region_diagnostics['region_representative'] = (
            'quantized existing-Adam-metric initialization; original shared-field/point fit and mode refresh')
        return result

    cls._initialize_candidates = initialize
    cls.capture, cls.restore, cls.record_final_diagnostics = new_capture, new_restore, new_diagnostics
    cls._adam_metric_projection_installed = True
