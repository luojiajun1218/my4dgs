"""Validate the actual interrupted-run checkpoint and dataset without a GPU.

Does not copy packets or large data; writes only camera JSON in a temporary
directory. The original30-frame plan and numerical method remain unchanged.
"""
from pathlib import Path
from dataclasses import asdict
import tempfile, sys, json, importlib, hashlib
import torch

ROOT=Path('/home/gamer-02/Documents/DeepLearning/my4dgs')
sys.path[:0]=[str(ROOT),str(Path(__file__).resolve().parent)]
torch.set_num_threads(1)
from scripts import benchmark_rigid_residual_tree as bench
from omegaconf import OmegaConf
from libgs.utils.config import to_structured
package=importlib.import_module('pipeline.ReCon-GS')
data_module=importlib.import_module('pipeline.ReCon-GS.data')
extension=importlib.import_module('pipeline.ReCon-GS.sequence_extension')
spatial=importlib.import_module('pipeline.ReCon-GS.model.spatial_gated_motion')
import my4dgs_adam_metric_region_backend_20261015 as backend
backend.install(spatial)
CONFIG=Path(__file__).with_name('recovery.yaml')
OUT=Path(__file__).with_name('preflight_cpu.json')
assert not OUT.exists()
cfg,extra=to_structured(OmegaConf.load(CONFIG),package.Config)
assert not extra
source=Path(cfg.resume_prefix_dir)
checkpoint=torch.load(cfg.ckpt_path,map_location='cpu',weights_only=False)
motion=spatial.SpatialGatedMotion(cfg.module.rigid_tree)
motion.restore(checkpoint['rigid_tree_motion'])
assert motion.committed and motion.frame_index==9
data=data_module.DataModule(cfg.data)
data.setup()  # No save_dir: do not copy input.ply or image data.
items=list(data.scene.train_dataset.items)
if data.scene.test_dataset is not None:
    items+=list(data.scene.test_dataset.items)
with tempfile.TemporaryDirectory(prefix='my4dgs_sameplan_recovery_') as temp:
    destination=Path(temp)
    (destination/'cameras.json').write_text(json.dumps([item.to_json(id=i) for i,item in enumerate(items)]))
    plan=extension.validate_sequence_extension(checkpoint=checkpoint,
        current_data_config=asdict(cfg.data),current_trainer_config=asdict(cfg.trainer),
        source_run=source,destination_run=destination,current_extent=data.cameras_extent,
        current_images=[(item.frame,item.path) for item in items],
        completed_prefix_frames=cfg.resume_completed_prefix_frames)
    assert (plan.previous_frames,plan.extended_frames,plan.source_planned_frames,plan.resume_frame)==(10,30,30,9)
    result=dict(config=str(CONFIG),config_sha256=hashlib.sha256(CONFIG.read_bytes()).hexdigest(),
        source_run=str(source),checkpoint=str(cfg.ckpt_path),
        recoverable_prefix_frames=plan.previous_frames,planned_frames=plan.extended_frames,
        source_planned_frames=plan.source_planned_frames,resume_frame=plan.resume_frame,
        verified_files=len(plan.files),verified_current_image_identities=len(plan.images),
        decoded_sha256=plan.decoded_sha256,raw_sha256=plan.raw_sha256,
        scene_extent=data.cameras_extent,initializer_checkpoint_marker=backend.MARKER,
        checkpoint_and_codec_pose_verified=True,packets_copied=False,large_data_copied=False,
        gpu_training_started=False,scope='Actual30->30 recovery with explicitlyselected completed0-9 prefix; sourceconfig unchanged, same numerical method. Futureframe10 will be recomputed fromsavedRNG. GPU remains unavailable until host recovery.')
OUT.write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2),flush=True)
