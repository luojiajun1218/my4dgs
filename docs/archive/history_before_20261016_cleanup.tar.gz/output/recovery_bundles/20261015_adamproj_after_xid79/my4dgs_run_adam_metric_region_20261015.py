"""Experimental initializer only; the original decoder remains compatible."""
from pathlib import Path
import sys, importlib, subprocess, shutil, hashlib, json

ROOT = Path('/home/gamer-02/Documents/DeepLearning/my4dgs')
sys.path.insert(0, str(ROOT))
import my4dgs_adam_metric_region_backend_20261015 as backend
spatial = importlib.import_module('pipeline.ReCon-GS.model.spatial_gated_motion')
backend.install(spatial)
from scripts import benchmark_rigid_residual_tree as bench
bench.check_gpu_exclusivity()
from omegaconf import OmegaConf
from libgs.utils.config import to_structured
package = importlib.import_module('pipeline.ReCon-GS')
cfg, extra = to_structured(OmegaConf.load(sys.argv[1]), package.Config)
assert not extra
assert cfg.module.rigid_tree.motion_steps == 100 and cfg.module.rigid_tree.birth_steps == 100
pipe = package.Pipeline(cfg)
snapshot = pipe.output_dir/'source_snapshot'
subprocess.run([sys.executable, str(ROOT/'scripts/freeze_experiment_source.py'), str(snapshot)], cwd=ROOT, check=True)
destination = snapshot/'experimental_projection'
destination.mkdir()
hashes = {}
for path in (Path(__file__), Path(backend.__file__), Path(backend.__file__).with_name('my4dgs_adam_metric_region_init_20261015.py')):
    shutil.copy2(path, destination/path.name)
    hashes[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
(pipe.output_dir/'experimental_projection.json').write_text(json.dumps(dict(
    policy=backend.MARKER, hashes=hashes,
    rule='Regional quantized initialization minimizes weighted proposal distortion using existing free-fit Adam diagonal proxy. No added coefficient or loss.',
    codec='original SPG1 unchanged; ordinary independent stream decoder compatible',
    note='Same spatial tree, gates, region absolute/GS relative semantics, 100+100 steps, loss weights, quantization, views, LR and original mode refresh. Training checkpoint marker strictly rejects a different initializer. Native shared first frame unchanged. Default method not modified.'), indent=2))
print(json.dumps(dict(run=str(pipe.output_dir), policy=backend.MARKER)), flush=True)
pipe.run()
