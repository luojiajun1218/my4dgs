"""Alternative shared projection using the existing Adam diagonal metric.

For each quantized coordinate choose round(sum(w*u)/sum(w)), minimizing
sum(w*(u-a)^2) on integer a. Adam sqrt(second-moment)+epsilon is a proxy,
not the image Hessian. No additional coefficient, loss or model parameter.
"""
import numpy as np
import torch


def representatives(symbols, groups, observed, metric, count):
    symbols = np.asarray(symbols, np.float64)
    groups = np.asarray(groups, np.int64)
    observed = np.asarray(observed, bool)
    metric = np.asarray(metric, np.float64)
    if symbols.shape != metric.shape or symbols.shape != (len(groups), 6):
        raise ValueError('Motion and Adam metric shape mismatch')
    if not np.isfinite(metric).all() or (metric <= 0).any():
        raise ValueError('Metric must be finite and positive')
    supported = np.bincount(groups, weights=observed, minlength=count)>0
    supported[0] = False
    ids = np.where(supported)[0]
    result = np.zeros((len(ids), 6), np.float64)
    for k in range(6):
        weight = metric[:, k]*observed
        denominator = np.bincount(groups, weights=weight, minlength=count)
        numerator = np.bincount(groups, weights=weight*symbols[:, k], minlength=count)
        result[:, k] = np.rint(numerator[ids]/denominator[ids]).clip(-32767, 32767)
    return ids, result


@torch.no_grad()
def initialize(self, full_motion=None):
    assert torch.equal(self.steps, self.gs_steps), 'Conditional rule checks the current equal-step method only'
    target = (torch.cat(full_motion, -1) if full_motion is not None else
        torch.cat((torch.round(self.gs_translation/self.gs_steps[:3]),
                   torch.round(self.gs_rotation/self.gs_steps[3:])), -1))
    metric = []
    for parameter in (self.gs_translation, self.gs_rotation):
        state = self.optimizer.state.get(parameter)
        if not state or 'exp_avg_sq' not in state:
            raise ValueError('Shared projection needs the completed free-fit Adam state')
        variance = state['exp_avg_sq']/(1-self.config.adam_betas[1]**int(state['step']))
        metric.append(variance.sqrt()+self.config.adam_eps)
    symbols = target.to(torch.int32).cpu().numpy()
    metric = torch.cat(metric, -1).cpu().double().numpy()
    observed = self.observations.gt(0).cpu().numpy()
    paths = self.spatial_paths.cpu().numpy()
    self._regional_fit_support = torch.zeros(len(self.parents), dtype=torch.bool, device=self.base_xyz.device)
    for level in range(paths.shape[1]):
        ids, values = representatives(symbols, paths[:, level], observed, metric, len(self.parents))
        index = torch.as_tensor(ids, device=self.base_xyz.device, dtype=torch.long)
        values = torch.as_tensor(values, device=self.base_xyz.device, dtype=self.base_xyz.dtype)
        self.region_translation[index] = values[:, :3]*self.steps[:3]
        self.region_rotation[index] = values[:, 3:]*self.steps[3:]
        self._regional_fit_support[index] = True
    self._regional_fit_support[0] = False
    self._candidate_initialized = True
    self._conditional_projection_rule = 'quantized_existing_adam_metric_projection_v1'
