"""Train one bounded initializer candidate, then use the unchanged decoder."""
from pathlib import Path
import sys, os, signal, subprocess, json, hashlib

ROOT=Path('/home/gamer-02/Documents/DeepLearning/my4dgs')
EXPERIMENT=ROOT/'output/fs_spatial_gate_adamproj_recovered_200_first30_20261015'
CONFIG=Path(__file__).with_name('recovery.yaml')
STATUS=Path(__file__).with_name('status.json')
BENCH=Path(__file__).with_name('benchmark.json')
probe=subprocess.run(['nvidia-smi','--query-gpu=name','--format=csv,noheader'],capture_output=True,text=True)
if probe.returncode or not probe.stdout.strip():
    raise SystemExit('GPU unavailable; recovery training was not started. Restore the GPU first.')
assert not STATUS.exists() and not EXPERIMENT.exists() and not BENCH.exists()
child=None
record=dict(controller_pid=os.getpid(),status='preparing',active_child_pid=None)


def save():
    STATUS.write_text(json.dumps(record,indent=2));print(json.dumps(record),flush=True)


def stop_child():
    if child is not None and child.poll() is None:
        os.killpg(child.pid,signal.SIGTERM)
        try:child.wait(timeout=15)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=15)


def run(arguments,log):
    global child
    with Path(log).open('xb') as output:
        child=subprocess.Popen([sys.executable,*arguments],cwd=ROOT,stdout=output,
            stderr=subprocess.STDOUT,start_new_session=True)
        record.update(active_child_pid=child.pid,log=log);save()
        code=child.wait();child=None;record['active_child_pid']=None
    if code:raise subprocess.CalledProcessError(code,arguments)


def interrupted(signum,frame):
    raise SystemExit(f'Controller received signal{signum}')


for sig in (signal.SIGINT,signal.SIGTERM):signal.signal(sig,interrupted)
try:
    record['status']='short_training'
    run([str(Path(__file__).with_name('my4dgs_run_adam_metric_region_20261015.py')),str(CONFIG)],
        str(Path(__file__).with_name('train.log')))
    runs=[p for p in EXPERIMENT.iterdir() if p.is_dir()];assert len(runs)==1
    target=runs[0];assert (target/'rigid-ckpt-29-200.pth').is_file()
    record.update(status='independent_original_decoder_benchmark',run=str(target));save()
    run([str(ROOT/'scripts/benchmark_rigid_residual_tree.py'),'--run',str(target),
        '--sequence','--mode','stream','--output',str(BENCH)],
        str(Path(__file__).with_name('benchmark.log')))
    result=json.loads(BENCH.read_text());assert result['measured_frames']==30
    snapshot=target/'source_snapshot'
    source=json.loads((snapshot/'source_manifest.json').read_text())
    for name,digest in source['hashes'].items():
        assert hashlib.sha256((snapshot/name).read_bytes()).hexdigest()==digest
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest
    extra=json.loads((target/'experimental_projection.json').read_text())
    for name,digest in extra['hashes'].items():
        assert hashlib.sha256((snapshot/'experimental_projection'/name).read_bytes()).hexdigest()==digest
        assert hashlib.sha256((Path(__file__).parent/name).read_bytes()).hexdigest()==digest
    record.update(status='complete',benchmark=str(BENCH),measured_frames=30,
        base_hashes_verified=len(source['hashes']),experimental_hashes_verified=len(extra['hashes']),
        dynamic_psnr=result['groups']['dynamic_frames']['psnr_mean'],
        complete_dynamic_bytes=result['storage']['dynamic_packets']['complete_update_bytes_mean'],
        pure_render_fps=result['groups']['all_frames']['aggregate_fps']);save()
except BaseException as exc:
    record.update(status='failed_or_interrupted',error=repr(exc));save();raise
finally:
    stop_child()
