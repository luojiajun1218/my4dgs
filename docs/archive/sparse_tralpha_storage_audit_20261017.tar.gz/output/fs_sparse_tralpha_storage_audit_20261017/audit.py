"""Read-only late-window byte accounting and reversible codec layout probes.

Probes use their own envelope, and do not change the production stream format.
Every probe is decompressed and inverted to the original packet bytes.
"""
from collections import Counter
import csv
import hashlib
import json
import lzma
from pathlib import Path
import statistics
import struct
import sys
import time
import zlib

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from pipeline.model.rigid_tree_codec import _Reader, _uvar, uncompressed_motion_packet
from pipeline.model.legacy_opacity_codec import HEADER

OUT = Path(__file__).resolve().parent
SOURCE = ROOT / 'output/fs_sparse_tralpha_validation_20261017/comparison.json'
comparison = json.loads(SOURCE.read_text())
RUN = Path(comparison['cases']['sparse_tralpha']['run'])
STREAM = RUN / 'frame_storage/rigid_tree'


def take_varints(reader, count):
    start = reader.cursor
    values = np.array([reader.integer() for _ in range(count)], dtype=np.int64)
    return values, bytes(reader.payload[start:reader.cursor])


def read_sparse(reader):
    start = reader.cursor
    count = reader.integer()
    gap_bytes = bytearray()
    gaps, flags, translations, rotations = [], [], [], []
    for _ in range(count):
        offset = reader.cursor
        gaps.append(reader.integer())
        gap_bytes.extend(reader.payload[offset:reader.cursor])
        flag = reader.take(1)[0]
        assert flag in (1, 2, 3)
        flags.append(flag)
        if flag & 1:
            translations.append(struct.unpack('<3h', reader.take(6)))
        if flag & 2:
            rotations.append(struct.unpack('<3h', reader.take(6)))
    return dict(count=count, gaps=np.array(gaps, dtype=np.int64),
        gap_bytes=bytes(gap_bytes), flags=np.array(flags, dtype=np.uint8),
        t=np.array(translations, dtype='<i2').reshape(-1, 3),
        r=np.array(rotations, dtype='<i2').reshape(-1, 3),
        original=bytes(reader.payload[start:reader.cursor]))


def write_sparse(part):
    output = bytearray(_uvar(part['count']))
    ti = ri = 0
    for gap, flags in zip(part['gaps'], part['flags']):
        output.extend(_uvar(gap))
        output.append(int(flags))
        if flags & 1:
            output.extend(part['t'][ti].tobytes())
            ti += 1
        if flags & 2:
            output.extend(part['r'][ri].tobytes())
            ri += 1
    assert ti == len(part['t']) and ri == len(part['r'])
    return bytes(output)


def pack_values(values, mode):
    if mode == 'planar16':
        return values.T.copy().tobytes()
    if mode == 'byteplanes':
        return values.T.copy().view(np.uint8).reshape(-1, 2).T.copy().tobytes()
    assert mode == 'zigzag'
    return b''.join(_uvar(2 * int(x) if x >= 0 else -2 * int(x) - 1)
                    for x in values.T.ravel())


def unpack_values(reader, count, components, mode):
    total = count * components
    if mode == 'planar16':
        values = np.frombuffer(reader.take(2 * total), dtype='<i2')
    elif mode == 'byteplanes':
        raw = np.frombuffer(reader.take(2 * total), dtype=np.uint8)
        values = raw.reshape(2, -1).T.copy().ravel().view('<i2')
    else:
        values, _ = take_varints(reader, total)
        values = ((values >> 1) ^ -(values & 1)).astype('<i2')
    return values.reshape(components, count).T.copy()


def planar_sparse(part, mode):
    return (_uvar(part['count']) + part['gap_bytes'] + part['flags'].tobytes()
            + pack_values(part['t'], mode) + pack_values(part['r'], mode))


def restore_sparse(reader, mode):
    count = reader.integer()
    gaps, gap_bytes = take_varints(reader, count)
    flags = np.frombuffer(reader.take(count), dtype=np.uint8)
    t_count = int(np.count_nonzero(flags & 1))
    r_count = int(np.count_nonzero(flags & 2))
    return write_sparse(dict(count=count, gaps=gaps, flags=flags,
        t=unpack_values(reader, t_count, 3, mode),
        r=unpack_values(reader, r_count, 3, mode)))


def envelope(raw, layout=0):
    # Complete self-identifying envelope overhead is included in byte counts.
    options = [(0, raw), (1, zlib.compress(raw, 6)),
               (2, lzma.compress(raw, format=lzma.FORMAT_XZ, preset=9))]
    codec, payload = min(options, key=lambda item: len(item[1]))
    packet = b'AUD1' + bytes([codec, layout]) + _uvar(len(raw)) + payload
    reader = _Reader(packet)
    assert bytes(reader.take(4)) == b'AUD1'
    codec = reader.take(1)[0]
    assert reader.take(1)[0] == layout
    size = reader.integer()
    payload = bytes(reader.take(len(packet) - reader.cursor))
    decoded = (payload if codec == 0 else zlib.decompress(payload) if codec == 1
               else lzma.decompress(payload))
    assert len(decoded) == size and decoded == raw
    return packet, decoded


def stats(part):
    n = part['count']
    return dict(rows=n, section_bytes=len(part['original']),
        gap_bytes=len(part['gap_bytes']), flags_bytes=n,
        count_bytes=len(_uvar(n)), translation_bytes=part['t'].nbytes,
        rotation_bytes=part['r'].nbytes,
        translation_blocks=len(part['t']), rotation_blocks=len(part['r']))


def symbol_stats(values):
    a = np.abs(values.astype(np.int64))
    norms = a.sum(axis=1)
    return dict(blocks=len(a), components=int(a.size),
        zero_components=int(np.count_nonzero(a == 0)),
        abs_le_1=int(np.count_nonzero(a <= 1)),
        abs_gt_127=int(np.count_nonzero(a > 127)),
        norm_eq_1=int(np.count_nonzero(norms == 1)),
        norm_ge_5=int(np.count_nonzero(norms >= 5)),
        norm_ge_10=int(np.count_nonzero(norms >= 10)),
        max_abs=int(a.max(initial=0)))


rows = []
histograms = {name: Counter() for name in ['gs_translation', 'gs_rotation', 'opacity']}
verified_probes = 0
started = time.monotonic()
for frame in range(270, 300):
    manifest_path = STREAM / f'frame_{frame:03d}.json'
    manifest = json.loads(manifest_path.read_text())
    motion = (STREAM / manifest['motion']).read_bytes()
    raw = uncompressed_motion_packet(motion)
    reader = _Reader(raw[:-16])
    assert bytes(reader.take(4)) == b'SPG1'
    reader.take(32)
    index, regions, count, births = [reader.integer() for _ in range(4)]
    assert index == frame
    quantization = struct.unpack('<5d', reader.take(40))
    mapping_start = reader.cursor
    deleted = 0
    survivor_mode = reader.take(1)[0]
    if survivor_mode:
        assert survivor_mode == 1
        deleted = reader.integer()
        take_varints(reader, deleted)
    mapping_bytes = reader.cursor - mapping_start
    assert reader.integer() == 0  # no parent edits in the fixed spatial tree
    header_bytes = reader.cursor - mapping_bytes
    reader.take((regions + 7) // 8)
    prefix = raw[:reader.cursor]
    regional, point = read_sparse(reader), read_sparse(reader)
    for part in (regional, point):
        assert write_sparse(part) == part['original']
    tail = raw[reader.cursor:]
    source_start = reader.cursor
    take_varints(reader, births)
    birth_sources = reader.cursor - source_start
    reader.take(28 * births)
    assert reader.cursor == len(raw) - 16
    assert (len(raw) == header_bytes + mapping_bytes + (regions + 7) // 8
            + len(regional['original']) + len(point['original'])
            + birth_sources + 28 * births + 16)

    opacity = (STREAM / manifest['opacity_update']).read_bytes()
    op_header = opacity[:HEADER.size]
    magic, op_frame, op_count, updates, step, body_size, checksum, prior = HEADER.unpack(op_header)
    op_body = zlib.decompress(opacity[HEADER.size:])
    assert magic == b'OPD1' and frame == op_frame and count == op_count
    assert len(op_body) == body_size
    op_reader = _Reader(op_body)
    gaps, values, gap_bytes = [], [], bytearray()
    for _ in range(updates):
        offset = op_reader.cursor
        gaps.append(op_reader.integer())
        gap_bytes.extend(op_reader.payload[offset:op_reader.cursor])
        values.append(struct.unpack('<h', op_reader.take(2))[0])
    assert op_reader.cursor == len(op_body)
    alpha_values = np.array(values, dtype='<i2').reshape(-1, 1)
    gs_rows = np.cumsum(point['gaps']) - 1
    alpha_rows = np.cumsum(gaps) - 1

    report = json.loads((RUN / f'frame_summary/frame_{frame:03d}.json').read_text())
    row = dict(frame=frame, old_count=count, birth_count=births, retired_count=deleted,
        motion_bytes=len(motion), opacity_bytes=len(opacity),
        birth_attribute_bytes=(STREAM / manifest['birth']).stat().st_size,
        manifest_bytes=manifest_path.stat().st_size,
        motion_raw_bytes=len(raw), header_bytes=header_bytes,
        survivor_mapping_bytes=mapping_bytes, gate_bitmap_bytes=(regions + 7) // 8,
        birth_source_bytes=birth_sources, birth_pose_bytes=28 * births, checksum_bytes=16,
        opacity_raw_bytes=len(op_header) + len(op_body), opacity_id_bytes=len(gap_bytes),
        opacity_symbol_bytes=2 * updates, opacity_rows=updates,
        motion_alpha_overlap=int(np.intersect1d(gs_rows, alpha_rows).size),
        rate_bytes_surrogate=report['motion_rate_diagnostics']['rate_bytes_surrogate'],
        opacity_rate_surrogate=report['opacity_rate_diagnostics']['raw_bytes_surrogate'],
        **{'region_' + k: v for k, v in stats(regional).items()},
        **{'gs_' + k: v for k, v in stats(point).items()})
    row['complete_update_bytes'] = sum(row[k] for k in [
        'motion_bytes', 'opacity_bytes', 'birth_attribute_bytes', 'manifest_bytes'])

    # Same OPD1 format: only change the compressor effort, then check the bytes.
    z9 = zlib.compress(op_body, 9)
    assert zlib.decompress(z9) == op_body
    row['opacity_zlib9_bytes'] = HEADER.size + len(z9)
    packet, decoded = envelope(op_header + op_body)
    assert decoded == op_header + op_body
    row['opacity_auto_bytes'] = len(packet)
    verified_probes += 1

    for mode in ['planar16', 'byteplanes', 'zigzag']:
        transformed = (_uvar(len(prefix)) + prefix + planar_sparse(regional, mode)
                       + planar_sparse(point, mode) + tail)
        layout = ['planar16', 'byteplanes', 'zigzag'].index(mode) + 1
        packet, decoded = envelope(transformed, layout=layout)
        restore = _Reader(decoded)
        restored_prefix = bytes(restore.take(restore.integer()))
        restored = (restored_prefix + restore_sparse(restore, mode)
                    + restore_sparse(restore, mode)
                    + bytes(restore.take(len(decoded) - restore.cursor)))
        assert restored == raw
        row['motion_' + mode + '_bytes'] = len(packet)

        transformed_alpha = op_header + bytes(gap_bytes) + pack_values(alpha_values, mode)
        alpha_packet, decoded = envelope(transformed_alpha, layout=layout + 3)
        restore = _Reader(decoded)
        restored_header = bytes(restore.take(HEADER.size))
        restored_gaps, _ = take_varints(restore, updates)
        restored_values = unpack_values(restore, updates, 1, mode)
        restored_body = b''.join(_uvar(gap) + restored_values[i].tobytes()
                                 for i, gap in enumerate(restored_gaps))
        assert restored_header == op_header and restored_body == op_body
        assert restore.cursor == len(decoded)
        row['opacity_' + mode + '_bytes'] = len(alpha_packet)
        verified_probes += 2

    for name, array in [('gs_translation', point['t']), ('gs_rotation', point['r']),
                        ('opacity', alpha_values)]:
        row.update({name + '_' + k: v for k, v in symbol_stats(array).items()})
        histograms[name].update(int(x) for x in np.abs(array.astype(np.int64)).sum(axis=1))
    rows.append(row)
    if frame in [270, 279, 289, 299]:
        print(json.dumps(dict(frame=frame, complete=row['complete_update_bytes'],
            motion_planar16=row['motion_planar16_bytes'],
            opacity_planar16=row['opacity_planar16_bytes'],
            elapsed=time.monotonic() - started)), flush=True)

means = {key: statistics.mean(row[key] for row in rows) for key in rows[0] if key != 'frame'}
for key, expected in comparison['cases']['sparse_tralpha']['means'].items():
    if key in means:
        assert abs(means[key] - expected) < 1e-8
totals = {key: sum(row[key] for row in rows) for key in rows[0] if key != 'frame'}
outer_share = {key: 100 * means[key] / means['complete_update_bytes'] for key in [
    'motion_bytes', 'opacity_bytes', 'birth_attribute_bytes', 'manifest_bytes']}
raw_share = {key: 100 * means[key] / means['motion_raw_bytes'] for key in [
    'header_bytes', 'survivor_mapping_bytes', 'gate_bitmap_bytes', 'region_section_bytes',
    'gs_section_bytes', 'birth_source_bytes', 'birth_pose_bytes', 'checksum_bytes']}
assert abs(sum(raw_share.values()) - 100) < 1e-10
probes = {}
for motion_mode in ['unchanged', 'planar16', 'byteplanes', 'zigzag']:
    for alpha_mode in ['unchanged', 'zlib9', 'auto', 'planar16', 'byteplanes', 'zigzag']:
        key = motion_mode + '+' + alpha_mode
        motion_key = 'motion_bytes' if motion_mode == 'unchanged' else 'motion_' + motion_mode + '_bytes'
        alpha_key = 'opacity_bytes' if alpha_mode == 'unchanged' else 'opacity_' + alpha_mode + '_bytes'
        total = means[motion_key] + means[alpha_key] + means['birth_attribute_bytes'] + means['manifest_bytes']
        probes[key] = dict(complete_update_bytes=total,
            savings_bytes=means['complete_update_bytes'] - total,
            savings_percent=100 * (1 - total / means['complete_update_bytes']))

result = dict(scope='Read-only packets 270-299 from late-window migration; no training or pruning policy change.',
    run=str(RUN), frames=30, means=means, totals=totals,
    compressed_file_share_percent=outer_share, raw_motion_share_percent=raw_share,
    warning='Raw motion sections are exact before joint entropy compression; compressed section shares are not additive.',
    probe_warning='Standalone reversible layout probes with included AUD1 envelope; not a deployed production codec.',
    layout_probes=probes, roundtrip_verified_probes=verified_probes,
    sparse_gradient='For nonzero block q, derivative factor is exp(-L1(q)/width)/width; width=1.',
    histogram_bin='L1 norm of quantized nonzero block',
    histograms={name: dict(sorted(hist.items())) for name, hist in histograms.items()},
    source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    elapsed_seconds=time.monotonic() - started)
with (OUT / 'per_frame_v2.csv').open('x', newline='') as handle:
    writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
(OUT / 'audit_v2.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(means=means, compressed_share=outer_share, raw_share=raw_share,
    probes=probes, roundtrips=verified_probes, elapsed_seconds=result['elapsed_seconds'])), flush=True)
