"""Summarize the completed replacement run against the same historical prefix."""
from pathlib import Path
import csv
import hashlib
import json
import statistics
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import torch
from pipeline.model.rigid_tree_codec import _Reader, uncompressed_motion_packet
from scripts.benchmark_rigid_residual_tree import _sequence_groups

OUT = Path(__file__).resolve().parent
NEW = ROOT/'output/fs_ste_replace_depth4_rate003_first30_20261017/20261017T103635_f905d1'
OLD = ROOT/'output/fs_ste_depth4_rate003_full300_20261017/20261017T022827_f74b2a'


def deletion_bytes(path):
    packet = uncompressed_motion_packet(path.read_bytes())
    reader = _Reader(packet)
    assert bytes(reader.take(4)) == b'SPG1'
    reader.take(32)
    for _ in range(4):
        reader.integer()
    reader.take(40)
    start = reader.cursor
    mode = reader.take(1)[0]
    count = 0
    if mode == 1:
        count = reader.integer()
        for _ in range(count):
            reader.integer()
    elif mode != 0:
        raise ValueError('Invalid survivor mode')
    return count, reader.cursor - start


rows = []
by_run = {}
for tag, run in [('historical_no_replacement', OLD), ('replacement', NEW)]:
    summaries = []
    for frame in range(1, 30):
        item = json.loads((run/'frame_summary'/f'frame_{frame:03d}.json').read_text())
        stream = run/'frame_storage/rigid_tree'
        manifest_path = stream/f'frame_{frame:03d}.json'
        manifest = json.loads(manifest_path.read_text())
        deleted, map_bytes = deletion_bytes(stream/manifest['motion'])
        assert item['frame'] == frame
        assert deleted == item.get('retired_count', 0)
        motion_bytes = (stream/manifest['motion']).stat().st_size
        birth_bytes = (stream/manifest['birth']).stat().st_size if manifest['birth'] else 0
        assert motion_bytes + birth_bytes == item['encoded_bytes']
        entry = dict(case=tag, frame=frame,
            psnr=item['evaluation']['test']['psnr'],
            ssim=item['evaluation']['test']['ssim'],
            lpips=item['evaluation']['test']['lpips'],
            old_count=item['old_count'], birth_count=item['birth_count'],
            total_count=item['total_count'], retired_count=deleted,
            retired_older_count=item['birth_control'].get('retirement', {}).get('retired_older_count', 0),
            retired_previous_birth_count=item['birth_control'].get('retirement', {}).get('retired_previous_birth_count', 0),
            region_count=item['region_count'],
            motion_bytes=motion_bytes, birth_attribute_bytes=birth_bytes,
            payload_bytes=motion_bytes + birth_bytes,
            manifest_bytes=manifest_path.stat().st_size,
            complete_update_bytes=motion_bytes + birth_bytes + manifest_path.stat().st_size,
            raw_deletion_map_bytes=map_bytes,
            extra_raw_deletion_bytes=map_bytes - 1,
            elapsed_seconds=item['elapsed_seconds'])
        if tag == 'replacement':
            assert item['old_count'] == 206237
            if frame > 1:
                assert deleted == summaries[-1]['birth_count']
                assert item['previous_count'] == summaries[-1]['total_count']
            assert manifest['no_old_deletions'] == (deleted == 0)
        summaries.append(entry)
    rows += summaries
    mean_fields = ['psnr', 'ssim', 'lpips', 'birth_count', 'region_count',
        'motion_bytes', 'birth_attribute_bytes', 'payload_bytes', 'manifest_bytes',
        'complete_update_bytes', 'raw_deletion_map_bytes', 'extra_raw_deletion_bytes',
        'elapsed_seconds']
    by_run[tag] = dict(run=str(run), dynamic_frames=29,
        means={name: statistics.mean(row[name] for row in summaries) for name in mean_fields},
        final_total_count=summaries[-1]['total_count'],
        final_birth_count=summaries[-1]['birth_count'],
        total_births=sum(row['birth_count'] for row in summaries),
        total_retired=sum(row['retired_count'] for row in summaries),
        retired_older_count=sum(row['retired_older_count'] for row in summaries),
        retired_previous_birth_count=sum(row['retired_previous_birth_count'] for row in summaries),
        final_frame=summaries[-1])
old = by_run['historical_no_replacement']['means']
new = by_run['replacement']['means']
result = dict(scope='Shared reference frame0 + first29 dynamic frames; not a full300 result.',
    cases=by_run, delta_means={name: new[name] - old[name] for name in new},
    complete_update_reduction_percent=100 * (1 - new['complete_update_bytes'] / old['complete_update_bytes']),
    invariants=dict(fixed_old_budget=True, previous_births_retired_next_frame=True,
                    deletion_count_matches_packet=True, deleted_ids_in_payload=True))

benchmark_path = OUT/'benchmark.json'
if benchmark_path.exists():
    benchmark = json.loads(benchmark_path.read_text())
    old_benchmark = json.loads((ROOT/'output/fs_ste_rate_sweep_full300_20261017/rate003_benchmark.json').read_text())
    result['new_benchmark_groups'] = benchmark['groups']
    result['historical_same_prefix_benchmark_groups'] = _sequence_groups(old_benchmark['frames'][:30], 30)
    result['benchmark_verification'] = dict(
        measured_frames=benchmark['measured_frames'],
        max_cache_pixel_difference=max(row['cache_pixel_max_abs_difference'] for row in benchmark['frames']),
        max_quality_difference={name: max(abs(row['quality_saved_difference'][name])
            for row in benchmark['frames'][1:]) for name in ['psnr', 'ssim', 'l1']})

with (OUT/'per_frame_comparison.csv').open('w') as file:
    writer = csv.DictWriter(file, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
(OUT/'comparison.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({key: value for key, value in result.items() if key not in [
    'new_benchmark_groups','historical_same_prefix_benchmark_groups']}, indent=2))
