"""Resume an actually pruned mid-motion checkpoint without retiring twice."""
from pathlib import Path
import json
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import torch
from pipeline.entry import Pipeline
from pipeline.model.birth_quantization import reference_digest
from scripts.replay_rigid_tree import replay
from scripts.benchmark_rigid_residual_tree import (
    _load_config, _capture_raw, check_gpu_exclusivity)

OUT = Path(__file__).resolve().parent
RUN = ROOT/'output/fs_ste_replace_depth4_rate003_first30_20261017/20261017T103635_f905d1'
check_gpu_exclusivity()
cfg = _load_config(RUN)
cfg.output_dir = OUT
cfg.experiment_name = 'resume_frame9_step70'
cfg.ckpt_path = RUN/'rigid-ckpt-9-70.pth'
pipeline = Pipeline(cfg)
trainer, module = pipeline.trainer, pipeline.module
trainer.setup(module, cfg.ckpt_path)
pipeline.save_config()
initial_retirement = dict(module.birth_control['retirement'])
initial_old_count = len(module.gaussians._xyz)
initial_deleted_rows = module.retired_reference['rows'].detach().cpu().clone()
started = time.perf_counter()
report = trainer.frame_training_loop()
duration = time.perf_counter() - started
assert initial_old_count == report['old_count'] == 206237
assert initial_retirement == report['birth_control']['retirement']
assert report['retired_count'] == len(initial_deleted_rows)
directory = pipeline.output_dir/'frame_storage/rigid_tree'
reference = trainer.decoder_reference_path
state, raw = replay(directory, reference, through=9)
saved_raw, _ = _capture_raw(pipeline.output_dir/'rigid-ckpt-9-200.pth', 9, 200)
assert all(torch.equal(raw[name], saved_raw[name]) for name in raw)
original = json.loads((RUN/'frame_summary/frame_009.json').read_text())
result = dict(source_checkpoint=str(cfg.ckpt_path), output=str(pipeline.output_dir),
    reference=str(reference), reference_frame=8, final_frame=state.frame_index,
    resumed_steps=report['train_loss_steps'], seconds=duration,
    retained_old_count=report['old_count'], retired_count=report['retired_count'],
    retirement_not_repeated=True, decoded_raw_matches_checkpoint=True,
    resumed_test=report['evaluation']['test'], original_test=original['evaluation']['test'],
    psnr_difference=report['evaluation']['test']['psnr'] - original['evaluation']['test']['psnr'],
    resumed_births=report['birth_count'], original_births=original['birth_count'],
    decoded_raw_sha256=reference_digest(raw))
(OUT/'resume_audit.json').write_text(json.dumps(result, indent=2)+'\n')
if trainer.tb_writer is not None:
    trainer.tb_writer.close()
print(json.dumps(result, indent=2))
