# 当前保留的实验

最新机制修复为 [区域/gate 图像联合优化与实际码率校准](experiment/20261017_joint_image_codec_validation.md)：区域与 gate 接收图像梯度，去除逐步抵消，step70 后仅固定 gate、区域和 GS 继续训练。运动码率采用真实字节统计与实际包长校准；前20步实测，之后按20步窗口及70/100步校准，其余步为估计。**192项回归与独立回放通过，但存储尚未改善**：最终帧1为34.3874dB /155.802KB，帧270为32.3780dB /151.022KB，不能作为300帧均值。gate相对全细分的独立压缩收益仍约0.9%，下一步优先检查剩余平移残差的图像收益和新码率口径的约束强度。

此前训练改进是 [图像 Adam＋GS 近端稀疏优化，后 30 帧](experiment/20261017_proximal_gs_late270_299.md)：相同旧第 269 帧续跑，PSNR **33.2909 → 33.4669 dB**，完整更新 **151.406 → 87.874 KB，减少 41.96%**。GS 非零残差比例 **21.9% → 5.7%**，旋转残差平均 **36,681 → 687**；94.29% 的移动点无需逐 GS 残差。SSIM/LPIPS 略降，尚未达到完整 300 帧与 50 KB 目标。179 项测试、30 帧独立回放及原始状态检查通过；另完成 0.002 配方从共享首帧启动两个动态帧的核验。该历史配方使用 `proxgs_lossless` 实验名；没有重跑 300 帧。

此前完成 [无损编码接入及 gate/旋转核验](experiment/20261017_lossless_codec_gate_rotation.md)。对既有帧 270–299 通过正式编码器重新导出，完整动态更新 **188.492 → 151.406 KB，减少 19.68%**，连续解码的全部状态逐字节一致，175 项测试通过；未重跑 300 帧。发现大量旋转参数停在半 bin 门槛附近，三帧冻结检查显示其最小旋转残差收益很小。gate 在实际开合，76.53% 的移动点不需 GS 残差；但单帧 learned gate 相比全细分仅省约 0.58%，独立码率优势仍待改进。α＜0.01 删除保持不变。

此前三通道功能实验为 [平移/旋转/透明度联合量化与稀疏更新，后 30 帧续跑](experiment/20261017_sparse_tralpha_late270_299.md)。从旧第 269 帧继续训练 270–299，平均 **32.5682 → 33.2909 dB**，第 299 帧提高约 0.99 dB；每帧完整更新由 **131.257 增至 188.492 KB**。透明度平均新增 41.056 KB，运动包也变大，该历史配方属于**画质改善、存储回归**。171 项测试、全段独立回放与恢复检查通过；不是重新训练的完整 300 帧成绩。

该记录中的码流审计为接入前的离线结果：运动包占 74.74%、透明度占 21.78%，新增属性占 3.17%。离线布局探针为 151.404 KB；当前正式格式增加明确的原始/变换长度等字段后为 **151.406 KB**，并已完成正式导出与连续回放核验。

最新完整序列结果是 [STE gate、storage 0.002 / 0.003 的 300 帧对比](experiment/20261017_ste_storage002_vs003_full300.md)。两组均已训练完成并独立核验全部 300 帧。0.002 为 **33.0724 dB、127.338 KB/动态帧、199.494 纯渲染 FPS**；0.003 为 **33.2902 dB、119.698 KB/动态帧、199.820 纯渲染 FPS**。本次 0.003 的 PSNR 高 0.2178 dB，完整更新量少 6.00%，两组仍未达到画质与存储目标。

针对后段退化，已完成 [定向诊断](experiment/20261017_late_degradation_diagnosis.md)：第 299 帧保留新点从 327 增至 4705 只提高约 0.008 dB，却增加约 192 KB 负载；同点数、无量化/码率约束的透明度诊断可提高约 0.82 dB。历史实现缺少旧点替换，GS 非零块字节项对运动向量没有直接梯度，且压缩效率变化未被块计数充分反映。

此前完成 [ReCon-GS 式固定预算替换的前 30 帧核验](experiment/20261017_recongs_replacement_first30.md)：相同 29 动态帧平均 **34.2249 → 34.2612 dB，106.904 → 101.927 KB**。其按固定 α 排序的问题已在本次实验中改为学习当前 α，再删除低 α 点；不再强制新增 K 个就删除 K 个。固定预算结果保留为历史记录。

| 内容 | 记录 | 结果目录 |
|---|---|---|
| 图像联合优化、实际码率校准与残差诊断 | [联合优化与字节核验](experiment/20261017_joint_image_codec_validation.md) | `output/fs_joint_image_codec_validation_20261017/` |
| GS 近端稀疏优化，续跑 270–299；0.002 启动检查 | [残差优化与独立核验](experiment/20261017_proximal_gs_late270_299.md) | `output/fs_proximal_gs_validation_20261017/` |
| 新编码器重导出 270–299，gate/旋转诊断 | [编码与机制核验](experiment/20261017_lossless_codec_gate_rotation.md) | `output/fs_lossless_gate_rotation_validation_20261017/` |
| 三通道量化与稀疏更新，续跑 270–299 | [画质与实际存储核验](experiment/20261017_sparse_tralpha_late270_299.md) | `output/fs_sparse_tralpha_validation_20261017/` |
| ReCon-GS 式替换，前 30 帧 | [替换与回放核验](experiment/20261017_recongs_replacement_first30.md) | `output/fs_ste_replace_depth4_rate003_first30_20261017/` |
| STE、storage 0.002，完整 300 帧 | [0.002 记录](experiment/20261017_ste_storage002_full300.md) | `output/fs_ste_depth4_rate002_full300_20261017/` |
| STE、storage 0.003，完整 300 帧 | [0.003 记录](experiment/20261017_ste_storage003_full300.md) | `output/fs_ste_depth4_rate003_full300_20261017/` |
| 此前 350 W 稳定性训练，30 帧 | [30 帧记录](experiment/20261016_gpu_350w_training_first30.md) | `output/fs_gpu_stability_350w_worldroute_first30_20261016/` |
| 此前长序列退化检查，实际完成 200 帧 | [200 帧记录](experiment/20261015_spatial_gate_worldroute200_stopped200.md) | `output/fs_spatial_gate_worldroute_200_full300_20261015/` |
| 稳健树初始化 CPU 审计 | [初始化审计](experiment/20261016_spatial_gate_robust_initialization_cpu.md) | `output/fs_spatial_gate_initialization_audit_20261016/` |

完整更新量含每帧 manifest，KB=1000 B，一次性首帧参考 17720236 B 另计。纯渲染 FPS 不含解码、验证和上传。逐帧 CSV、对比曲线和两次 benchmark 见完整对比记录；[轻量证据归档](archive/ste_storage002_003_full300_20261017.tar.gz) 保存固定源码与结果文本，原始训练产物仍在本地 output。

本轮实现提速核验单列为 [训练冗余与提速记录](experiment/20261016_training_redundancy_speed.md)：这是单帧执行速度检查，不是新增的全序列画质结果。

基础配置为 `config/fs_spatial_gate_depth4_200_full300_20261016.yaml`：最大深度 4、storage 权重 0.002、robust_median 初始化、远点连最近非空叶区域；首个动态帧细分 gate 全关，后续继承前帧 gate；前 70 步联合训练，后 30 步只固定 gate，区域运动与 GS 残差继续共同拟合图像。运动每步 2 个视角，新增 GS 再训练 100 步（每步 1 个视角）。当前开启 opacity 更新、可微稀疏支持、GS 近端收缩、`spatial_gate.joint_image_gradients` 以及 `rate_model: codec`；真实码率初始实测20步、之后每20步及70/100步校准。按当前 α＜0.01 删点，旧 opacity logit 步长为0.05，固定数量替换关闭。GS Adam 只收图像梯度，已有残差约束由近端步骤实现。两份入口使用新的 `fs_joint_image_codec_rate00x_full300_20261017` 实验名；0.003入口仍为 `config/fs_ste_sparse_tralpha_rate003_full300_20261017.yaml`。最新只完成启动和后段短验证，尚未重新训练完整300帧。

此前固定预算替换入口 `config/fs_ste_replace_depth4_rate003_full300_20261017.yaml` 保持其历史设置，可用于读取和复现对应短测。

历史完整序列入口为 `config/fs_ste_depth4_rate002_full300_20261017.yaml` 和 `config/fs_ste_depth4_rate003_full300_20261017.yaml`，两者保持替换关闭，除实验名及权重外设置相同。两次执行同一固定源码，运行来源保存在 `output/fs_ste_rate_sweep_full300_20261017/`。

此前 [learnable gate 的 STE 与优化坐标核验](experiment/20261017_learnable_gate_ste_first6.md) 为共享首帧加五个动态帧：区域数 8、8、287、286、293，动态平均 34.4726 dB、完整更新 126.10 KB。它只用于短测机制检查；完整 300 帧结果已如上，不可用短测均值替代。

此前 [全关初始化短测](experiment/20261016_joint70_closedfirst_2view_first3.md) 为两动态帧平均 34.4233 dB、137.81 KB；[全开初始化短测](experiment/20261016_joint70_robustnearest_2view_first3.md) 为两动态帧平均 34.4122 dB、139.72 KB。这些是 STE/优化坐标修复之前的结果，不可与五帧均值直接比较。

此前保留的 30 帧和 200 帧训练结果来自五层、0.03 配方，不能当作当前配置的结果。初始化 CPU 审计只覆盖建树候选本身，与训练结果分别记录。

`config/` 保留基础配置、本次三通道 0.003 入口、此前替换 0.003 入口、两个完整 300 帧入口，以及历史 30 帧配置、200 帧续训入口与 robust_median 候选，共 8 份 YAML。历史 200 帧续训入口使用保留的最后检查点和新 experiment_name；历史 run 内的原配置保持不变。

演示视频为 `output/4dgs_flame_steak_demo_1920x1080_20261016_122523.mp4`，同名 `.manifest.json` 保存来源帧摘要和视频核验信息。来源链中的旧训练目录已清理，成片仍可直接播放。

2026-10-16 清理前的实验记录、YAML 和轻量诊断文本保存在 `archive/history_before_20261016_cleanup.tar.gz`。归档不包含已删除的原始训练产物；删除清单、保留项和空间统计见 `archive/cleanup_20261016.json`。例如读取旧联合训练记录：

```bash
tar -xOf docs/archive/history_before_20261016_cleanup.tar.gz docs/experiment/20261014_spatial_gate_joint_first5.md
```
