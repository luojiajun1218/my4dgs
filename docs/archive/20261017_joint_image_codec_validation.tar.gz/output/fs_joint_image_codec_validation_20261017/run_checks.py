"""Bounded startup and late-window validation; no full300 training."""
from dataclasses import asdict
import copy
import gc
import hashlib
import json
from pathlib import Path
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
LATE_ONLY = '--late-only' in sys.argv
CALIBRATED = '--calibrated' in sys.argv
SINGLE_FRAME = '--single-frame' in sys.argv
SNAPSHOT = OUT / ('source_snapshot_v5' if CALIBRATED else 'source_snapshot_v3')
STATUS_NAME = 'calibrated_status' if CALIBRATED else 'training_status'
# Verify the frozen Python/config sources, then execute the workspace copy so
# the existing CUDA extension keeps its real source/include and build paths.
manifest = json.loads((SNAPSHOT / 'source_manifest.json').read_text())
assert all(hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == digest
           for path, digest in manifest['hashes'].items())
sys.path.insert(0, str(ROOT))
import torch
from omegaconf import OmegaConf
from libgs.utils.config import to_structured
from pipeline.entry import Config, Pipeline
from pipeline.model.sparse_updates import OpacityUpdateConfig, QuantizedOpacityUpdate
from scripts.benchmark_rigid_residual_tree import _load_config, check_gpu_exclusivity


def serial(value):
    return OmegaConf.to_container(value, resolve=True) if OmegaConf.is_config(value) else str(value)


if LATE_ONLY:
    status = json.loads((OUT / 'training_status.json').read_text())
    assert len(status['runs']) == 1 and status['runs'][0]['complete']
    status['runs'][0]['snapshot'] = str(OUT / 'source_snapshot_v2')
    status.pop('error', None)
    status['snapshot'] = str(SNAPSHOT)
else:
    status = dict(complete=False, snapshot=str(SNAPSHOT), execution_root=str(ROOT),
                  source_hashes_verified=True, no_full300_run=True, runs=[])


def save():
    target = OUT / f'{STATUS_NAME}.json'
    temporary = OUT / f'{STATUS_NAME}.tmp'
    temporary.write_text(json.dumps(status, indent=2, default=serial) + '\n')
    temporary.replace(target)


def gradients(loss, motion):
    names = ['region_T', 'region_R', 'gs_T', 'gs_R', 'gate']
    values = torch.autograd.grad(loss, [motion.region_translation, motion.region_rotation,
        motion.gs_translation, motion.gs_rotation, motion.gate_logits], retain_graph=True, allow_unused=True)
    return {name: None if value is None else dict(abs_sum=float(value.abs().sum()),
        nonzero=int(value.ne(0).sum()), finite=bool(value.isfinite().all()))
        for name, value in zip(names, values)}


def run(late=False):
    check_gpu_exclusivity()
    if late:
        source = ROOT / 'output/fs_ste_depth4_rate003_full300_20261017/20261017T022827_f74b2a'
        cfg = _load_config(source)
        cfg.ckpt_path = source / 'rigid-ckpt-269-200.pth'
        name, frames = ('late270_271_calibrated_rate003', [270, 271]) if CALIBRATED else ('late270_272_rate003_v3', [270, 271, 272])
    else:
        cfg, extra = to_structured(OmegaConf.load(ROOT / 'config/fs_spatial_gate_depth4_200_full300_20261016.yaml'), Config)
        assert not extra, extra
        name, frames = ('startup1_2_calibrated_rate002', [1, 2]) if CALIBRATED else ('startup1_3_rate002_v2', [1, 2, 3])
    if SINGLE_FRAME:
        frames = frames[:1]
        name += '_initial20'
    cfg.output_dir, cfg.experiment_name = OUT, name
    if not late:
        cfg.trainer.saving_ckpt_frames = [frames[0], frames[-1]]
        cfg.trainer.saving_ckpt_steps = [70, 100, 200]
    pipeline = Pipeline(cfg)
    trainer, module = pipeline.trainer, pipeline.module
    trainer.setup(module, cfg.ckpt_path)
    source_config = asdict(module.config)
    if late:
        assert module.frame_finalized and module.current_frame == 269
        cfg.module.rigid_tree.spatial_gate.joint_image_gradients = True
        cfg.module.rigid_tree.rate_model = 'codec'
        cfg.module.rigid_tree.codec_rate_interval = 20 if CALIBRATED else 1
        cfg.module.rigid_tree.codec_rate_initial_steps = 20 if CALIBRATED else 0
        cfg.module.rigid_tree.proximal_gs_regularization = True
        cfg.module.rigid_tree.differentiable_rate_support = True
        cfg.module.birth.replace_low_opacity = False
        cfg.module.opacity_update = OpacityUpdateConfig(enabled=True, step=.05, learning_rate=.05, prune_threshold=.01)
        module.opacity_update = QuantizedOpacityUpdate(cfg.module.opacity_update)
        trainer._restore_rng(trainer._resume_rng)
        trainer._resume_rng = None
        module.begin_next_frame()
    else:
        assert trainer.is_first_frame
    trainer.global_step = 0
    cfg.trainer.saving_ckpt_frames = [frames[0], frames[-1]]
    cfg.trainer.saving_ckpt_steps = [70, 100, 200]
    cfg.module.rigid_tree.validate()
    pipeline.save_config()
    record = dict(name=name, output=str(pipeline.output_dir), frames=frames, snapshot=str(SNAPSHOT), source_checkpoint=str(cfg.ckpt_path),
        checkpoint_sha256=hashlib.sha256(Path(cfg.ckpt_path).read_bytes()).hexdigest(),
        source_config=source_config, effective_config=asdict(module.config),
        image_gradients=[], gate_freeze=[], rate_checks=[], rate_prediction_checks=[], results=[], complete=False)
    status['runs'].append(record)
    save()
    original_training = module.training_step
    def training(viewpoint, step, regularization_weight=1.):
        result = original_training(viewpoint, step, regularization_weight)
        if module.current_frame == frames[0] and regularization_weight == 0 and step in (5, 69, 71, 99):
            record['image_gradients'].append(dict(step=step, photometric_only=True,
                gradients=gradients(result[0], module.motion)))
            if CALIBRATED:
                # Compare against an independent copy so this diagnostic does
                # not refresh the training model or alter its 20-step cadence.
                from pipeline.model.motion_rate import MotionCodecRate
                motion = module.motion
                with torch.no_grad():
                    estimated = float(motion.loss_terms(step, False)['rate_bytes_surrogate'])
                    clone = MotionCodecRate.restore(copy.deepcopy(motion._codec_rate.capture()))
                    values = [value.cpu() for value in motion._values(hard=True)]
                    actual = clone.measure(*values, motion.opened.cpu(), step)
                record['rate_prediction_checks'].append(dict(step=step, estimated=estimated,
                    actual=actual, relative_error=estimated/actual-1,
                    calibration_step=motion._codec_rate.last_measure_step))
            save()
        return result
    module.training_step = training
    original_post = module.post_training_step
    def post(package):
        step = trainer.global_step
        capture = module.current_frame == frames[0] and step in (70, 71, 99)
        if capture:
            motion = module.motion
            gates = motion.gate_logits.detach().clone()
            region = motion.region_translation.detach().clone()
            point = motion.gs_translation.detach().clone()
        result = original_post(package)
        if capture:
            record['gate_freeze'].append(dict(step=step, frozen=module.motion._hard_gate_frozen,
                changed_gate_logits=int(module.motion.gate_logits.ne(gates).sum()),
                changed_region_components=int(module.motion.region_translation.ne(region).sum()),
                changed_point_components=int(module.motion.gs_translation.ne(point).sum())))
            save()
        return result
    module.post_training_step = post
    started = time.perf_counter()
    for frame in frames:
        trainer.datamodule.current_frame = frame
        report = trainer.frame_training_loop()
        manifest = pipeline.output_dir / 'frame_storage/rigid_tree' / f'frame_{frame:03d}.json'
        full = report['encoded_bytes'] + manifest.stat().st_size
        record['results'].append(dict(frame=frame, psnr=report['evaluation']['test']['psnr'],
            ssim=report['evaluation']['test']['ssim'], lpips=report['evaluation']['test'].get('lpips'),
            payload_bytes=report['encoded_bytes'], full_bytes=full,
            motion_bytes=report['motion']['bytes'], opacity_bytes=(report.get('opacity_update') or {}).get('archive_bytes', 0),
            birth_bytes=(report.get('birth') or {}).get('archive_bytes', 0),
            regions=report['region_count'], gs_residuals=report['motion_rate_diagnostics']['gs_active_rows'],
            rotation_blocks=report['motion_rate_diagnostics']['gs_rotation_active_blocks'],
            elapsed_seconds=report['elapsed_seconds']))
        with torch.no_grad():
            terms = module.motion.loss_terms(100, diagnostics=True)
        record['rate_checks'].append(dict(frame=frame, old_point_codec_bytes=float(terms['rate_bytes_surrogate']),
            measured_bytes=module.motion._codec_rate.last_packet_bytes,
            entropy_bytes=float(terms['rate_entropy_bytes']), scale=float(terms['rate_codec_gradient_scale'])))
        save()
        module.begin_next_frame()
        trainer.global_step = 0
    photo = {row['step']: row['gradients'] for row in record['image_gradients']}
    assert any(photo[step]['gate'] is not None and photo[step]['gate']['abs_sum'] > 0 for step in (5, 69))
    for step in (71, 99):
        assert photo[step]['gate'] is None
        assert photo[step]['region_T']['abs_sum'] > 0 and photo[step]['gs_T']['abs_sum'] > 0
    for row in record['gate_freeze']:
        assert row['frozen'] and (row['step'] == 70 or row['changed_gate_logits'] == 0)
        assert row['changed_region_components'] > 0 and row['changed_point_components'] > 0
    record.update(complete=True, seconds=time.perf_counter() - started)
    save()
    if trainer.tb_writer is not None:
        trainer.tb_writer.close()
    del trainer, module, pipeline
    gc.collect()
    torch.cuda.empty_cache()


save()
try:
    if not LATE_ONLY:
        run(False)
    run(True)
    status['complete'] = True
except BaseException as error:
    status['error'] = repr(error)
    raise
finally:
    save()
print(json.dumps(dict(complete=status['complete'], outputs=[r['output'] for r in status['runs']]), indent=2))
