"""Compare old/new wire bytes and CPU rate measurement on a real checkpoint."""
import copy
import importlib.util
import json
from pathlib import Path
import statistics
import sys
import time
from unittest.mock import patch

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT))
import torch
from pipeline.model import rigid_tree_codec as codec
from pipeline.model.motion_rate import MotionCodecRate
from pipeline.model.spatial_gated_motion import SpatialGatedMotion
from scripts.benchmark_rigid_residual_tree import _load_config


def load(name, path):
    specification = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


torch.set_num_threads(2)
status = json.loads((OUT / 'training_status.json').read_text())
record = status['runs'][0]
run = Path(record['output'])
frame = record['frames'][-1]
packet = torch.load(run / f'rigid-ckpt-{frame}-100.pth', map_location='cpu', weights_only=False)['rigid_tree_motion']
model = SpatialGatedMotion(_load_config(run).module.rigid_tree)
model.restore(packet)
model._measure_codec_rate(100)
state = copy.deepcopy(model._codec_rate.capture())
values = [value.cpu() for value in model._values(hard=True)]
old_sparse = load('sparse_integer_codec_reference', OUT / 'source_snapshot_v2/pipeline/model/sparse_integer_codec.py')
old_rate = load('pipeline.model.motion_rate_reference', OUT / 'source_snapshot_v2/pipeline/model/motion_rate.py')
old = old_rate.MotionCodecRate.restore(copy.deepcopy(state))
new = MotionCodecRate.restore(copy.deepcopy(state))
old_times, new_times = [], []
for _ in range(4):
    with patch.object(codec, 'encode_motion_layout', old_sparse.encode_motion_layout):
        started = time.perf_counter()
        old_bytes = old.measure(*values, model.opened.cpu(), 100)
        old_times.append(time.perf_counter() - started)
        old_packet = old.packet(*values, model.opened.cpu())
    started = time.perf_counter()
    new_bytes = new.measure(*values, model.opened.cpu(), 100)
    new_times.append(time.perf_counter() - started)
    new_packet = new.packet(*values, model.opened.cpu())
    assert old_packet == new_packet and old_bytes == new_bytes
    assert old.last_entropy_bytes == new.last_entropy_bytes
matches = []
all_runs = list(status['runs'])
for filename in ('calibrated_status_v4.json', 'calibrated_status.json'):
    all_runs.extend(json.loads((OUT / filename).read_text())['runs'])
for row in all_runs:
    stream = Path(row['output']) / 'frame_storage/rigid_tree'
    for path in sorted(stream.glob('motion_*.bin')):
        stored = path.read_bytes()
        raw = codec.uncompressed_motion_packet(stored)
        assert codec.compress_motion_packet(raw, 'auto') == stored
        matches.append(str(path))
result = dict(complete=True, frame=frame, point_count=len(model.owner),
    old_seconds=old_times, new_seconds=new_times,
    old_median_seconds=statistics.median(old_times), new_median_seconds=statistics.median(new_times),
    rate_measure_speedup=statistics.median(old_times) / statistics.median(new_times),
    measured_packet_and_entropy_identical=True, stored_motion_packets_reencoded_identically=matches,
    scope='CPU rate measurement only; this is not an end-to-end training speed benchmark.')
(OUT / 'serializer_check.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
