"""Fixed-motion capacity probe, not a production codec or training ablation."""
import json
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT))
import numpy as np
import torch
from pipeline.model.spatial_gated_motion import SpatialGatedMotion
from scripts.benchmark_rigid_residual_tree import _load_config

torch.set_num_threads(2)
status = json.loads((OUT / 'calibrated_status.json').read_text())
results = []


def mode_count(values):
    _, counts = np.unique(values, axis=0, return_counts=True)
    return int(counts.max())


for record in status['runs']:
    run, frame = Path(record['output']), record['frames'][-1]
    model = SpatialGatedMotion(_load_config(run).module.rigid_tree)
    model.restore(torch.load(run / f'rigid-ckpt-{frame}-100.pth', map_location='cpu', weights_only=False)['rigid_tree_motion'])
    xyz = model.base_xyz.numpy().astype(np.float64)
    full = model._full_motion_symbols()[0].detach().numpy().astype(np.int32)
    step = float(model.gs_steps[0])
    for name, groups in [('selected', model.owner.numpy()), ('finest', model.spatial_paths[:, -1].numpy())]:
        order = np.argsort(groups, kind='stable')
        nodes, starts = np.unique(groups[order], return_index=True)
        baseline, rigid, affine, rigid_groups, affine_groups = 0, 0, 0, 0, 0
        for node, members in zip(nodes, np.split(order, starts[1:])):
            points, target = xyz[members], full[members]
            initial = len(members) - mode_count(target)
            baseline += initial
            if len(members) < 8 or initial == 0:
                rigid += initial
                affine += initial
                continue
            center = np.median(points, axis=0)
            centered = points - center
            radius = np.linalg.norm(centered, axis=1)
            fit = radius <= np.quantile(radius, .999)
            design = np.c_[centered, np.ones(len(centered))]
            coefficients = np.linalg.lstsq(design[fit], target[fit] * step, rcond=1e-6)[0][:3]
            skew = (coefficients - coefficients.T) / 2
            for kind, field in [('rigid', skew), ('affine', coefficients)]:
                quantized = np.rint(field / .001) * .001
                prediction = np.rint(centered @ quantized / step).astype(np.int64)
                count = len(members) - mode_count(target - prediction)
                # Choosing an expressive model is only a capacity upper bound:
                # no extra coefficient or selection bytes are charged here.
                count = min(initial, count)
                if kind == 'rigid':
                    rigid += count
                    rigid_groups += int(count < initial)
                else:
                    affine += count
                    affine_groups += int(count < initial)
        results.append(dict(frame=frame, grouping=name, groups=len(nodes),
            constant_translation_exceptions=baseline,
            linearized_position_rotation_exceptions=rigid, rotation_helped_groups=rigid_groups,
            affine_position_exceptions=affine, affine_helped_groups=affine_groups,
            rotation_exception_reduction=1-rigid/max(1, baseline), affine_exception_reduction=1-affine/max(1, baseline)))
result = dict(scope='Position-dependent shared-motion capacity only. Same integer target motion, but new motion coefficients/selection have no implemented wire format; extra dictionary and selection costs are NOT included. Counts are not byte savings or quality results.', rows=results)
(OUT / 'motion_capacity.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
