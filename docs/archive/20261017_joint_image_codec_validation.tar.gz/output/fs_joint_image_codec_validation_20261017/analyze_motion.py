"""Locate remaining translation exceptions without changing any motion."""
import json
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT))
import numpy as np
import torch
from pipeline.model.spatial_gated_motion import SpatialGatedMotion
from scripts.benchmark_rigid_residual_tree import _load_config

torch.set_num_threads(2)
status = json.loads((OUT / 'calibrated_status.json').read_text())
assert status['complete']
rows = []
for record in status['runs']:
    run = Path(record['output'])
    frame = record['frames'][-1]
    model = SpatialGatedMotion(_load_config(run).module.rigid_tree)
    model.restore(torch.load(run / f'rigid-ckpt-{frame}-100.pth', map_location='cpu', weights_only=False)['rigid_tree_motion'])
    rt, _, gt, gr = model._values(hard=True)
    full_t = (rt[model.owner].int() + gt.int()).numpy()
    paths = model.spatial_paths[:, -1].numpy()
    order = np.argsort(paths, kind='stable')
    nodes, starts = np.unique(paths[order], return_index=True)
    nonmodal, second_support, leaves_mixed, dense_mixed_points = 0, 0, 0, 0
    for node, members in zip(nodes, np.split(order, starts[1:])):
        _, count = np.unique(full_t[members], axis=0, return_counts=True)
        count.sort()
        nonmodal += len(members) - int(count[-1])
        if len(count) > 1:
            leaves_mixed += 1
            second_support += int(count[-2])
        if count[-1] < .8 * len(members):
            dense_mixed_points += len(members)
    integer = gt.numpy().astype(np.int32)
    single = (np.count_nonzero(integer, axis=1) == 1) & (np.abs(integer).max(1) == 1)
    latent = (model.gs_translation.detach() / model.gs_steps[:3]).numpy()
    amplitude = np.abs(latent[single][integer[single] != 0])
    rows.append(dict(name=record['name'], frame=frame, old_points=len(gt),
        translation_blocks=int(gt.ne(0).any(-1).sum()), rotation_blocks=int(gr.ne(0).any(-1).sum()),
        one_bin_single_axis_translation_blocks=int(single.sum()),
        translation_blocks_with_latent_amplitude_050_051=int(((amplitude >= .5) & (amplitude <= .51)).sum()),
        median_single_bin_translation_amplitude=float(np.median(amplitude)) if len(amplitude) else None,
        supported_leaves=len(nodes), leaves_with_multiple_translation_vectors=leaves_mixed,
        nonmodal_translation_points_at_finest_level=nonmodal,
        second_most_frequent_translation_support_within_leaves=second_support,
        points_in_leaves_with_dominant_translation_fraction_below_080=dense_mixed_points))
result = dict(scope='Exact integer translation statistics at step100. A second motion per leaf is only a correlation diagnostic; assignment and extra dictionary costs have not been evaluated.', rows=rows)
(OUT / 'motion_structure.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
