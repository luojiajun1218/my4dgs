"""Read-only coding diagnostics of the finalized old-point motion field."""
import copy
import hashlib
import json
from pathlib import Path
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT))
import torch
from pipeline.model.spatial_gated_motion import SpatialGatedMotion
from scripts.benchmark_rigid_residual_tree import _load_config

torch.set_num_threads(2)
suffix = 'calibrated_' if '--calibrated' in sys.argv else ''
status = json.loads((OUT / ('calibrated_status.json' if suffix else 'training_status.json')).read_text())
records = []
for record in status['runs']:
    if not record['complete']:
        continue
    run = Path(record['output'])
    frame = record['frames'][-1]
    checkpoint = run / f'rigid-ckpt-{frame}-100.pth'
    packet = torch.load(checkpoint, map_location='cpu', weights_only=False)['rigid_tree_motion']
    config = _load_config(run).module.rigid_tree
    original = SpatialGatedMotion(config)
    original.restore(packet)
    full = tuple(value.clone() for value in original._full_motion_symbols())
    pose = tuple(value.detach().clone() for value in original(frame))
    cuts = []
    for cut in ('learned', 'learned_refit', 'coarse8_refit', 'finest_refit'):
        model = SpatialGatedMotion(copy.deepcopy(config))
        model.restore(copy.deepcopy(packet))
        if cut.startswith('coarse') or cut.startswith('finest'):
            with torch.no_grad():
                model.gate_logits[model.split_eligible] = -6. if cut.startswith('coarse') else 6.
            model._select_frontier(freeze=True)
            model._rebase_full_motion(full, preserve_remainder=True)
        if cut != 'learned':
            # Historical raw-byte/L1 representative search, used only as a
            # diagnostic candidate. Always measure the resulting real codec.
            model._refresh_active_representatives()
        started = time.perf_counter()
        actual, _ = model._measure_codec_rate(100, force=True)
        seconds = time.perf_counter() - started
        now = model._full_motion_symbols()
        assert all(torch.equal(a, b) for a, b in zip(full, now))
        current_pose = model(frame)
        _, _, gt, gr = model._values(hard=True)
        cuts.append(dict(cut=cut, old_motion_bytes=actual, regions=int(model.owner.unique().numel()),
            gs_residuals=int((gt.ne(0).any(-1) | gr.ne(0).any(-1)).sum()),
            translation_blocks=int(gt.ne(0).any(-1).sum()), rotation_blocks=int(gr.ne(0).any(-1).sum()),
            full_integer_motion_preserved=True,
            max_pose_difference=[float((a-b).abs().max()) for a,b in zip(pose,current_pose)],
            rate_measure_seconds=seconds))
    records.append(dict(name=record['name'], frame=frame, checkpoint=str(checkpoint),
        sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest(), cuts=cuts))
result = dict(scope='Read-only fixed integer motion diagnostic; excludes births and opacity; refit uses historical representative search, not a training ablation.', runs=records)
(OUT / f'{suffix}frontier.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
