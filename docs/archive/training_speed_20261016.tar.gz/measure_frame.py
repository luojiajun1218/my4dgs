"""Compare the same dynamic frame without modifying repository artifacts."""
import importlib.util
import json
from pathlib import Path
import sys
import time

import torch
from omegaconf import OmegaConf

ROOT = Path('/home/gamer-02/Documents/DeepLearning/my4dgs')
TEMP = Path('/tmp/my4dgs_training_speed')
sys.path.insert(0, str(ROOT))
import pipeline.entry as entry
from libgs.utils.config import to_structured


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, TEMP / filename)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


variant = sys.argv[1]
if variant == 'old':
    spatial = load('pipeline.model._speed_before', 'spatial_before.py')
    module = load('pipeline._speed_module_before', 'module_before.py')
    trainer = load('pipeline._speed_trainer_before', 'trainer_before.py')
    module.SpatialGatedMotion = spatial.SpatialGatedMotion
    entry.Module, entry.Trainer = module.Module, trainer.Trainer

settings = OmegaConf.load(ROOT / 'config/fs_spatial_gate_depth4_200_full300_20261016.yaml')
settings.output_dir = str(TEMP)
settings.experiment_name = 'measured_' + variant
settings.data.extra_dataset_kwargs.num_frames = 2
settings.trainer.saving_ckpt_frames = []
settings.module.num_saving_images = 0
settings.trainer.stage_image_camera = None
settings.data.eval_test = False
config, _ = to_structured(settings, entry.Config)

totals = {}
original = entry.Trainer._fit_views


def measured(self, fetcher, step):
    phase = ('free' if step <= 40 else 'shared_gate' if step <= 60 else
             'shared_residual' if step <= 100 else 'birth')
    started = time.perf_counter()
    result = original(self, fetcher, step)
    elapsed = time.perf_counter() - started
    totals[phase] = totals.get(phase, 0.) + elapsed
    return result


entry.Trainer._fit_views = measured
torch.cuda.init()
# Establish the same BLAS/CUDA context before both measurements.
torch.randn(256, 256, device='cuda').square().mean().item()
torch.cuda.reset_peak_memory_stats()
instance = entry.Pipeline(config)
started = time.perf_counter()
instance.run()
output = dict(variant=variant, phases_seconds=totals,
              all_training_steps_seconds=sum(totals.values()),
              process_seconds=time.perf_counter() - started,
              peak_allocated_bytes=torch.cuda.max_memory_allocated(),
              peak_reserved_bytes=torch.cuda.max_memory_reserved(),
              output=str(instance.trainer.output_dir))
(TEMP / ('measured_' + variant + '.json')).write_text(json.dumps(output, indent=2))
print(json.dumps(output, indent=2))
