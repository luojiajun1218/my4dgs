"""Summarize matched frames without mixing short and30-frame averages."""
import csv
import hashlib
import json
from pathlib import Path
import statistics
import sys

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
run=Path(sys.argv[1]).resolve()
baseline=ROOT/'output/fs_proximal_gs_validation_20261017/late270_299_prox_v1/20261017T132700_043227'
status=json.loads((run/'trial_status.json').read_text())
verified=json.loads((run/'independent_verification.json').read_text())
assert status['complete'] and verified['complete']
old=[]
for after in status['results']:
    frame=after['frame']
    summary=json.loads((baseline/'frame_summary'/f'frame_{frame:03d}.json').read_text())
    manifest=baseline/'frame_storage/rigid_tree'/f'frame_{frame:03d}.json'
    diag=summary['motion_rate_diagnostics']
    old.append(dict(frame=frame,psnr=summary['evaluation']['test']['psnr'],
        ssim=summary['evaluation']['test']['ssim'],
        full_bytes=summary['encoded_bytes']+manifest.stat().st_size,
        motion_bytes=summary['motion']['bytes'],
        opacity_bytes=summary['opacity_update']['archive_bytes'],birth_bytes=summary['birth']['archive_bytes'],
        gs_rows=diag['gs_active_rows'],gs_t=diag['gs_translation_active_blocks'],
        gs_r=diag['gs_rotation_active_blocks'],regions=summary['region_count'],
        elapsed_seconds=summary['elapsed_seconds']))
keys=('psnr','ssim','full_bytes','motion_bytes','opacity_bytes','birth_bytes',
      'gs_rows','gs_t','gs_r','elapsed_seconds')
average=lambda rows:{k:statistics.mean(r[k] for r in rows) for k in keys}
a,b=average(old),average(status['results'])
result=dict(complete=True,scope='Matched270-272 from same old269; no full300. Baseline87.874KB/33.466945dB is its270-299 average.',
    baseline=str(baseline),trial=str(run),before=old,after=status['results'],mean_before=a,mean_after=b,
    psnr_difference=b['psnr']-a['psnr'],byte_fraction_change=b['full_bytes']/a['full_bytes']-1,
    gs_row_fraction_change=b['gs_rows']/a['gs_rows']-1,time_fraction_change=b['elapsed_seconds']/a['elapsed_seconds']-1,
    adopt_as_default=False)
for name in ('comparison.json','per_frame_comparison.csv','validation_summary.json','decomposition_audit.json'):
    previous=OUT/name
    if previous.exists():
        archive=previous.with_name(previous.stem+'_v1'+previous.suffix)
        if not archive.exists():
            previous.rename(archive)
(OUT/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
with (OUT/'per_frame_comparison.csv').open('w',newline='') as fh:
    writer=csv.DictWriter(fh,fieldnames=['frame']+[p+k for p in ('baseline_','relative_') for k in keys])
    writer.writeheader()
    for before,after in zip(old,status['results']):
        writer.writerow(dict(frame=before['frame'],**{'baseline_'+k:before[k] for k in keys},
                             **{'relative_'+k:after[k] for k in keys}))
assert all(hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==digest for path,digest in status['source_hashes'].items())
summary=dict(complete=True,unit_tests=201,independent_decode_verified=True,
    checkpoint_raw_exact_frames=[r['frame'] for r in verified['frames'] if r.get('raw_checkpoint_exact')],
    max_psnr_difference=max(abs(r['quality_saved_difference']['psnr']) for r in verified['frames']),
    max_cache_pixel_difference=max(r['cache_pixel_max_abs_difference'] for r in verified['frames']),
    pure_fps_mean=statistics.mean(r['pure_fps'] for r in verified['frames']),
    no_full300_run=True,source_hashes_match=True,final_trial=str(run),
    supersedes='v1 double-counted two hidden dictionary nodes through identity parent -1; rerun after correction')
(OUT/'validation_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(before=a,after=b,psnr_difference=result['psnr_difference'],
    byte_change_percent=100*result['byte_fraction_change'],validation=summary),indent=2))
