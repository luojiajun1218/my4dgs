"""Independent decode, checkpoint identity, and held-out image verification."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
sys.path.insert(0,str(ROOT))
import torch
from scripts.benchmark_rigid_residual_tree import (
    _load_config,_make_module,_load_reference,_decode_frame,_install_raw,_cam00,
    _sequence_quality,_time_sequence_render,_validate_stream_manifest,
    _actual_frame_storage,_capture_raw,check_gpu_exclusivity)

parser=argparse.ArgumentParser()
parser.add_argument('run',type=Path)
args=parser.parse_args()
run=args.run.resolve()
status=json.loads((run/'trial_status.json').read_text())
assert status['complete']
torch.set_num_threads(2)
gpu=check_gpu_exclusivity()
cfg=_load_config(run)
module,data=_make_module(cfg,torch.device('cuda'))
stream=run/'frame_storage/rigid_tree'
first,last=status['start'],status['end']
ref=stream/f'reference_frame{first-1:03d}.npz'
state,raw=_load_reference(ref,None)
saved,_=_capture_raw(Path(status['source_checkpoint']),first-1,200)
assert all(torch.equal(raw[k],saved[k]) for k in raw)
relative_reference=json.loads((stream/f'frame_{first:03d}.json').read_text())['reference']
rows=[]
for frame in range(first,last+1):
    started=time.perf_counter()
    state,raw=_decode_frame(stream,frame,state,raw)
    manifest=_validate_stream_manifest(stream,frame,state,raw,relative_reference)
    decode_seconds=time.perf_counter()-started
    _install_raw(module,raw,torch.device('cuda'))
    view,n=_cam00(data,frame,torch.device('cuda'))
    assert n==1
    summary=json.loads((run/'frame_summary'/f'frame_{frame:03d}.json').read_text())
    quality,difference,cache_difference=_sequence_quality(module,view,
        summary['evaluation']['test'],dict(psnr=1e-4,ssim=1e-6,l1=1e-6),True)
    storage=_actual_frame_storage(stream,frame,manifest,summary,ref.stat().st_size,relative_reference)
    render_seconds=_time_sequence_render(module,view,10,50)
    row=dict(frame=frame,quality=quality,quality_saved_difference=difference,
        cache_pixel_max_abs_difference=cache_difference,render_seconds=render_seconds,
        pure_fps=50/render_seconds,decode_seconds=decode_seconds,**storage)
    ckpt=run/f'rigid-ckpt-{frame}-200.pth'
    if ckpt.exists():
        saved,_=_capture_raw(ckpt,frame,200)
        assert all(torch.equal(raw[k],saved[k]) for k in raw)
        row['raw_checkpoint_exact']=True
    rows.append(row)
    del view
assert hashlib.sha256(Path(status['source_checkpoint']).read_bytes()).hexdigest()==status['source_sha256']
assert all(hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==digest
    for path,digest in status['source_hashes'].items())
result=dict(complete=True,run=str(run),reference_matches_source=True,
    source_unchanged=True,source_code_unchanged=True,frames=rows,gpu_check=gpu,
    timing_scope='50 materialized renders after10 warmups, excludes decoding and upload')
(run/'independent_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(complete=True,frames=len(rows),mean_fps=sum(r['pure_fps'] for r in rows)/len(rows),
    max_psnr_difference=max(abs(r['quality_saved_difference']['psnr']) for r in rows),
    cache_max_pixel_difference=max(r['cache_pixel_max_abs_difference'] for r in rows)),indent=2))
