"""Read-only decomposition audit of the completed relative trial."""
import copy
import json
from pathlib import Path
import sys

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
sys.path.insert(0,str(ROOT))
import torch
from pipeline.model.spatial_gated_motion import SpatialGatedMotion
from pipeline.model.rigid_tree_codec import encode_motion,decode_motion
from scripts.benchmark_rigid_residual_tree import _load_config

torch.set_num_threads(2)
run=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else OUT/'relative_smoke270_272/20261017T172625_72797e'
baseline=ROOT/'output/fs_proximal_gs_validation_20261017/late270_299_prox_v1/20261017T132700_043227'

def packet(m):
    rt,rr,gt,gr=m._values(hard=True)
    return encode_motion(m.frame_reference_state,m.frame_index,m.extent,m.previous_rows,
        m.owner,m.parents,rt,rr,gt,gr,torch.empty(0,dtype=torch.long),torch.empty(0,3),
        torch.empty(0,4),m.config.motion_xyz_step_extent,m.config.motion_rotation_step_rad,
        compression='auto',gs_translation_step_extent=m.config.gs_xyz_step_extent,
        gs_rotation_step_rad=m.config.gs_rotation_step_rad,spatial_open=m.opened,
        spatial_relative=m.relative_regions)

def stats(m):
    rt,rr,t,r=m._values(hard=True)
    bins=m.gs_rotation.detach()/m.gs_steps[3:]
    single=r.abs().to(torch.int32).sum(-1).eq(1)
    amplitudes=bins[single][r[single].ne(0)].abs()
    raw=packet(m)
    decoded=decode_motion(raw,m.frame_reference_state)
    torch.testing.assert_close(decoded.xyz,m(100)[0],atol=1e-6,rtol=0)
    return dict(motion_bytes=len(raw),stored_regions=int(m._stored_region_support().sum()),
        gs_rows=int((t.ne(0).any(-1)|r.ne(0).any(-1)).sum()),gs_t=int(t.ne(0).any(-1).sum()),
        gs_r=int(r.ne(0).any(-1).sum()),region_t=int(rt.ne(0).any(-1).sum()),
        region_r=int(rr.ne(0).any(-1).sum()),single_bin_rotations=int(single.sum()),
        single_bin_rotations_near_half=int(((amplitudes>=.5)&(amplitudes<=.51)).sum()))

rows=[]
for f in (270,272):
    m=SpatialGatedMotion(_load_config(run).module.rigid_tree)
    state=torch.load(run/f'rigid-ckpt-{f}-100.pth',map_location='cpu',weights_only=False)['rigid_tree_motion']
    m.restore(state)
    with torch.no_grad():
        full=tuple(x.clone() for x in m._full_motion_symbols())
        entry=dict(frame=f,relative=stats(m),gate_trace=m.flat_region_diagnostics.get('learning_trace'))
        absolute=m._regional_predictions(hard=True)
        assert all(bool(x.abs().le(32767).all()) for x in absolute)
        m.region_translation.copy_(absolute[0]*m.steps[:3])
        m.region_rotation.copy_(absolute[1]*m.steps[3:])
        m.config.spatial_gate.region_motion='absolute'
        assert all(torch.equal(a,b) for a,b in zip(full,m._full_motion_symbols()))
        entry['same_motion_absolute_storage']=stats(m)
        m._refresh_active_representatives()
        assert all(torch.equal(a,b) for a,b in zip(full,m._full_motion_symbols()))
        entry['same_motion_absolute_refit']=stats(m)
        baseline_checkpoint=baseline/f'rigid-ckpt-{f}-100.pth'
        if baseline_checkpoint.exists():
            b=SpatialGatedMotion(_load_config(baseline).module.rigid_tree)
            b.restore(torch.load(baseline_checkpoint,map_location='cpu',weights_only=False)['rigid_tree_motion'])
            entry['trained_absolute_baseline']=stats(b)
        rows.append(entry)
result=dict(scope='Old-point motion only, no births/opacity. Converting representation and refitting preserve the full integer motion; does not isolate individual training changes.',rows=rows)
(run/'decomposition_audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps([{k:v for k,v in row.items() if k!='gate_trace'} for row in rows],indent=2))
