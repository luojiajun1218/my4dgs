"""Bounded relative-region trial from exactly the proximal baseline's old269.

No historical output is mutated. Same .003 rate units, image views, quantizer,
GS proximal steps, opacity and birth settings as the 87.874 KB baseline.
"""
import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import shutil
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT))
import torch
from omegaconf import OmegaConf
from pipeline.entry import Pipeline
from pipeline.model.sparse_updates import OpacityUpdateConfig, QuantizedOpacityUpdate
from scripts.benchmark_rigid_residual_tree import _load_config, check_gpu_exclusivity

parser = argparse.ArgumentParser()
parser.add_argument('--frames', type=int, default=3)
parser.add_argument('--resume', type=Path)
args = parser.parse_args()
assert 1 <= args.frames <= 30
check_gpu_exclusivity()
old = ROOT/'output/fs_ste_depth4_rate003_full300_20261017/20261017T022827_f74b2a'
source = old/'rigid-ckpt-269-200.pth' if args.resume is None else args.resume.resolve()
cfg = _load_config(source.parent)
cfg.output_dir = OUT
cfg.experiment_name = 'relative_smoke270_272_v2' if args.resume is None else 'relative_continuation'
cfg.ckpt_path = source
pipeline = Pipeline(cfg)
trainer, module = pipeline.trainer, pipeline.module
trainer.setup(module, source)
assert module.frame_finalized
start = module.current_frame + 1
end = min(start+args.frames, 300)
old_config = asdict(module.config)
if args.resume is None:
    assert module.current_frame == 269
    cfg.module.rigid_tree.proximal_gs_regularization = True
    cfg.module.rigid_tree.differentiable_rate_support = True
    cfg.module.rigid_tree.spatial_gate.joint_image_gradients = False
    cfg.module.rigid_tree.rate_model = 'raw_blocks'
    cfg.module.birth.replace_low_opacity = False
    cfg.module.opacity_update = OpacityUpdateConfig(enabled=True, step=.05,
        learning_rate=.05, prune_threshold=.01)
    module.opacity_update = QuantizedOpacityUpdate(cfg.module.opacity_update)
    module.motion.enable_relative_regions()
cfg.module.rigid_tree.validate()
trainer._restore_rng(trainer._resume_rng)
trainer._resume_rng = None
module.begin_next_frame()
trainer.global_step = 0
cfg.trainer.saving_ckpt_frames = sorted(set([start, end-1] +
    [f for f in (272,279,299) if start <= f < end]))
cfg.trainer.saving_ckpt_steps = [70,100,200]
pipeline.save_config()
snapshot = pipeline.output_dir/'source_snapshot'
hashes = {}
for folder in ('pipeline', 'tests', 'scripts'):
    for path in (ROOT/folder).rglob('*.py'):
        if path.is_symlink():
            continue
        rel = path.relative_to(ROOT)
        target = snapshot/rel
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(path,target)
        hashes[str(rel)] = hashlib.sha256(path.read_bytes()).hexdigest()
(snapshot/'manifest.json').write_text(json.dumps(hashes,indent=2)+'\n')
status = dict(complete=False, output=str(pipeline.output_dir), start=start, end=end-1,
    source_checkpoint=str(source), source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    old_module_config=old_config, effective_module_config=asdict(module.config),
    source_hashes=hashes, results=[])
status_path = pipeline.output_dir/'trial_status.json'
def save():
    temporary = status_path.with_suffix('.tmp')
    temporary.write_text(json.dumps(status,indent=2,default=str)+'\n')
    temporary.replace(status_path)
save()
started = time.perf_counter()
try:
    for frame in range(start,end):
        trainer.datamodule.current_frame = frame
        report = trainer.frame_training_loop()
        manifest = pipeline.output_dir/'frame_storage/rigid_tree'/f'frame_{frame:03d}.json'
        summary = report['flat_region_diagnostics']
        gates = {g['node']:g['opened'] for g in summary['gates']}
        effective = 0
        for node, opened in gates.items():
            if not opened:
                continue
            p=(node-1)//8
            while p and gates.get(p,False):
                p=(p-1)//8
            effective += p==0
        status['results'].append(dict(frame=frame,
            psnr=report['evaluation']['test']['psnr'],
            ssim=report['evaluation']['test']['ssim'],
            full_bytes=report['encoded_bytes']+manifest.stat().st_size,
            motion_bytes=report['motion']['bytes'],
            opacity_bytes=(report.get('opacity_update') or {}).get('archive_bytes',0),
            birth_bytes=(report.get('birth') or {}).get('archive_bytes',0),
            regions=report['region_count'], stored_regions=summary['stored_region_nodes'],
            opened=summary['open_gates'],effective_splits=effective,
            depths=summary['active_regions_by_depth'],
            gs_rows=report['motion_rate_diagnostics']['gs_active_rows'],
            gs_t=report['motion_rate_diagnostics']['gs_translation_active_blocks'],
            gs_r=report['motion_rate_diagnostics']['gs_rotation_active_blocks'],
            elapsed_seconds=report['elapsed_seconds']))
        save()
        if frame+1 < end:
            module.begin_next_frame()
            trainer.global_step=0
    status.update(complete=True,seconds=time.perf_counter()-started,
        source_unchanged=hashlib.sha256(source.read_bytes()).hexdigest()==status['source_sha256'])
except BaseException as error:
    status['error']=repr(error)
    raise
finally:
    save()
    if trainer.tb_writer is not None:
        trainer.tb_writer.close()
print(json.dumps({key:status[key] for key in ('complete','output','start','end','seconds','results')},indent=2))
