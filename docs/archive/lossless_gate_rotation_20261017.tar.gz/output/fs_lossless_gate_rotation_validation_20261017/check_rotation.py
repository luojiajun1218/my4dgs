"""Quantizer checks and frozen multi-view rotation sensitivity, no optimization."""
import json
import math
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import torch
from libgs.metric import psnr
from pipeline.model.spatial_gated_motion import SpatialGatedMotion
from pipeline.model.rigid_residual_tree import _quantized, _integer, quaternion_angle_error, rotation_vector_quaternion
from scripts.benchmark_rigid_residual_tree import (_load_config, _make_module,
    _install_raw, _cam00, CAPTURE_INDEX, check_gpu_exclusivity)

torch.set_num_threads(2)
OUT = Path(__file__).resolve().parent
RUN = Path(json.loads((ROOT/'output/fs_sparse_tralpha_validation_20261017/comparison.json').read_text())['cases']['sparse_tralpha']['run'])
check_gpu_exclusivity()
device = torch.device('cuda')
config = _load_config(RUN)
module, data = _make_module(config, device)
step = torch.tensor(.001)
inputs = torch.tensor([-.00051, -.00049, 0., .00049, .00051], requires_grad=True)
quantized = _quantized(inputs, step)
quantized.sum().backward()
assert torch.equal(_integer(inputs,step), torch.tensor([-1,0,0,0,1],dtype=torch.int16))
assert torch.equal(inputs.grad, torch.ones_like(inputs))
single = rotation_vector_quaternion(torch.tensor([[.001, 0., 0.]]))
identity = torch.tensor([[1.,0.,0.,0.]])
angle = float(quaternion_angle_error(single, identity))
assert abs(angle-.001)<1e-9
result = dict(scope='Frozen final-frame attributes; remove GS rotation residuals without any retraining. Do not interpret as a deployable quantizer or a full-sequence result.',
    quantizer=dict(inputs=inputs.detach().tolist(), outputs=quantized.detach().tolist(),
        roundtrip_symbols=_integer(inputs,step).tolist(), ste_gradient=inputs.grad.tolist(),
        single_bin_angle_rad=angle,single_bin_angle_degrees=angle*180/math.pi), frames=[])


@torch.no_grad()
def evaluate(views):
    records = []
    for view in views:
        image = module.forward(view)['render'].clamp(0,1)
        records.append(dict(camera=view.path.name, psnr=float(psnr(image, view.image)),
            mse=float((image-view.image).square().mean())))
    return dict(psnr_mean=statistics.mean(r['psnr'] for r in records), rows=records)


for frame in [270,279,299]:
    checkpoint = torch.load(RUN/f'rigid-ckpt-{frame}-200.pth',map_location='cpu',weights_only=False)
    raw = {name:checkpoint['gaussians'][index].detach().clone() for name,index in CAPTURE_INDEX.items()}
    motion = SpatialGatedMotion(config.module.rigid_tree)
    motion.restore(checkpoint['rigid_tree_motion'])
    values = motion.gs_rotation.detach()
    bins = values/motion.gs_steps[3:]
    symbols = bins.round()
    norms = symbols.abs().sum(-1)
    small = norms.eq(1)
    active = norms.gt(0)
    selected = bins[small][symbols[small].ne(0)].abs()
    distance = selected-.5
    phases = dict(active_rows=int(active.sum()), single_bin_rows=int(small.sum()),
        single_bin_percent=100*float(small.sum())/max(1,int(active.sum())),
        single_bin_continuous_abs_quantiles={str(p):float(torch.quantile(selected,p)) for p in [0.,.25,.5,.75,1.]},
        single_bin_within_001_of_zero_boundary=int(distance.le(.01).sum()),
        single_bin_within_005_of_zero_boundary=int(distance.le(.05).sum()))
    data.current_frame=frame
    dataset=data.get_train_dataset()
    indices=sorted(range(len(dataset.items)), key=lambda i:dataset.items[i].path.name)
    views=[dataset[i].to(device) for i in indices]
    test,_=_cam00(data,frame,device)
    cases=[]
    original=motion.gs_rotation.detach().clone()
    for mode in ['original','recomposed_control','zero_single_bin_residual','zero_all_rotation_residual']:
        with torch.no_grad():
            motion.gs_rotation.copy_(original)
            if mode == 'zero_single_bin_residual':
                motion.gs_rotation[small]=0
            elif mode == 'zero_all_rotation_residual':
                motion.gs_rotation.zero_()
            current={**raw}
            if mode != 'original':
                current['rotation']=raw['rotation'].clone()
                current['rotation'][:len(values)]=motion.materialized_pose()[1]
        _install_raw(module,current,device)
        row=dict(mode=mode,training=evaluate(views),heldout=evaluate([test]))
        cases.append(row)
        print(json.dumps(dict(frame=frame,mode=mode,train=row['training']['psnr_mean'],
            test=row['heldout']['psnr_mean'])),flush=True)
    expected=json.loads((RUN/f'frame_summary/frame_{frame:03d}.json').read_text())['evaluation']['test']['psnr']
    assert abs(cases[0]['heldout']['psnr_mean']-expected)<1e-4
    result['frames'].append(dict(frame=frame,quantization_phases=phases,cases=cases))
    (OUT/'rotation.json').write_text(json.dumps(result,indent=2)+'\n')
    del checkpoint,raw,motion,views,test,current
check_gpu_exclusivity()
