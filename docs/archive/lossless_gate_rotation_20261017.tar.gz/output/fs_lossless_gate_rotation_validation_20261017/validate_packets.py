"""Use production encoders, then independently replay the unchanged 30 states."""
import csv
import hashlib
import json
from pathlib import Path
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import torch
from pipeline.model import rigid_tree_codec as M
from pipeline.model.legacy_opacity_codec import decode_opacity_delta
from pipeline.model.sparse_updates import encode_opacity_delta
from scripts.replay_rigid_tree import replay, decode_frame, fields

torch.set_num_threads(2)
OUT = Path(__file__).resolve().parent
comparison = json.loads((ROOT / 'output/fs_sparse_tralpha_validation_20261017/comparison.json').read_text())
RUN = Path(comparison['cases']['sparse_tralpha']['run'])
SOURCE = RUN / 'frame_storage/rigid_tree'
STREAM = OUT / 'reencoded270_299/frame_storage/rigid_tree'
STREAM.mkdir(parents=True, exist_ok=False)
reference = SOURCE / 'reference_frame269.npz'
(STREAM / reference.name).symlink_to(reference)
state, raw = replay(SOURCE, reference, 269)
records = []
source_hashes = {}
started = time.perf_counter()
for frame in range(270, 300):
    manifest_path = SOURCE / f'frame_{frame:03d}.json'
    manifest_bytes = manifest_path.read_bytes()
    manifest = json.loads(manifest_bytes)
    original_motion = (SOURCE / manifest['motion']).read_bytes()
    motion_raw = M.uncompressed_motion_packet(original_motion)
    reader = M._Reader(motion_raw)
    reader.take(36)
    index, regions, count, births = [reader.integer() for _ in range(4)]
    reader.take(40)
    keep = torch.ones(len(state.xyz), dtype=torch.bool)
    if reader.take(1)[0]:
        deleted, previous = reader.integer(), -1
        for _ in range(deleted):
            previous += reader.integer() + 1
            keep[previous] = False
    rows = keep.nonzero(as_tuple=True)[0]
    assert index == frame and count == len(rows)
    assert reader.integer() == 0
    reader.take((regions + 7) // 8)
    rt, rr = M._sparse_read(reader, regions - 1, delta_rows=True)
    rt = torch.cat((torch.zeros(1, 3, dtype=torch.int16), rt))
    rr = torch.cat((torch.zeros(1, 3, dtype=torch.int16), rr))
    gt, gr = M._sparse_read(reader, count, delta_rows=True)
    encode_start = time.perf_counter()
    packet = M.compress_motion_packet(motion_raw, mode='auto')
    assert len(packet) <= len(original_motion)
    assert M.uncompressed_motion_packet(packet) == motion_raw
    (STREAM / manifest['motion']).write_bytes(packet)
    encode_motion_seconds = time.perf_counter() - encode_start

    reference_alpha = raw['opacity'][rows]
    original_alpha = (SOURCE / manifest['opacity_update']).read_bytes()
    prior_update = decode_opacity_delta(original_alpha, reference_alpha, frame_index=frame)
    symbols = torch.zeros_like(reference_alpha)
    symbols[prior_update.rows, 0] = prior_update.symbols.float()
    encode_start = time.perf_counter()
    alpha = encode_opacity_delta(reference_alpha, symbols, frame_index=frame, step=prior_update.step)
    assert len(alpha) <= len(original_alpha)
    (STREAM / manifest['opacity_update']).write_bytes(alpha)
    encode_alpha_seconds = time.perf_counter() - encode_start
    if manifest['birth']:
        (STREAM / manifest['birth']).symlink_to(SOURCE / manifest['birth'])
    (STREAM / manifest_path.name).write_bytes(manifest_bytes)

    decode_start = time.perf_counter()
    state, raw = decode_frame(STREAM, frame, state, raw)
    decode_seconds = time.perf_counter() - decode_start
    assert torch.equal(rows, state.survivor_rows)
    assert state.digest().hex() == manifest['decoded_state_sha256']
    digest = hashlib.sha256()
    for name in fields:
        value = raw[name].contiguous()
        digest.update(name.encode())
        digest.update(str(tuple(value.shape)).encode())
        digest.update(value.numpy().tobytes())
    assert digest.hexdigest() == manifest['raw_state_sha256']

    full_t = rt[state.owner[:count]].int() + gt.int()
    full_r = rr[state.owner[:count]].int() + gr.int()
    moving = full_t.ne(0).any(-1) | full_r.ne(0).any(-1)
    residual = gt.ne(0).any(-1) | gr.ne(0).any(-1)
    summary = json.loads((RUN / f'frame_summary/frame_{frame:03d}.json').read_text())
    d = summary['flat_region_diagnostics']
    trace = d['learning_trace']
    birth_bytes = (SOURCE / manifest['birth']).stat().st_size if manifest['birth'] else 0
    record = dict(frame=frame, old_count=count, old_motion_bytes=len(original_motion),
        old_opacity_bytes=len(original_alpha), motion_bytes=len(packet), opacity_bytes=len(alpha),
        birth_bytes=birth_bytes, manifest_bytes=len(manifest_bytes),
        complete_bytes=len(packet) + len(alpha) + birth_bytes + len(manifest_bytes),
        old_complete_bytes=len(original_motion) + len(original_alpha) + birth_bytes + len(manifest_bytes),
        moving_points=int(moving.sum()), residual_points=int(residual.sum()),
        moving_without_residual=int((moving & ~residual).sum()),
        full_translation_blocks=int(full_t.ne(0).any(-1).sum()),
        full_rotation_blocks=int(full_r.ne(0).any(-1).sum()),
        residual_translation_blocks=int(gt.ne(0).any(-1).sum()),
        residual_rotation_blocks=int(gr.ne(0).any(-1).sum()),
        open_gates=d['open_gates'], eligible_gates=d['eligible_gates'],
        active_regions=d['active_regions'], start_regions=trace[0]['active_regions'],
        psnr=summary['evaluation']['test']['psnr'],
        encode_motion_seconds=encode_motion_seconds, encode_alpha_seconds=encode_alpha_seconds,
        sequential_decode_seconds=decode_seconds,
        motion_format=packet[:4].decode('ascii'), opacity_format=alpha[:4].decode('ascii'))
    records.append(record)
    for name in [manifest_path.name, manifest['motion'], manifest['birth'], manifest['opacity_update']]:
        if name:
            source_hashes[name] = hashlib.sha256((SOURCE / name).read_bytes()).hexdigest()
    if frame in [270, 279, 289, 299]:
        print(json.dumps(record), flush=True)

means = {name: statistics.mean(row[name] for row in records)
         for name in records[0] if name not in ('frame', 'motion_format', 'opacity_format')}
total_moving = sum(row['moving_points'] for row in records)
result = dict(scope='Existing 270-299 packet states, re-exported through production lossless encoders; no training.',
    source_run=str(RUN), output_stream=str(STREAM), frames=len(records),
    all_original_raw_and_state_hashes_match=True, all_motion_packets_restore_exact_bytes=True,
    means=means, savings_percent=100 * (1 - means['complete_bytes'] / means['old_complete_bytes']),
    shared_motion_explains_moving_point_percent=100 * sum(row['moving_without_residual'] for row in records) / total_moving,
    gates=dict(open_min=min(r['open_gates'] for r in records), open_max=max(r['open_gates'] for r in records),
        eligible_min=min(r['eligible_gates'] for r in records), eligible_max=max(r['eligible_gates'] for r in records),
        active_regions_min=min(r['active_regions'] for r in records), active_regions_max=max(r['active_regions'] for r in records),
        frames_start_end_regions_differ=sum(r['start_regions'] != r['active_regions'] for r in records)),
    timing_scope='CPU production encoding and sequential decode+materialization, two torch threads; no renderer.',
    source_sha256=source_hashes, script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    elapsed_seconds=time.perf_counter() - started)
(OUT / 'packets.json').write_text(json.dumps(result, indent=2) + '\n')
with (OUT / 'packets_per_frame.csv').open('x', newline='') as file:
    writer = csv.DictWriter(file, fieldnames=list(records[0]))
    writer.writeheader()
    writer.writerows(records)
print(json.dumps({key:value for key,value in result.items() if key != 'source_sha256'}, indent=2), flush=True)
