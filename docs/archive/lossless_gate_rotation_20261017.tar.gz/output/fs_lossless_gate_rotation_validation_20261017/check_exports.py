"""Check actual model exporters on the saved finalized frame299 checkpoint."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import torch
from pipeline.model.spatial_gated_motion import SpatialGatedMotion
from pipeline.model.sparse_updates import OpacityUpdateConfig, QuantizedOpacityUpdate
from scripts.benchmark_rigid_residual_tree import _load_config

torch.set_num_threads(2)
OUT = Path(__file__).resolve().parent
RUN = Path(json.loads((OUT/'packets.json').read_text())['source_run'])
checkpoint = torch.load(RUN/'rigid-ckpt-299-200.pth',map_location='cpu',weights_only=False)
config = _load_config(RUN)
motion = SpatialGatedMotion(config.module.rigid_tree)
motion.restore(checkpoint['rigid_tree_motion'])
info = motion.export_motion(OUT/'model_export_motion_299.bin')
opacity_packet = checkpoint['quantized_opacity_update']
opacity = QuantizedOpacityUpdate(OpacityUpdateConfig(**opacity_packet['config']))
opacity.restore(opacity_packet, torch.device('cpu'))
alpha_info = opacity.export(OUT/'model_export_opacity_299.bin',299)
stream = OUT/'reencoded270_299/frame_storage/rigid_tree'
assert (OUT/'model_export_motion_299.bin').read_bytes() == (stream/'motion_299.bin').read_bytes()
assert (OUT/'model_export_opacity_299.bin').read_bytes() == (stream/'opacity_299.bin').read_bytes()
result = dict(finalized_checkpoint_export_matches_reencoded_stream=True,
              motion=info, opacity=alpha_info, no_training=True)
(OUT/'model_exports.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
