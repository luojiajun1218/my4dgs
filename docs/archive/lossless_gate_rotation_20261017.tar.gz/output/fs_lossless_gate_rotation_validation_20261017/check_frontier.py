"""Single fitted-frame dictionary diagnostic; no training or gate policy change."""
import copy
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import torch
from pipeline.model.spatial_gated_motion import SpatialGatedMotion
from pipeline.model.spatial_gate import spatial_owner
from scripts.benchmark_rigid_residual_tree import _load_config

torch.set_num_threads(2)
OUT = Path(__file__).resolve().parent
RUN = Path(json.loads((ROOT/'output/fs_sparse_tralpha_validation_20261017/comparison.json').read_text())['cases']['sparse_tralpha']['run'])
checkpoint_path = RUN/'rigid-ckpt-299-100.pth'
checkpoint = torch.load(checkpoint_path, map_location='cpu', weights_only=False)
config = _load_config(RUN)
rows = []
original = pose = None
started = time.perf_counter()
for cut in ['learned', 'learned_refit', 'coarse8_refit', 'finest_refit']:
    motion = SpatialGatedMotion(config.module.rigid_tree)
    motion.restore(copy.deepcopy(checkpoint['rigid_tree_motion']))
    with torch.no_grad():
        full = motion._full_motion_symbols()
        if original is None:
            original = tuple(value.clone() for value in full)
            pose = tuple(value.clone() for value in motion.materialized_pose())
        if cut != 'learned':
            if cut != 'learned_refit':
                opened = (torch.zeros_like(motion.opened) if cut.startswith('coarse')
                          else motion.split_eligible.clone())
                opened[0] = True
                motion.opened = opened
                motion._recode_owner(spatial_owner(motion.spatial_paths, opened), full_motion=full)
            motion._hard_gate_frozen = True
            motion._refresh_active_representatives()
        assert all(torch.equal(a, b) for a, b in zip(original, motion._full_motion_symbols()))
        current_pose = motion.materialized_pose()
        delta = [float((a-b).abs().max()) for a,b in zip(pose,current_pose)]
        motion.register_materialized_layout(*current_pose,
            birth_source_rows=torch.empty(0, dtype=torch.long))
        info = motion.export_motion(OUT/f'frontier_{cut}_299.bin')
        terms = motion.loss_terms(100, diagnostics=True)
        record = dict(cut=cut, bytes=info['bytes'], raw_bytes=info['raw_stream_bytes'],
            active_regions=int(motion.owner.unique().numel()),
            gs_active_rows=int(terms['gs_active_rows']),
            gs_translation_blocks=int(terms['gs_translation_active_blocks']),
            gs_rotation_blocks=int(terms['gs_rotation_active_blocks']),
            rate_surrogate=float(terms['rate_bytes_surrogate']),
            integer_full_motion_preserved=True, max_abs_pose_difference=delta)
        rows.append(record)
        print(json.dumps(record), flush=True)
result = dict(scope='Frame299 old points at step100; preserve fitted full integer motion, no births or alpha counted. Endpoint cuts are diagnostic only.',
    source=str(checkpoint_path), checkpoint_sha256=hashlib.sha256(checkpoint_path.read_bytes()).hexdigest(),
    cuts=rows, elapsed_seconds=time.perf_counter()-started)
(OUT/'frontier.json').write_text(json.dumps(result,indent=2)+'\n')
