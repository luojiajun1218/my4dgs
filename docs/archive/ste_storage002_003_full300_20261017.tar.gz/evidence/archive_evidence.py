"""Archive source and lightweight evidence without datasets or model artifacts."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

batch = Path(__file__).resolve().parent
repo = batch.parent.parent
archive = repo / 'docs/archive/ste_storage002_003_full300_20261017.tar.gz'
state = json.loads((batch / 'status.json').read_text())
assert state['status'] == 'complete'
source_manifest = json.loads((batch / 'source/source_manifest.json').read_text())
members = {'source/source_manifest.json': batch / 'source/source_manifest.json'}
members.update({f'source/{name}': batch / 'source' / name
                for name in source_manifest['hashes']})
evidence = ['status.json', 'provenance.json', 'pip_freeze.txt', 'gpu_initial.txt',
    'gpu_final.txt', 'gpu_telemetry.jsonl', 'comparison.json',
    'per_frame_comparison.csv', 'comparison_validation.log',
    'run_batch.py', 'analyze_completed.py', 'finish_reports.py', 'archive_evidence.py']
for suffix in ['002', '003']:
    evidence += [f'rate{suffix}_{name}' for name in ['benchmark.json', 'benchmark.log',
        'training.log', 'analysis.json', 'analysis.log', 'per_frame.csv']]
for name in evidence:
    members[f'evidence/{name}'] = batch / name
for job, suffix in zip(state['jobs'], ['002', '003']):
    run = Path(job['run'])
    members[f'runs/rate{suffix}/config.yaml'] = run / 'config.yaml'
    for manifest in sorted((run / 'frame_storage/rigid_tree').glob('frame_*.json')):
        members[f'runs/rate{suffix}/manifests/{manifest.name}'] = manifest
    for frame in [1, 30, 90, 150, 270, 299]:
        name = f'frame_{frame:03d}.json'
        members[f'runs/rate{suffix}/selected_summaries/{name}'] = run / 'frame_summary' / name
for name in ['docs/README.md', 'docs/experiment/20261017_ste_storage002_full300.md',
    'docs/experiment/20261017_ste_storage003_full300.md',
    'docs/experiment/20261017_ste_storage002_vs003_full300.md',
    'docs/experiment/figures/20261017_ste_storage002_vs003_full300.png']:
    members[name] = repo / name

checksums = {}
for name, path in members.items():
    assert path.is_file() and not path.is_symlink(), path
    assert path.suffix not in {'.pth', '.pt', '.npz', '.ply', '.bin'}, path
    checksums[name] = hashlib.sha256(path.read_bytes()).hexdigest()
index = json.dumps(dict(schema='ste_rate_pair_lightweight_evidence_v1',
    dataset_copied=False, model_checkpoints_copied=False, packet_payloads_copied=False,
    source_manifest_sha256=hashlib.sha256((batch / 'source/source_manifest.json').read_bytes()).hexdigest(),
    sha256=checksums), indent=2).encode()
with tarfile.open(archive, 'x:gz') as handle:
    for name, path in members.items():
        handle.add(path, arcname=name, recursive=False)
    info = tarfile.TarInfo('archive_manifest.json')
    info.size = len(index)
    handle.addfile(info, io.BytesIO(index))
with tarfile.open(archive, 'r:gz') as handle:
    saved = json.load(handle.extractfile('archive_manifest.json'))
    for name, expected in saved['sha256'].items():
        assert hashlib.sha256(handle.extractfile(name).read()).hexdigest() == expected, name
result = dict(archive=str(archive), bytes=archive.stat().st_size,
    sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), verified_members=len(checksums))
(batch / 'archive_verification.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result))
