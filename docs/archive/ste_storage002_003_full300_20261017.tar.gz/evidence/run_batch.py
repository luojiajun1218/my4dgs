"""Execute the two requested full300 jobs sequentially from one source snapshot."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time
import traceback

BATCH = Path(__file__).resolve().parent
SOURCE = BATCH / 'source'
REPO = BATCH.parent.parent
STATE_PATH = BATCH / 'status.json'
MANIFEST = json.loads((SOURCE / 'source_manifest.json').read_text())
STATE = {'schema': 'requested_two_full300_v1', 'controller_pid': os.getpid(),
         'started_utc': datetime.now(timezone.utc).isoformat(), 'status': 'running',
         'source': str(SOURCE), 'jobs': []}


def now():
    return datetime.now(timezone.utc).isoformat()


def save():
    STATE['updated_utc'] = now()
    temporary = STATE_PATH.with_suffix('.tmp')
    temporary.write_text(json.dumps(STATE, indent=2) + '\n')
    temporary.replace(STATE_PATH)


def verify_source():
    for relative, expected in MANIFEST['hashes'].items():
        actual = hashlib.sha256((SOURCE / relative).read_bytes()).hexdigest()
        if actual != expected:
            raise RuntimeError(f'Frozen source changed: {relative}')


def require_idle_gpu():
    result = subprocess.run(['nvidia-smi',
        '--query-compute-apps=pid,process_name,used_gpu_memory',
        '--format=csv,noheader,nounits'], text=True, capture_output=True,
        check=True, timeout=10)
    if result.stdout.strip():
        raise RuntimeError('GPU has another compute process: ' + result.stdout.strip())


def telemetry(stage):
    try:
        result = subprocess.run(['nvidia-smi',
            '--query-gpu=uuid,temperature.gpu,power.draw,power.limit,utilization.gpu,memory.used',
            '--format=csv,noheader,nounits'], text=True, capture_output=True, timeout=10)
        row = {'utc': now(), 'stage': stage, 'returncode': result.returncode,
               'csv': result.stdout.strip(), 'stderr': result.stderr.strip()}
    except Exception as error:
        row = {'utc': now(), 'stage': stage, 'error': repr(error)}
    with (BATCH / 'gpu_telemetry.jsonl').open('a') as handle:
        handle.write(json.dumps(row) + '\n')
    STATE['gpu_latest'] = row


def discover_run(job):
    parent = REPO / 'output' / job['experiment_name']
    directories = [path for path in parent.iterdir() if path.is_dir()] if parent.exists() else []
    if len(directories) > 1:
        raise RuntimeError(f'Ambiguous run directories: {directories}')
    if directories:
        job['run'] = str(directories[0])
        return directories[0]
    return None


def update_progress(job, cached):
    run = discover_run(job)
    if run is None:
        return
    for path in sorted((run / 'frame_summary').glob('frame_*.json')):
        frame = int(path.stem.rsplit('_', 1)[1])
        if frame in cached:
            continue
        try:
            report = json.loads(path.read_text())
            manifest_bytes = (run / report['frame_manifest']).stat().st_size
            cached[frame] = {'frame': frame, 'psnr': report['evaluation']['test']['psnr'],
                'ssim': report['evaluation']['test']['ssim'],
                'payload_bytes': report['encoded_bytes'],
                'complete_update_bytes': report['encoded_bytes'] + manifest_bytes,
                'elapsed_seconds': report['elapsed_seconds'],
                'region_count': report['region_count'], 'total_count': report['total_count'],
                'birth_count': report.get('birth_count', 0)}
        except (json.JSONDecodeError, FileNotFoundError):
            continue
    if cached:
        rows = [cached[key] for key in sorted(cached)]
        job['progress'] = {'completed_dynamic_frames': len(rows),
            'expected_dynamic_frames': 299, 'latest': rows[-1],
            'dynamic_psnr_mean': statistics.mean(row['psnr'] for row in rows),
            'complete_update_bytes_mean': statistics.mean(row['complete_update_bytes'] for row in rows),
            'reported_frame_seconds_mean': statistics.mean(row['elapsed_seconds'] for row in rows)}


def run_process(job, stage, command, log_path, cached):
    require_idle_gpu()
    verify_source()
    started = time.monotonic()
    env = dict(os.environ, PYTHONUNBUFFERED='1')
    with log_path.open('x') as log:
        child = subprocess.Popen(command, cwd=SOURCE, env=env, stdout=log,
                                 stderr=subprocess.STDOUT, start_new_session=True)
        job['stage'] = stage
        job['child_pid'] = child.pid
        job[f'{stage}_started_utc'] = now()
        job[f'{stage}_command'] = command
        job[f'{stage}_log'] = str(log_path)
        save()
        last_telemetry = 0.
        while True:
            code = child.poll()
            update_progress(job, cached)
            job[f'{stage}_wall_seconds'] = time.monotonic() - started
            if time.monotonic() - last_telemetry >= 30.:
                telemetry(stage)
                last_telemetry = time.monotonic()
            save()
            if code is not None:
                break
            time.sleep(5)
    job[f'{stage}_returncode'] = code
    job[f'{stage}_finished_utc'] = now()
    save()
    if code:
        tail = log_path.read_text(errors='replace')[-8000:]
        raise RuntimeError(f'{stage} exited {code}; log={log_path}\n{tail}')
    verify_source()


def main():
    for suffix, weight in [('002', .002), ('003', .003)]:
        experiment = f'fs_ste_depth4_rate{suffix}_full300_20261017'
        job = {'rate_loss_weight': weight, 'experiment_name': experiment,
               'status': 'running', 'expected_frames': 300}
        STATE['jobs'].append(job)
        cached = {}
        config = SOURCE / 'config' / f'{experiment}.yaml'
        run_process(job, 'training', [sys.executable, 'main.py', f'--config={config}'],
                    BATCH / f'rate{suffix}_training.log', cached)
        run = Path(job['run'])
        if sorted(cached) != list(range(1, 300)):
            raise RuntimeError('Training did not produce all 299 dynamic frames')
        if not (run / 'frame_storage/rigid_tree/reference_frame0.npz').is_file():
            raise RuntimeError('Missing frame0 reference')
        benchmark = BATCH / f'rate{suffix}_benchmark.json'
        run_process(job, 'benchmark', [sys.executable,
            'scripts/benchmark_rigid_residual_tree.py', '--run', str(run),
            '--sequence', '--mode=stream', '--sequence-warmups=10',
            '--sequence-renders=50', '--output', str(benchmark)],
            BATCH / f'rate{suffix}_benchmark.log', cached)
        result = json.loads(benchmark.read_text())
        if result['expected_frames'] != 300 or result['measured_frames'] != 300:
            raise RuntimeError('Benchmark did not verify all 300 frames')
        job['benchmark_result'] = str(benchmark)
        job['benchmark_summary'] = {key: result['groups'][key]
                                    for key in ['all_frames', 'dynamic_frames']}
        job['status'] = 'complete'
        job['stage'] = 'complete'
        job['completed_utc'] = now()
        save()
    STATE['status'] = 'complete'
    STATE['completed_utc'] = now()
    save()


if __name__ == '__main__':
    if STATE_PATH.exists():
        raise FileExistsError(STATE_PATH)
    save()
    try:
        main()
    except BaseException as error:
        STATE['status'] = 'failed'
        STATE['error'] = str(error)
        STATE['traceback'] = traceback.format_exc()
        if STATE['jobs'] and STATE['jobs'][-1]['status'] == 'running':
            STATE['jobs'][-1]['status'] = 'failed'
        save()
        raise
