"""Build per-frame CSV and diagnostics only from a completed full300 benchmark."""
import argparse
import csv
import json
from pathlib import Path
import statistics

BATCH = Path(__file__).resolve().parent


def mean(values):
    return statistics.mean(values)


def analyze(suffix):
    benchmark_path = BATCH / f'rate{suffix}_benchmark.json'
    benchmark = json.loads(benchmark_path.read_text())
    assert benchmark['expected_frames'] == benchmark['measured_frames'] == 300
    assert [r['frame'] for r in benchmark['frames']] == list(range(300))
    run = Path(benchmark['run'])
    summaries = {i: json.loads((run / f'frame_summary/frame_{i:03d}.json').read_text())
                 for i in range(1, 300)}
    assert all(r['train_loss_steps'] == 200 for r in summaries.values())
    rows = []
    for measured in benchmark['frames']:
        frame = measured['frame']
        row = {'frame': frame, **measured['quality']}
        row.update({k: measured.get(k, 0) for k in ('gaussian_count', 'motion_bytes',
            'birth_bytes', 'opacity_update_bytes', 'payload_bytes', 'manifest_index_bytes',
            'complete_update_bytes', 'render_fps', 'render_seconds',
            'file_decode_verify_seconds', 'upload_seconds')})
        row['bootstrap_reference_bytes'] = benchmark['storage']['bootstrap_reference_bytes'] if frame == 0 else 0
        if frame:
            saved = summaries[frame]
            row['lpips_training_summary'] = saved['evaluation']['test'].get('lpips')
            row['train_elapsed_seconds'] = saved['elapsed_seconds']
            row['active_regions'] = saved['region_count']
            row['nonzero_gs_residuals'] = saved['motion_activity']['old_gs_with_local_residual']
            row['new_gaussians'] = saved['birth_count']
            rate = saved['motion_rate_diagnostics']
            row['open_gates'] = rate['spatial_open_gates']
            row['gate_mean_probability'] = rate['spatial_gate_mean_probability']
            row['rate_bytes_surrogate'] = rate['rate_bytes_surrogate']
            row['rate_bytes_hard'] = rate['rate_bytes_hard']
            stages = {r['step']: r['psnr'] for r in saved['stage_image_metrics']}
            row['step100_psnr'] = stages[100]
            row['step200_psnr'] = stages[200]
            row['birth_stage_psnr_gain'] = stages[200] - stages[100]
        rows.append(row)
    fields = list(dict.fromkeys(k for row in rows for k in row))
    csv_path = BATCH / f'rate{suffix}_per_frame.csv'
    with csv_path.open('x', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    dynamic = rows[1:]
    differences = [r['quality_saved_difference'] for r in benchmark['frames'][1:]]
    state = json.loads((BATCH / 'status.json').read_text())
    job = next(j for j in state['jobs'] if j['experiment_name'] == run.parent.name)
    segments = []
    for start in range(1, 300, 30):
        part = rows[start:min(start + 30, 300)]
        segments.append({'first_frame': part[0]['frame'], 'last_frame': part[-1]['frame'],
            'frames': len(part), 'psnr_mean': mean(r['psnr'] for r in part),
            'complete_update_KB_mean': mean(r['complete_update_bytes'] for r in part)/1000,
            'train_seconds_mean': mean(r['train_elapsed_seconds'] for r in part),
            'regions_mean': mean(r['active_regions'] for r in part)})
    worst = sorted(dynamic, key=lambda r: r['psnr'])[:5]
    result = {'weight': job['rate_loss_weight'], 'run': str(run),
        'config': str(run / 'config.yaml'), 'benchmark': str(benchmark_path), 'csv': str(csv_path),
        'all_frames': benchmark['groups']['all_frames'],
        'dynamic_frames': benchmark['groups']['dynamic_frames'],
        'storage': benchmark['storage'], 'train_wall_seconds': job['training_wall_seconds'],
        'benchmark_wall_seconds': job.get('benchmark_wall_seconds'),
        'reported_dynamic_frame_seconds_mean': mean(r['train_elapsed_seconds'] for r in dynamic),
        'reported_dynamic_frame_seconds_median': statistics.median(r['train_elapsed_seconds'] for r in dynamic),
        'reported_dynamic_frame_seconds_max': max(r['train_elapsed_seconds'] for r in dynamic),
        'reported_seconds_mean_excluding_first_dynamic': mean(r['train_elapsed_seconds'] for r in dynamic[1:]),
        'lpips_dynamic_training_summary_mean': mean(r['lpips_training_summary'] for r in dynamic),
        'birth_stage_psnr_gain_mean': mean(r['birth_stage_psnr_gain'] for r in dynamic),
        'birth_stage_psnr_gain_median': statistics.median(r['birth_stage_psnr_gain'] for r in dynamic),
        'max_saved_quality_abs_difference': {k: max(abs(d[k]) for d in differences) for k in differences[0]},
        'max_cache_pixel_abs_difference': max(r['cache_pixel_max_abs_difference'] for r in benchmark['frames']),
        'decode_verify_seconds_total': benchmark['decode_verify_seconds_total'],
        'upload_seconds_total': benchmark['upload_seconds_total'],
        'measured_render_seconds_total': sum(r['render_seconds'] for r in benchmark['frames']),
        'region_count_first': dynamic[0]['active_regions'],
        'region_count_last': dynamic[-1]['active_regions'],
        'region_count_min': min(r['active_regions'] for r in dynamic),
        'region_count_max': max(r['active_regions'] for r in dynamic),
        'gaussian_count_first': rows[0]['gaussian_count'],
        'gaussian_count_last': rows[-1]['gaussian_count'],
        'worst_psnr_frames': [{'frame': r['frame'], 'psnr': r['psnr']} for r in worst],
        'thirty_frame_segments': segments,
        'fps_scope': benchmark['scopes']['render_fps'],
        'all_300_decoded_states_verified': True,
        'timing_protocol': benchmark['timing_protocol'], 'gpu_name': benchmark['gpu_name']}
    summary_path = BATCH / f'rate{suffix}_analysis.json'
    with summary_path.open('x') as handle:
        json.dump(result, handle, indent=2)
        handle.write('\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('suffix', choices=['002', '003'])
    args = parser.parse_args()
    analyze(args.suffix)
