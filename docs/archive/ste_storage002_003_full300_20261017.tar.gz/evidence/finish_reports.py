"""Validate the completed pair and create portable comparison artifacts."""
from __future__ import annotations
import copy
import csv
import hashlib
import json
from pathlib import Path
import statistics

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import yaml

BATCH = Path(__file__).resolve().parent
REPO = BATCH.parent.parent
state = json.loads((BATCH / 'status.json').read_text())
assert state['status'] == 'complete'
assert [job['rate_loss_weight'] for job in state['jobs']] == [.002, .003]
assert all(job['training_returncode'] == job['benchmark_returncode'] == 0
           for job in state['jobs'])
analyses = [json.loads((BATCH / f'rate{suffix}_analysis.json').read_text())
            for suffix in ['002', '003']]
benchmarks = [json.loads(Path(analysis['benchmark']).read_text())
              for analysis in analyses]
configs = [yaml.safe_load((Path(analysis['run']) / 'config.yaml').read_text())
           for analysis in analyses]
normalized = copy.deepcopy(configs)
for config in normalized:
    config.pop('experiment_name')
    config['module']['rigid_tree'].pop('rate_loss_weight')
assert normalized[0] == normalized[1], 'Resolved run configurations differ'
assert [config['module']['rigid_tree']['rate_loss_weight'] for config in configs] == [.002, .003]

manifest_path = BATCH / 'source/source_manifest.json'
manifest = json.loads(manifest_path.read_text())
provenance = json.loads((BATCH / 'provenance.json').read_text())
assert hashlib.sha256(manifest_path.read_bytes()).hexdigest() == provenance['source_manifest_sha256']
for relative, expected in manifest['hashes'].items():
    assert hashlib.sha256((BATCH / 'source' / relative).read_bytes()).hexdigest() == expected, relative

references = [Path(benchmark['reference']) for benchmark in benchmarks]
with np.load(references[0]) as left, np.load(references[1]) as right:
    assert set(left.files) == set(right.files)
    assert all(np.array_equal(left[key], right[key]) for key in left.files)
    reference_field_count = len(left.files)
for analysis in analyses:
    assert analysis['all_300_decoded_states_verified']
    assert analysis['max_saved_quality_abs_difference'] == dict(psnr=0., ssim=0., l1=0.)
    assert analysis['max_cache_pixel_abs_difference'] == 0.

rows = []
for left, right in zip(benchmarks[0]['frames'], benchmarks[1]['frames']):
    assert left['frame'] == right['frame']
    rows.append(dict(frame=left['frame'],
        psnr_002=left['quality']['psnr'], psnr_003=right['quality']['psnr'],
        psnr_003_minus_002=right['quality']['psnr']-left['quality']['psnr'],
        complete_update_bytes_002=left['complete_update_bytes'],
        complete_update_bytes_003=right['complete_update_bytes'],
        complete_update_bytes_003_minus_002=right['complete_update_bytes']-left['complete_update_bytes'],
        pure_render_fps_002=left['render_fps'], pure_render_fps_003=right['render_fps']))
with (BATCH / 'per_frame_comparison.csv').open('x', newline='') as handle:
    writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)

diagnostics = []
for analysis in analyses:
    with Path(analysis['csv']).open(newline='') as handle:
        values = list(csv.DictReader(handle))[1:]
    diagnostics.append({key+'_mean': statistics.mean(float(row[key]) for row in values)
        for key in ['active_regions', 'open_gates', 'nonzero_gs_residuals',
                    'rate_bytes_surrogate', 'rate_bytes_hard']})

left, right = analyses
size0 = left['storage']['dynamic_packets']['complete_update_bytes_mean']
size1 = right['storage']['dynamic_packets']['complete_update_bytes_mean']
comparison = dict(
    source_manifest_sha256=provenance['source_manifest_sha256'],
    source_files_verified=len(manifest['hashes']),
    resolved_configs_equal_except_experiment_name_and_rate_weight=True,
    bootstrap_reference_fields_identical=reference_field_count,
    bootstrap_reference_sha256=[hashlib.sha256(path.read_bytes()).hexdigest() for path in references],
    measured_frames_per_run=[300, 300],
    psnr_all300_delta_003_minus_002=right['all_frames']['psnr_mean']-left['all_frames']['psnr_mean'],
    dynamic_update_bytes_mean_delta_003_minus_002=size1-size0,
    dynamic_update_reduction_fraction=1-size1/size0,
    ssim_all300_delta_003_minus_002=right['all_frames']['ssim_mean']-left['all_frames']['ssim_mean'],
    lpips_dynamic_delta_003_minus_002=right['lpips_dynamic_training_summary_mean']-left['lpips_dynamic_training_summary_mean'],
    diagnostics_002=diagnostics[0], diagnostics_003=diagnostics[1],
    metrics_scope=dict(psnr='arithmetic mean of per-frame decoded cam00 PSNR, frames 0..299',
        storage='actual dynamic packet files plus each manifest, frames 1..299; decimal KB; bootstrap separate',
        fps='aggregate full materialized render + clamp; decode, verification, upload and warmups excluded'),
    analysis_paths=[str(BATCH / f'rate{suffix}_analysis.json') for suffix in ['002', '003']])
(BATCH / 'comparison.json').write_text(json.dumps(comparison, indent=2)+'\n')

def rolling(values, window=30):
    values = np.asarray(values, dtype=float)
    sums = np.concatenate(([0.], np.cumsum(values)))
    return np.array([(sums[i+1]-sums[max(0, i-window+1)]) / min(i+1, window)
                     for i in range(len(values))])

plt.rcParams.update({'font.size': 10, 'axes.spines.top': False,
                     'axes.spines.right': False, 'savefig.facecolor': 'white'})
fig, axes = plt.subplots(2, 1, figsize=(11.5, 7), sharex=True,
                         constrained_layout=True)
colors = ['#1764ab', '#d46b12']
for suffix, color in zip(['002', '003'], colors):
    frame = [row['frame'] for row in rows]
    psnr_values = [row['psnr_'+suffix] for row in rows]
    sizes = [row['complete_update_bytes_'+suffix]/1000 for row in rows[1:]]
    axes[0].plot(frame, psnr_values, color=color, alpha=.23, linewidth=.7)
    axes[0].plot(frame, rolling(psnr_values), color=color, linewidth=2,
                 label='storage weight = 0.'+suffix)
    axes[1].plot(frame[1:], sizes, color=color, alpha=.23, linewidth=.7)
    axes[1].plot(frame[1:], rolling(sizes), color=color, linewidth=2)
axes[0].axhline(34.2, color='#666666', linestyle='--', linewidth=1,
               label='PSNR target: 34.2 dB')
axes[1].axhline(50, color='#666666', linestyle='--', linewidth=1,
               label='update target: 50 KB')
axes[0].set_ylabel('Decoded cam00 PSNR (dB)')
axes[1].set_ylabel('Complete dynamic update (KB)')
axes[1].set_xlabel('Frame index (0 is the shared reference)')
axes[0].set_title('Two completed 300-frame runs: identical code and settings except storage weight', loc='left')
axes[0].legend(loc='lower left', ncol=3, fontsize=9)
axes[1].legend(loc='lower left', fontsize=9)
axes[1].set_ylim(bottom=35)
axes[1].set_xlim(0, 299)
axes[1].set_xticks([0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 299])
for ax in axes:
    ax.grid(alpha=.18)
fig.supxlabel('Faint: individual frames. Bold: trailing 30-frame mean. KB = 1000 bytes; frame0 reference excluded from update sizes.', fontsize=9)
figure_path = REPO / 'docs/experiment/figures/20261017_ste_storage002_vs003_full300.png'
figure_path.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(figure_path, dpi=170)
plt.close(fig)
print(json.dumps(comparison, indent=2))
print('Figure:', figure_path)
