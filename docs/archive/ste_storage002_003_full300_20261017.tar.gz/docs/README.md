# 当前保留的实验

最新结果是 [STE gate、storage 0.002 / 0.003 的完整 300 帧对比](experiment/20261017_ste_storage002_vs003_full300.md)。两组均已训练完成并独立核验全部 300 帧。0.002 为 **33.0724 dB、127.338 KB/动态帧、199.494 纯渲染 FPS**；0.003 为 **33.2902 dB、119.698 KB/动态帧、199.820 纯渲染 FPS**。本次 0.003 的 PSNR 高 0.2178 dB，完整更新量少 6.00%，两组仍未达到画质与存储目标。

| 内容 | 记录 | 结果目录 |
|---|---|---|
| STE、storage 0.002，完整 300 帧 | [0.002 记录](experiment/20261017_ste_storage002_full300.md) | `output/fs_ste_depth4_rate002_full300_20261017/` |
| STE、storage 0.003，完整 300 帧 | [0.003 记录](experiment/20261017_ste_storage003_full300.md) | `output/fs_ste_depth4_rate003_full300_20261017/` |
| 此前 350 W 稳定性训练，30 帧 | [30 帧记录](experiment/20261016_gpu_350w_training_first30.md) | `output/fs_gpu_stability_350w_worldroute_first30_20261016/` |
| 此前长序列退化检查，实际完成 200 帧 | [200 帧记录](experiment/20261015_spatial_gate_worldroute200_stopped200.md) | `output/fs_spatial_gate_worldroute_200_full300_20261015/` |
| 稳健树初始化 CPU 审计 | [初始化审计](experiment/20261016_spatial_gate_robust_initialization_cpu.md) | `output/fs_spatial_gate_initialization_audit_20261016/` |

完整更新量含每帧 manifest，KB=1000 B，一次性首帧参考 17720236 B 另计。纯渲染 FPS 不含解码、验证和上传。逐帧 CSV、对比曲线和两次 benchmark 见完整对比记录；[轻量证据归档](archive/ste_storage002_003_full300_20261017.tar.gz) 保存固定源码与结果文本，原始训练产物仍在本地 output。

本轮实现提速核验单列为 [训练冗余与提速记录](experiment/20261016_training_redundancy_speed.md)：这是单帧执行速度检查，不是新增的全序列画质结果。

基础配置为 `config/fs_spatial_gate_depth4_200_full300_20261016.yaml`：最大深度 4、storage 权重 0.002、robust_median 初始化、远点连最近非空叶区域；首个动态帧细分 gate 全关，后续继承前帧 gate；前 70 步联合训练，后 30 步固定 gate，运动每步 2 个视角，再训练新增 GS 100 步（每步 1 个视角）。本次专用入口为 `config/fs_ste_depth4_rate002_full300_20261017.yaml` 和 `config/fs_ste_depth4_rate003_full300_20261017.yaml`，除实验名及权重外设置相同。两次执行同一固定源码，运行来源保存在 `output/fs_ste_rate_sweep_full300_20261017/`。

此前 [learnable gate 的 STE 与优化坐标核验](experiment/20261017_learnable_gate_ste_first6.md) 为共享首帧加五个动态帧：区域数 8、8、287、286、293，动态平均 34.4726 dB、完整更新 126.10 KB。它只用于短测机制检查；完整 300 帧结果已如上，不可用短测均值替代。

此前 [全关初始化短测](experiment/20261016_joint70_closedfirst_2view_first3.md) 为两动态帧平均 34.4233 dB、137.81 KB；[全开初始化短测](experiment/20261016_joint70_robustnearest_2view_first3.md) 为两动态帧平均 34.4122 dB、139.72 KB。这些是 STE/优化坐标修复之前的结果，不可与五帧均值直接比较。

此前保留的 30 帧和 200 帧训练结果来自五层、0.03 配方，不能当作当前配置的结果。初始化 CPU 审计只覆盖建树候选本身，与训练结果分别记录。

`config/` 保留基础配置、本次两个 300 帧入口，以及历史 30 帧配置、200 帧续训入口与 robust_median 候选，共 6 份 YAML。历史 200 帧续训入口使用保留的最后检查点和新 experiment_name；历史 run 内的原配置保持不变。

演示视频为 `output/4dgs_flame_steak_demo_1920x1080_20261016_122523.mp4`，同名 `.manifest.json` 保存来源帧摘要和视频核验信息。来源链中的旧训练目录已清理，成片仍可直接播放。

2026-10-16 清理前的实验记录、YAML 和轻量诊断文本保存在 `archive/history_before_20261016_cleanup.tar.gz`。归档不包含已删除的原始训练产物；删除清单、保留项和空间统计见 `archive/cleanup_20261016.json`。例如读取旧联合训练记录：

```bash
tar -xOf docs/archive/history_before_20261016_cleanup.tar.gz docs/experiment/20261014_spatial_gate_joint_first5.md
```
